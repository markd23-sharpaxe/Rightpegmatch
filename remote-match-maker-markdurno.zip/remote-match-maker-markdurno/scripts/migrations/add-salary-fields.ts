/**
 * This script adds salary-related fields to both the user and job tables
 */
import { db } from "../../server/db";
import { sql } from "drizzle-orm";

async function addSalaryFields() {
  console.log("Adding salary fields to users and jobs tables...");

  try {
    // Add salary fields to users table
    await db.execute(sql`
      ALTER TABLE users 
      ADD COLUMN IF NOT EXISTS min_salary_requirement DECIMAL(10,2),
      ADD COLUMN IF NOT EXISTS max_salary_requirement DECIMAL(10,2),
      ADD COLUMN IF NOT EXISTS salary_currency TEXT DEFAULT 'USD',
      ADD COLUMN IF NOT EXISTS preferred_salary_type TEXT DEFAULT 'hourly'
    `);
    
    console.log("Added salary fields to users table");

    // Add salary fields to jobs table
    await db.execute(sql`
      ALTER TABLE jobs 
      ADD COLUMN IF NOT EXISTS min_salary DECIMAL(10,2),
      ADD COLUMN IF NOT EXISTS max_salary DECIMAL(10,2),
      ADD COLUMN IF NOT EXISTS salary_type TEXT DEFAULT 'hourly'
    `);
    
    console.log("Added salary fields to jobs table");

    console.log("Migration completed successfully");
  } catch (error) {
    console.error("Error adding salary fields:", error);
    throw error;
  }
}

// Run the migration
addSalaryFields()
  .then(() => {
    console.log("Salary fields migration completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Migration failed:", error);
    process.exit(1);
  });