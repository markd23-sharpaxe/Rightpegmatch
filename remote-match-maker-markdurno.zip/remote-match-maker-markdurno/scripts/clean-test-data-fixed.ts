/**
 * This script removes test data from the database before production deployment
 * It deletes:
 * 1. Users with usernames starting with "test"
 * 2. Jobs created by test users
 * 3. Orphaned data (applications, matches, etc.)
 */

import { db } from "../server/db";
import { and, eq, ilike, inArray, isNull, sql } from "drizzle-orm";
import { 
  users, jobs, skills, jobApplications, jobMatchesCache, availabilitySlots,
  userSkills, userJobRoles, userSubscriptions, passwordResetTokens, messages, directMessages
} from "../shared/schema";

async function cleanTestData() {
  console.log("Starting test data cleanup...");
  
  try {
    // Find all test users (usernames starting with "test")
    const testUsers = await db.select({ id: users.id, username: users.username })
      .from(users)
      .where(ilike(users.username, 'test%'));
    
    if (testUsers.length === 0) {
      console.log("No test users found. Nothing to clean up.");
      return;
    }
    
    const testUserIds = testUsers.map(user => user.id);
    console.log(`Found ${testUsers.length} test users to remove: ${testUsers.map(u => u.username).join(', ')}`);
    
    // Find jobs posted by test users
    const testJobs = await db.select({ id: jobs.id, title: jobs.title })
      .from(jobs)
      .where(inArray(jobs.employerId, testUserIds));
    
    const testJobIds = testJobs.map(job => job.id);
    console.log(`Found ${testJobs.length} jobs posted by test users to remove`);
    
    // Transaction to delete all test data
    await db.transaction(async (tx) => {
      // Delete password reset tokens for test users
      if (testUserIds.length > 0) {
        const deletedTokens = await tx.delete(passwordResetTokens)
          .where(inArray(passwordResetTokens.userId, testUserIds))
          .returning({ id: passwordResetTokens.id });
        console.log(`Deleted ${deletedTokens.length} password reset tokens`);
      }
      
      // Get all application IDs for test users or jobs
      const testApplications = await tx.select({ id: jobApplications.id })
        .from(jobApplications)
        .where(
          inArray(jobApplications.jobseekerId, testUserIds)
        );
        
      const testJobApplications = await tx.select({ id: jobApplications.id })
        .from(jobApplications)
        .where(
          inArray(jobApplications.jobId, testJobIds)
        );
        
      const testApplicationIds = [
        ...testApplications.map(app => app.id),
        ...testJobApplications.map(app => app.id)
      ];
      
      console.log(`Found ${testApplicationIds.length} job applications to remove`);
      
      // Delete messages related to test job applications first
      if (testApplicationIds.length > 0) {
        const deletedMessages = await tx.delete(messages)
          .where(inArray(messages.applicationId, testApplicationIds))
          .returning({ id: messages.id });
        console.log(`Deleted ${deletedMessages.length} application messages`);
      }
      
      // Delete direct messages where test user is sender or receiver
      if (testUserIds.length > 0) {
        const deletedDirectMessages = await tx.delete(directMessages)
          .where(
            inArray(directMessages.senderId, testUserIds)
          )
          .returning({ id: directMessages.id });
          
        const deletedReceiverMessages = await tx.delete(directMessages)
          .where(
            inArray(directMessages.recipientId, testUserIds)
          )
          .returning({ id: directMessages.id });
          
        console.log(`Deleted ${deletedDirectMessages.length + deletedReceiverMessages.length} direct messages`);
      }
      
      // Delete job applications related to test users (as applicant or job owner)
      if (testUserIds.length > 0 || testJobIds.length > 0) {
        // First delete applications where test user is the applicant
        const deletedUserApplications = await tx.delete(jobApplications)
          .where(inArray(jobApplications.jobseekerId, testUserIds))
          .returning({ id: jobApplications.id });
        
        // Then delete applications for jobs created by test users
        const deletedJobApplications = await tx.delete(jobApplications)
          .where(inArray(jobApplications.jobId, testJobIds))
          .returning({ id: jobApplications.id });
          
        console.log(`Deleted ${deletedUserApplications.length + deletedJobApplications.length} job applications`);
      }
      
      // Delete job matches related to test users or jobs
      if (testUserIds.length > 0 || testJobIds.length > 0) {
        // First delete matches where user is the match target
        const deletedUserMatches = await tx.delete(jobMatchesCache)
          .where(inArray(jobMatchesCache.userId, testUserIds))
          .returning({ id: jobMatchesCache.id });
        
        // Then delete matches for jobs created by test users
        const deletedJobMatches = await tx.delete(jobMatchesCache)
          .where(inArray(jobMatchesCache.jobId, testJobIds))
          .returning({ id: jobMatchesCache.id });
          
        console.log(`Deleted ${deletedUserMatches.length + deletedJobMatches.length} job matches`);
      }
      
      // Delete jobs created by test users
      if (testUserIds.length > 0) {
        const deletedJobs = await tx.delete(jobs)
          .where(inArray(jobs.employerId, testUserIds))
          .returning({ id: jobs.id });
        console.log(`Deleted ${deletedJobs.length} jobs`);
      }
      
      // Delete user subscriptions for test users
      if (testUserIds.length > 0) {
        const deletedSubscriptions = await tx.delete(userSubscriptions)
          .where(inArray(userSubscriptions.userId, testUserIds))
          .returning({ id: userSubscriptions.id });
        console.log(`Deleted ${deletedSubscriptions.length} user subscriptions`);
      }
      
      // Delete user skills for test users
      if (testUserIds.length > 0) {
        const deletedUserSkills = await tx.delete(userSkills)
          .where(inArray(userSkills.userId, testUserIds))
          .returning({ id: userSkills.id });
        console.log(`Deleted ${deletedUserSkills.length} user skills`);
      }
      
      // Delete user job roles for test users
      if (testUserIds.length > 0) {
        const deletedUserJobRoles = await tx.delete(userJobRoles)
          .where(inArray(userJobRoles.userId, testUserIds))
          .returning({ id: userJobRoles.id });
        console.log(`Deleted ${deletedUserJobRoles.length} user job roles`);
      }
      
      // Delete availability slots for test users
      if (testUserIds.length > 0) {
        const deletedAvailabilitySlots = await tx.delete(availabilitySlots)
          .where(inArray(availabilitySlots.userId, testUserIds))
          .returning({ id: availabilitySlots.id });
        console.log(`Deleted ${deletedAvailabilitySlots.length} availability slots`);
      }
      
      // Finally, delete the test users themselves
      if (testUserIds.length > 0) {
        const deletedUsers = await tx.delete(users)
          .where(inArray(users.id, testUserIds))
          .returning({ id: users.id, username: users.username });
        console.log(`Deleted ${deletedUsers.length} test users: ${deletedUsers.map(u => u.username).join(', ')}`);
      }
    });
    
    console.log("Test data cleanup completed successfully!");
  } catch (error) {
    console.error("Error cleaning test data:", error);
    throw error;
  }
}

// Add an or function since TypeScript doesn't recognize drizzle-orm's or function properly
function or(...conditions: any[]) {
  return sql`(${conditions.map(c => `(${c})`).join(' OR ')})`;
}

// Run the script
cleanTestData()
  .then(() => {
    console.log("Test data cleanup completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error in test data cleanup:", error);
    process.exit(1);
  });