/**
 * This script removes test data from the database before production deployment
 * It deletes:
 * 1. Users with usernames starting with "test"
 * 2. Jobs created by test users
 * 3. Orphaned data (applications, matches, messages, etc.)
 * 
 * This script handles foreign key constraints by deleting data in the correct order.
 */

import { db } from "../server/db";
import { ilike, inArray, sql } from "drizzle-orm";
import { 
  users, jobs, jobApplications, jobMatchesCache, availabilitySlots,
  userSkills, userJobRoles, userSubscriptions, passwordResetTokens,
  messages, userQualifications, jobRequiredSkills
} from "../shared/schema";

async function cleanProductionData() {
  console.log("Starting test data cleanup for production...");
  
  try {
    // Step 1: Find all test users (usernames starting with "test" or "Testing")
    const testUsers = await db.select({ id: users.id, username: users.username })
      .from(users)
      .where(sql`${users.username} ILIKE 'test%'`);
    
    if (testUsers.length === 0) {
      console.log("No test users found. Nothing to clean up.");
      return;
    }
    
    const testUserIds = testUsers.map(user => user.id);
    console.log(`Found ${testUsers.length} test users to remove: ${testUsers.map(u => u.username).join(', ')}`);
    
    // Step 2: Find jobs posted by test users
    const testJobs = await db.select({ id: jobs.id })
      .from(jobs)
      .where(sql`${jobs.employerId} IN (${testUserIds.join(',')})`);
    
    const testJobIds = testJobs.map(job => job.id);
    console.log(`Found ${testJobs.length} jobs posted by test users to remove`);
    
    // Step 3: Find applications related to test users or jobs
    const jobApplicationsFromTestUsers = await db.select({ id: jobApplications.id })
      .from(jobApplications)
      .where(sql`${jobApplications.jobseekerId} IN (${testUserIds.join(',')})`);
      
    const jobApplicationsForTestJobs = await db.select({ id: jobApplications.id })
      .from(jobApplications)
      .where(sql`${jobApplications.jobId} IN (${testJobIds.join(',')})`);
      
    const allTestApplicationIds = [
      ...jobApplicationsFromTestUsers.map(app => app.id),
      ...jobApplicationsForTestJobs.map(app => app.id)
    ];
    
    console.log(`Found ${allTestApplicationIds.length} job applications related to test data`);
    
    // Begin transaction
    await db.transaction(async (tx) => {
      // Step 4: Delete in order of dependencies
      
      // 4.1: Delete messages related to test applications
      if (allTestApplicationIds.length > 0) {
        const { count } = await tx.execute(
          sql`DELETE FROM ${messages} WHERE application_id IN (${allTestApplicationIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${count} application messages`);
      }
      
      // 4.2: Delete direct messages where test user is sender or receiver
      if (testUserIds.length > 0) {
        const { count: senderCount } = await tx.execute(
          sql`DELETE FROM ${directMessages} WHERE sender_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        
        const { count: receiverCount } = await tx.execute(
          sql`DELETE FROM ${directMessages} WHERE receiver_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        
        console.log(`Deleted ${senderCount + receiverCount} direct messages`);
      }
      
      // 4.3: Delete notifications for test users
      if (testUserIds.length > 0) {
        const { count } = await tx.execute(
          sql`DELETE FROM ${notifications} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${count} notifications`);
      }
      
      // 4.4: Delete job applications
      if (allTestApplicationIds.length > 0) {
        const { count } = await tx.execute(
          sql`DELETE FROM ${jobApplications} WHERE id IN (${allTestApplicationIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${count} job applications`);
      }
      
      // 4.5: Delete job matches for test users or jobs
      if (testUserIds.length > 0) {
        const { count: userMatchCount } = await tx.execute(
          sql`DELETE FROM ${jobMatchesCache} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${userMatchCount} job matches for test users`);
      }
      
      if (testJobIds.length > 0) {
        const { count: jobMatchCount } = await tx.execute(
          sql`DELETE FROM ${jobMatchesCache} WHERE job_id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${jobMatchCount} job matches for test jobs`);
      }
      
      // 4.6: Delete job indexes and requirements for test jobs
      if (testJobIds.length > 0) {
        // Delete job language indexes
        const { count: langIndexCount } = await tx.execute(
          sql`DELETE FROM ${jobUserLanguageIndexes} WHERE job_id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${langIndexCount} job language indexes`);
        
        // Delete job family indexes
        const { count: familyIndexCount } = await tx.execute(
          sql`DELETE FROM ${jobFamilyIndexes} WHERE job_id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${familyIndexCount} job family indexes`);
        
        // Delete job skill requirements
        const { count: skillReqCount } = await tx.execute(
          sql`DELETE FROM ${jobSkillRequirements} WHERE job_id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${skillReqCount} job skill requirements`);
        
        // Delete job qualification requirements
        const { count: qualReqCount } = await tx.execute(
          sql`DELETE FROM ${jobQualificationRequirements} WHERE job_id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${qualReqCount} job qualification requirements`);
        
        // Delete job role requirements
        const { count: roleReqCount } = await tx.execute(
          sql`DELETE FROM ${jobRoleRequirements} WHERE job_id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${roleReqCount} job role requirements`);
        
        // Delete job availability requirements
        const { count: availReqCount } = await tx.execute(
          sql`DELETE FROM ${jobAvailabilityRequirements} WHERE job_id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${availReqCount} job availability requirements`);
      }
      
      // 4.7: Delete test jobs
      if (testJobIds.length > 0) {
        const { count } = await tx.execute(
          sql`DELETE FROM ${jobs} WHERE id IN (${testJobIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${count} test jobs`);
      }
      
      // 4.8: Delete user related data
      if (testUserIds.length > 0) {
        // Delete user indexes
        const { count: userLangCount } = await tx.execute(
          sql`DELETE FROM ${userLanguageIndexes} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${userLangCount} user language indexes`);
        
        const { count: userFamilyCount } = await tx.execute(
          sql`DELETE FROM ${userJobFamilyIndexes} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${userFamilyCount} user job family indexes`);
        
        // Delete user subscriptions
        const { count: subscriptionCount } = await tx.execute(
          sql`DELETE FROM ${userSubscriptions} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${subscriptionCount} user subscriptions`);
        
        // Delete user skills
        const { count: skillCount } = await tx.execute(
          sql`DELETE FROM ${userSkills} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${skillCount} user skills`);
        
        // Delete user job roles
        const { count: roleCount } = await tx.execute(
          sql`DELETE FROM ${userJobRoles} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${roleCount} user job roles`);
        
        // Delete availability slots
        const { count: availCount } = await tx.execute(
          sql`DELETE FROM ${availabilitySlots} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${availCount} availability slots`);
        
        // Delete password reset tokens
        const { count: tokenCount } = await tx.execute(
          sql`DELETE FROM ${passwordResetTokens} WHERE user_id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${tokenCount} password reset tokens`);
      }
      
      // 4.9: Finally, delete test users
      if (testUserIds.length > 0) {
        const { count } = await tx.execute(
          sql`DELETE FROM ${users} WHERE id IN (${testUserIds.join(',')}) RETURNING id`
        );
        console.log(`Deleted ${count} test users`);
      }
    });
    
    console.log("Test data cleanup completed successfully!");
  } catch (error) {
    console.error("Error cleaning test data:", error);
    throw error;
  }
}

// Run the script
cleanProductionData()
  .then(() => {
    console.log("Test data cleanup completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error in test data cleanup:", error);
    process.exit(1);
  });