/**
 * Quick fix script to set up matching indexes for Testing2 user and Right Peg Match job
 */

import { db } from "../server/db";
import * as schema from "../shared/schema";
import { eq } from "drizzle-orm";

async function fixTesting2Match() {
  console.log("Starting to fix Testing2 match with Right Peg Match job...");
  
  // Get the Testing2 user
  const [testing2] = await db.select().from(schema.users).where(eq(schema.users.username, "Testing2"));
  if (!testing2) {
    console.log("User Testing2 not found!");
    return;
  }
  console.log(`Found user Testing2 with ID: ${testing2.id}`);
  
  // Get the Right Peg Match job
  const [rightPegJob] = await db.select().from(schema.jobs)
    .where(eq(schema.jobs.companyName, "Right Peg Match"))
    .where(eq(schema.jobs.title, "Project Manager"));
  
  if (!rightPegJob) {
    console.log("Right Peg Match Project Manager job not found!");
    return;
  }
  console.log(`Found job Right Peg Match with ID: ${rightPegJob.id}`);
  
  // Add user language index
  if (testing2.languages) {
    const languages = testing2.languages.split(',').map(lang => lang.trim());
    for (const language of languages) {
      if (language) {
        await db.insert(schema.userLanguageIndex).values({
          userId: testing2.id,
          language
        }).onConflictDoNothing();
        console.log(`Added language "${language}" for user Testing2`);
      }
    }
  }
  
  // Get user job roles to determine job families
  let userJobFamily = "";
  
  // Try to get from user job roles
  const userJobRoles = await db.select({
    role: schema.jobRoles
  })
  .from(schema.userJobRoles)
  .innerJoin(schema.jobRoles, eq(schema.userJobRoles.jobRoleId, schema.jobRoles.id))
  .where(eq(schema.userJobRoles.userId, testing2.id));
  
  for (const userJobRole of userJobRoles) {
    if (userJobRole.role.jobFamily) {
      userJobFamily = userJobRole.role.jobFamily;
      break;
    }
  }
  
  // If not found, try legacy job role ID
  if (!userJobFamily && testing2.jobRoleId) {
    const [legacyJobRole] = await db.select().from(schema.jobRoles).where(eq(schema.jobRoles.id, testing2.jobRoleId));
    if (legacyJobRole?.jobFamily) {
      userJobFamily = legacyJobRole.jobFamily;
    }
  }
  
  if (userJobFamily) {
    await db.insert(schema.userJobFamilyIndex).values({
      userId: testing2.id,
      jobFamily: userJobFamily
    }).onConflictDoNothing();
    console.log(`Added job family "${userJobFamily}" for user Testing2`);
  } else {
    console.log("No job family found for Testing2 user");
  }
  
  // Add job language index
  if (rightPegJob.requiredLanguages) {
    const languages = rightPegJob.requiredLanguages.split(',').map(lang => lang.trim());
    for (const language of languages) {
      if (language) {
        await db.insert(schema.jobLanguageIndex).values({
          jobId: rightPegJob.id,
          language
        }).onConflictDoNothing();
        console.log(`Added language "${language}" for Right Peg Match job`);
      }
    }
  }
  
  // Add job family index
  if (rightPegJob.jobFamily) {
    await db.insert(schema.jobFamilyIndex).values({
      jobId: rightPegJob.id,
      jobFamily: rightPegJob.jobFamily
    }).onConflictDoNothing();
    console.log(`Added job family "${rightPegJob.jobFamily}" for Right Peg Match job`);
  } else {
    // If no job family directly on the job, try to get it from the job role
    if (rightPegJob.jobRoleId) {
      const [jobRole] = await db.select().from(schema.jobRoles).where(eq(schema.jobRoles.id, rightPegJob.jobRoleId));
      if (jobRole?.jobFamily) {
        await db.insert(schema.jobFamilyIndex).values({
          jobId: rightPegJob.id,
          jobFamily: jobRole.jobFamily
        }).onConflictDoNothing();
        console.log(`Added job family "${jobRole.jobFamily}" for Right Peg Match job (from job role)`);
      }
    }
  }
  
  console.log("Fix completed!");
}

// Run the script
fixTesting2Match()
  .then(() => {
    console.log("All done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error fixing Testing2 match:", error);
    process.exit(1);
  });