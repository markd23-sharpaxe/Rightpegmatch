/**
 * This script creates the qualifications tables in the database
 */
import { db } from "../server/db";
import { qualifications, userQualifications } from "../shared/schema";
import { eq } from "drizzle-orm";

async function createQualificationsTables() {
  try {
    console.log("Creating qualifications table...");
    
    // Create qualifications table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS qualifications (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE
      );
    `);
    
    console.log("Creating user_qualifications table...");
    
    // Create user_qualifications join table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS user_qualifications (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id),
        qualification_id INTEGER NOT NULL REFERENCES qualifications(id)
      );
    `);
    
    console.log("Tables created successfully!");
    
    // Add some initial qualifications
    const initialQualifications = [
      "Bachelor's Degree",
      "Master's Degree",
      "PhD",
      "Certified Project Manager (PMP)",
      "Certified Scrum Master",
      "AWS Certified Solutions Architect",
      "Google Cloud Certified",
      "Microsoft Certified: Azure",
      "Cisco Certified Network Associate (CCNA)",
      "CompTIA Security+",
      "Chartered Financial Analyst (CFA)",
      "Certified Public Accountant (CPA)",
      "Licensed Professional Engineer",
      "ITIL Certification",
      "Six Sigma Green Belt",
      "Six Sigma Black Belt",
      "Certified Information Systems Security Professional (CISSP)",
      "Certified Ethical Hacker (CEH)",
      "Professional Engineer License",
      "Teaching License/Certification"
    ];
    
    console.log("Adding initial qualifications...");
    
    for (const qualification of initialQualifications) {
      try {
        // Insert qualification, ignoring if it already exists
        await db.insert(qualifications).values({ name: qualification });
        console.log(`Added qualification: ${qualification}`);
      } catch (error) {
        // If it's a duplicate key error, ignore it
        console.log(`Qualification already exists: ${qualification}`);
      }
    }
    
    console.log("Initial qualifications added!");
    
  } catch (error) {
    console.error("Error creating qualifications tables:", error);
    throw error;
  }
}

// Run the script
createQualificationsTables()
  .then(() => {
    console.log("Qualifications tables setup completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed to create qualifications tables:", error);
    process.exit(1);
  });