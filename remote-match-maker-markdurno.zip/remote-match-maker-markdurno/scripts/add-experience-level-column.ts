/**
 * This script adds the experience_level column to the user_job_roles table
 */
import { db } from "../server/db";

async function addExperienceLevelColumn() {
  try {
    console.log("Adding experience_level column to user_job_roles table...");
    
    // Check if column exists
    const checkColumnResult = await db.execute(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'user_job_roles' AND column_name = 'experience_level';
    `);
    
    if (checkColumnResult.rows.length === 0) {
      // Add the column if it doesn't exist
      await db.execute(`
        ALTER TABLE user_job_roles 
        ADD COLUMN experience_level TEXT;
      `);
      console.log("Added experience_level column to user_job_roles table");
    } else {
      console.log("experience_level column already exists in user_job_roles table");
    }
    
  } catch (error) {
    console.error("Error adding experience_level column:", error);
    throw error;
  }
}

// Run the script
addExperienceLevelColumn()
  .then(() => {
    console.log("Completed successfully");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed:", error);
    process.exit(1);
  });