/**
 * This script adds qualification columns to the jobs table
 */
import { pool } from "../server/db";
import { db } from "../server/db";
import { jobs } from "../shared/schema";
import { jsonb } from "drizzle-orm/pg-core";

async function addQualificationsColumns() {
  console.log("Adding qualification columns to jobs table...");
  
  try {
    // Check if columns already exist
    const checkResult = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'jobs' 
      AND column_name in ('required_qualifications', 'optional_qualifications')
    `);
    
    // If both columns already exist, we don't need to do anything
    if (checkResult.rowCount === 2) {
      console.log("Qualification columns already exist. No changes needed.");
      return;
    }
    
    // Add the required_qualifications column if it doesn't exist
    if (!checkResult.rows.some(row => row.column_name === 'required_qualifications')) {
      await pool.query(`
        ALTER TABLE jobs
        ADD COLUMN required_qualifications JSONB DEFAULT '[]'::jsonb
      `);
      console.log("Added required_qualifications column.");
    }
    
    // Add the optional_qualifications column if it doesn't exist
    if (!checkResult.rows.some(row => row.column_name === 'optional_qualifications')) {
      await pool.query(`
        ALTER TABLE jobs
        ADD COLUMN optional_qualifications JSONB DEFAULT '[]'::jsonb
      `);
      console.log("Added optional_qualifications column.");
    }
    
    console.log("Qualification columns added successfully!");
  } catch (error) {
    console.error("Error adding qualification columns:", error);
    throw error;
  } finally {
    await pool.end();
  }
}

// Run the migration
addQualificationsColumns()
  .then(() => console.log("Migration completed successfully"))
  .catch(console.error);