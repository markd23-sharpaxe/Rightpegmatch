/**
 * This script adds more jobs to reach at least 200 total jobs in the database
 * without affecting existing data
 */

import { db } from "../server/db";
import { sql } from "drizzle-orm";
import {
  users, jobs, skills, jobRoles, jobRequiredSkills,
  JobFamily, SalaryType, StartDateFlexibilityType,
  InsertJob, JobAvailabilityRequirement
} from "../shared/schema";

// Common test data
const companyNames = [
  "TechNova Solutions", "Global Innovations Group", "NextGen Systems", "Horizon Analytics",
  "Blue Ocean Consulting", "CloudSphere Technologies", "Apex Digital Ventures", "Quantum Leap Networks",
  "Pinnacle Solutions", "Stellar Systems", "Catalyst Dynamics", "Fusion Technologies",
  "Prism Solutions", "Emerge Digital", "Traverse Industries", "Nexus Innovations",
  "Vertex Systems", "Elevate Technologies", "Spark Analytics", "Pulse Dynamics",
  "Echo Technologies", "Vanguard Solutions", "Mosaic Digital", "Zenith Systems",
  "Orbit Innovations", "Summit Technologies", "Spectrum Solutions", "Beacon Consulting",
  "Phoenix Technologies", "Axiom Solutions", "Everest Innovations", "Meridian Systems"
];

const languages = ["English", "Spanish", "French", "German", "Chinese", "Japanese", "Korean", "Russian", "Portuguese"];
const currencies = ["USD", "EUR", "GBP", "CAD", "AUD"];
const salaryTypes: SalaryType[] = ["hourly", "weekly", "monthly", "yearly"];
const startDateFlexibilityOptions: StartDateFlexibilityType[] = ["exact", "month", "immediate"];
const timeZones = ["GMT+0", "GMT-5", "GMT-8", "GMT+1", "GMT+2", "GMT+3", "GMT+5:30", "GMT+8", "GMT+9"];

/**
 * Generate a random integer between min and max (inclusive)
 */
function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Select a random item from an array
 */
function getRandomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Select a random subset of items from an array
 */
function getRandomSubset<T>(arr: T[], min: number, max: number): T[] {
  const count = getRandomInt(min, Math.min(max, arr.length));
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

/**
 * Generate a random date within a range
 */
function getRandomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

/**
 * Generate random availability slots
 */
function generateAvailabilitySlots(count: number): JobAvailabilityRequirement[] {
  const slots: JobAvailabilityRequirement[] = [];
  const days = [1, 2, 3, 4, 5]; // Monday to Friday
  
  for (let i = 0; i < count; i++) {
    const dayOfWeek = getRandomItem(days);
    const startHour = getRandomInt(8, 16);
    const endHour = getRandomInt(startHour + 1, Math.min(startHour + 8, 23));
    const timeZone = getRandomItem(timeZones);
    
    slots.push({
      dayOfWeek,
      startHour,
      endHour,
      timeZone
    });
  }
  
  return slots;
}

/**
 * Generate a job description
 */
function generateJobDescription(roleName: string, jobFamily: string): string {
  const descriptions = [
    `We are looking for a talented ${roleName} with experience in ${jobFamily} to join our remote team. You will work on exciting projects with clients worldwide.`,
    `Join our team as a ${roleName} and help us develop innovative solutions. This role involves collaborating with cross-functional teams and ensuring high-quality deliverables.`,
    `Experienced ${roleName} needed for a growing ${jobFamily} team. You will be responsible for working on challenging projects and contributing to our company's success.`,
    `Remote ${roleName} position available. We're seeking someone with strong ${jobFamily} skills who can work independently and as part of a team to deliver exceptional results.`,
    `We're hiring a ${roleName} to join our ${jobFamily} department. You'll work on diverse projects, collaborate with talented professionals, and grow your career with us.`
  ];
  
  return getRandomItem(descriptions);
}

/**
 * Add more jobs to the database
 */
async function addMoreJobs(batchSize: number) {
  // Get current job count
  const [result] = await db.select({ count: sql<number>`count(*)` }).from(jobs);
  const currentJobCount = result?.count || 0;
  
  console.log(`Current job count: ${currentJobCount}`);
  
  if (currentJobCount >= 200) {
    console.log("Already have 200+ jobs in the database. No need to add more.");
    return;
  }
  
  const jobsToAdd = Math.max(200 - currentJobCount, 0);
  console.log(`Will add ${jobsToAdd} more jobs to reach at least 200`);
  
  // Get all users, job roles, and skills
  const allUsers = await db.select().from(users);
  const allJobRoles = await db.select().from(jobRoles);
  const allSkills = await db.select().from(skills);
  
  // Process in batches to avoid timeouts
  for (let i = 0; i < jobsToAdd; i += batchSize) {
    const batchEnd = Math.min(i + batchSize, jobsToAdd);
    console.log(`Adding jobs ${i + 1} to ${batchEnd} of ${jobsToAdd}...`);
    
    const jobBatch = [];
    
    for (let j = i; j < batchEnd; j++) {
      // Select random job role and employer
      const jobRole = getRandomItem(allJobRoles);
      const employer = getRandomItem(allUsers);
      
      // Job dates
      const now = new Date();
      const futureDate = new Date();
      futureDate.setMonth(now.getMonth() + 3);
      
      const isPermanent = Math.random() > 0.5;
      const startDate = getRandomDate(now, new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000));
      const endDate = isPermanent ? undefined : getRandomDate(futureDate, new Date(futureDate.getTime() + 90 * 24 * 60 * 60 * 1000));
      
      // Generate availability slots
      const availabilitySlots = generateAvailabilitySlots(getRandomInt(1, 3));
      
      // Create job
      const jobData: InsertJob = {
        title: `${jobRole.name} at ${getRandomItem(companyNames)}`,
        employerId: employer.id,
        companyName: getRandomItem(companyNames),
        jobRoleId: jobRole.id,
        jobFamily: jobRole.jobFamily,
        hoursPerWeek: getRandomInt(10, 40),
        salaryAmount: getRandomInt(20, 120).toString(),
        salaryType: getRandomItem(salaryTypes),
        currency: getRandomItem(currencies),
        requiredLanguages: getRandomSubset(languages, 1, 2).join(", "),
        requiredAvailability: availabilitySlots,
        description: generateJobDescription(jobRole.name, jobRole.jobFamily),
        location: "Remote",
        startDate,
        endDate,
        startDateFlexibility: getRandomItem(startDateFlexibilityOptions),
        isPermanent
      };
      
      jobBatch.push(jobData);
    }
    
    // Insert job batch
    const insertedJobs = await db.insert(jobs).values(jobBatch).returning({ id: jobs.id, jobRoleId: jobs.jobRoleId });
    
    // Add required skills
    for (const job of insertedJobs) {
      // Get skills for the job (2-4 skills per job)
      const skillsToAdd = getRandomSubset(allSkills, 2, 4);
      
      for (const skill of skillsToAdd) {
        await db.execute(sql`
          INSERT INTO job_required_skills (job_id, skill_id)
          VALUES (${job.id}, ${skill.id})
        `);
      }
    }
    
    console.log(`Added batch of ${insertedJobs.length} jobs`);
  }
  
  // Get new job count
  const [newResult] = await db.select({ count: sql<number>`count(*)` }).from(jobs);
  const newJobCount = newResult?.count || 0;
  
  console.log(`New job count: ${newJobCount}`);
}

/**
 * Main function
 */
async function main() {
  try {
    const batchSize = 20; // Process in batches of 20 jobs to avoid timeouts
    await addMoreJobs(batchSize);
    console.log("Completed adding more jobs!");
  } catch (error) {
    console.error("Error adding jobs:", error);
    process.exit(1);
  }
}

// Run the script
main().then(() => {
  console.log("Done!");
  process.exit(0);
}).catch((error) => {
  console.error("Script failed:", error);
  process.exit(1);
});