/**
 * Script to generate mock data for development
 * 
 * This script creates 100 user profiles and 100 job listings with realistic data.
 */

import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';
import { 
  users, 
  skills, 
  jobs, 
  userSkills, 
  availabilitySlots,
  subscriptionPlans,
  userSubscriptions
} from '../shared/schema';
import { skillCategories, getStandardizedSkills } from '../shared/skill-utils';
import { getCommonTimeZones } from '../shared/time-utils';
import { storage } from '../server/storage';

const scryptAsync = promisify(scrypt);

// Helper to hash passwords
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex');
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString('hex')}.${salt}`;
}

// Utility to get random item from an array
function getRandomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// Utility to get random subset of array
function getRandomSubset<T>(arr: T[], min: number, max: number): T[] {
  const count = Math.floor(Math.random() * (max - min + 1)) + min;
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

// Generate random time slots for availability
function generateAvailabilitySlots(userId: number, count: number) {
  const availabilitySlots = [];
  const days = [0, 1, 2, 3, 4, 5, 6]; // Monday to Sunday
  const randomDays = getRandomSubset(days, 1, 5);
  const timeZones = getCommonTimeZones();
  const timeZone = getRandomItem(timeZones).value;
  
  for (const day of randomDays) {
    // Generate a time slot during common working hours
    const startHour = Math.floor(Math.random() * 4) + 8; // 8 AM to 12 PM
    const duration = Math.floor(Math.random() * 6) + 3; // 3 to 8 hours
    const endHour = Math.min(startHour + duration, 22); // Don't go past 10 PM
    
    availabilitySlots.push({
      userId,
      dayOfWeek: day,
      startHour,
      endHour,
      timeZone
    });
  }
  
  return availabilitySlots;
}

// MOCK DATA GENERATORS

// Generate 100 unique skills
async function generateSkills() {
  console.log('Generating skills...');
  
  // Get all standardized skills from different categories
  const allSkills: string[] = [];
  getStandardizedSkills().forEach(category => {
    allSkills.push(...category.skills);
  });
  
  // Ensure uniqueness
  const uniqueSkills = [...new Set(allSkills)];
  
  // Create skill records
  for (const skillName of uniqueSkills) {
    try {
      await storage.createSkill({ name: skillName });
    } catch (e) {
      console.log(`Skill already exists: ${skillName}`);
    }
  }
  
  console.log(`${uniqueSkills.length} skills created`);
  return uniqueSkills;
}

// Generate subscription plans
async function generateSubscriptionPlans() {
  console.log('Generating subscription plans...');
  
  const plans = [
    {
      name: 'Free',
      description: 'Basic access to job listings',
      price: '£0.00',
      maxSearches: 0,
      maxApplicantViews: 0,
      isUnlimited: false
    },
    {
      name: 'Basic',
      description: 'Access to basic search features and limited applicant views',
      price: '£9.99',
      maxSearches: 10,
      maxApplicantViews: 5,
      isUnlimited: false
    },
    {
      name: 'Professional',
      description: 'Increased search capacity and applicant views',
      price: '£19.99',
      maxSearches: 20,
      maxApplicantViews: 10,
      isUnlimited: false
    },
    {
      name: 'Premium',
      description: 'Unlimited searches and applicant views',
      price: '£29.99',
      maxSearches: 100,
      maxApplicantViews: 100,
      isUnlimited: true
    }
  ];
  
  for (const plan of plans) {
    try {
      await storage.createSubscriptionPlan(plan);
    } catch (e) {
      console.log(`Plan already exists: ${plan.name}`);
    }
  }
  
  console.log(`${plans.length} subscription plans created`);
}

// Generate 100 users
async function generateUsers() {
  console.log('Generating users...');
  
  const firstNames = [
    'James', 'Mary', 'John', 'Patricia', 'Robert', 'Jennifer', 'Michael', 'Linda', 'William', 'Elizabeth',
    'David', 'Barbara', 'Richard', 'Susan', 'Joseph', 'Jessica', 'Thomas', 'Sarah', 'Charles', 'Karen',
    'Christopher', 'Nancy', 'Daniel', 'Lisa', 'Matthew', 'Betty', 'Anthony', 'Margaret', 'Mark', 'Sandra',
    'Donald', 'Ashley', 'Steven', 'Kimberly', 'Paul', 'Emily', 'Andrew', 'Donna', 'Joshua', 'Michelle',
    'Kenneth', 'Dorothy', 'Kevin', 'Carol', 'Brian', 'Amanda', 'George', 'Melissa', 'Edward', 'Deborah',
    'Ronald', 'Stephanie', 'Timothy', 'Rebecca', 'Jason', 'Sharon', 'Jeffrey', 'Laura', 'Ryan', 'Cynthia',
    'Jacob', 'Kathleen', 'Gary', 'Amy', 'Nicholas', 'Shirley', 'Eric', 'Angela', 'Jonathan', 'Helen',
    'Stephen', 'Anna', 'Larry', 'Brenda', 'Justin', 'Pamela', 'Scott', 'Nicole', 'Brandon', 'Emma',
    'Benjamin', 'Samantha', 'Samuel', 'Katherine', 'Gregory', 'Christine', 'Frank', 'Debra', 'Alexander', 'Rachel',
    'Raymond', 'Catherine', 'Patrick', 'Carolyn', 'Jack', 'Janet', 'Dennis', 'Ruth', 'Jerry', 'Maria'
  ];
  
  const lastNames = [
    'Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Garcia', 'Rodriguez', 'Wilson',
    'Martinez', 'Anderson', 'Taylor', 'Thomas', 'Hernandez', 'Moore', 'Martin', 'Jackson', 'Thompson', 'White',
    'Lopez', 'Lee', 'Gonzalez', 'Harris', 'Clark', 'Lewis', 'Robinson', 'Walker', 'Perez', 'Hall',
    'Young', 'Allen', 'Sanchez', 'Wright', 'King', 'Scott', 'Green', 'Baker', 'Adams', 'Nelson',
    'Hill', 'Ramirez', 'Campbell', 'Mitchell', 'Roberts', 'Carter', 'Phillips', 'Evans', 'Turner', 'Torres',
    'Parker', 'Collins', 'Edwards', 'Stewart', 'Flores', 'Morris', 'Nguyen', 'Murphy', 'Rivera', 'Cook',
    'Rogers', 'Morgan', 'Peterson', 'Cooper', 'Reed', 'Bailey', 'Bell', 'Gomez', 'Kelly', 'Howard',
    'Ward', 'Cox', 'Diaz', 'Richardson', 'Wood', 'Watson', 'Brooks', 'Bennett', 'Gray', 'James',
    'Reyes', 'Cruz', 'Hughes', 'Price', 'Myers', 'Long', 'Foster', 'Sanders', 'Ross', 'Morales',
    'Powell', 'Sullivan', 'Russell', 'Ortiz', 'Jenkins', 'Gutierrez', 'Perry', 'Butler', 'Barnes', 'Fisher'
  ];
  
  const domains = ['gmail.com', 'outlook.com', 'yahoo.com', 'hotmail.com', 'icloud.com', 'protonmail.com'];
  
  const locations = [
    'London, UK', 'New York, USA', 'Paris, France', 'Berlin, Germany', 'Tokyo, Japan',
    'Sydney, Australia', 'Toronto, Canada', 'Singapore', 'Stockholm, Sweden', 'Barcelona, Spain',
    'Amsterdam, Netherlands', 'Dubai, UAE', 'Hong Kong', 'San Francisco, USA', 'Mumbai, India',
    'Seoul, South Korea', 'Lisbon, Portugal', 'Vienna, Austria', 'Cape Town, South Africa', 'Mexico City, Mexico',
    'Dublin, Ireland', 'Rome, Italy', 'Copenhagen, Denmark', 'Prague, Czech Republic', 'Rio de Janeiro, Brazil'
  ];
  
  const timeZones = getCommonTimeZones();
  
  const bioTemplates = [
    'Experienced remote professional with a focus on [SKILL]. Passionate about [INTEREST] and [INTEREST].',
    'Dedicated [ROLE] with [X] years of experience in remote work. Organized, self-motivated, and detail-oriented.',
    'Results-driven [ROLE] specializing in [SKILL]. Strong communication skills and a proven track record of delivering quality work.',
    'Creative [ROLE] with expertise in [SKILL] and [SKILL]. Looking for challenging remote opportunities.',
    'Adaptable [ROLE] with a background in [SKILL]. Excellent time management skills and comfortable working across time zones.',
    'Seasoned professional with skills in [SKILL] and [SKILL]. Committed to continuous learning and growth.'
  ];
  
  const roles = [
    'Developer', 'Designer', 'Project Manager', 'Content Writer', 'Marketing Specialist',
    'Data Analyst', 'Product Manager', 'QA Engineer', 'UX Researcher', 'DevOps Engineer'
  ];
  
  const interests = [
    'open-source contribution', 'learning new technologies', 'solving complex problems',
    'cross-cultural collaboration', 'process optimization', 'digital nomadism',
    'sustainable technology', 'continuous learning', 'mentoring', 'community building'
  ];
  
  const experiences = ['2', '3', '4', '5', '6', '7', '8', '10+'];
  
  const users = [];
  
  // Generate users
  for (let i = 0; i < 100; i++) {
    const firstName = getRandomItem(firstNames);
    const lastName = getRandomItem(lastNames);
    const username = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${Math.floor(Math.random() * 1000)}`;
    const email = `${username}@${getRandomItem(domains)}`;
    const fullName = `${firstName} ${lastName}`;
    const location = getRandomItem(locations);
    const timeZone = getRandomItem(timeZones).value;
    
    const role = getRandomItem(roles);
    let bio = getRandomItem(bioTemplates)
      .replace('[ROLE]', role)
      .replace('[X]', getRandomItem(experiences));
    
    // Replace [SKILL] placeholders
    const allSkillCategories = getStandardizedSkills();
    const randomCategory = getRandomItem(allSkillCategories);
    const randomSkills = getRandomSubset(randomCategory.skills, 2, 3);
    
    let skillIndex = 0;
    bio = bio.replace(/\[SKILL\]/g, () => randomSkills[skillIndex++ % randomSkills.length]);
    
    // Replace [INTEREST] placeholders
    const randomInterests = getRandomSubset(interests, 2, 2);
    let interestIndex = 0;
    bio = bio.replace(/\[INTEREST\]/g, () => randomInterests[interestIndex++ % randomInterests.length]);
    
    // Add avatar URL
    const avatarUrl = `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName)}&background=random`;
    
    try {
      const password = await hashPassword('password123');
      const userData = {
        username,
        password,
        email,
        fullName,
        location,
        timeZone,
        bio,
        avatarUrl
      };
      
      const user = await storage.createUser(userData);
      users.push(user);
      
      console.log(`Created user ${i+1}/100: ${fullName}`);
      
      // Create user subscription - randomize between free and paid plans
      const planId = Math.floor(Math.random() * 4) + 1; // 1-4 for the plans we created
      
      const now = new Date();
      const startDate = now;
      
      // End date is 1-12 months in the future
      const endDate = new Date(now);
      endDate.setMonth(now.getMonth() + Math.floor(Math.random() * 12) + 1);
      
      await storage.createUserSubscription({
        userId: user.id,
        planId,
        startDate,
        endDate,
        isActive: true,
        searchesUsed: Math.floor(Math.random() * 5),
        applicantViewsUsed: Math.floor(Math.random() * 3)
      });
    } catch (error) {
      console.error(`Error creating user ${username}:`, error);
    }
  }
  
  return users;
}

// Add skills to users
async function addSkillsToUsers() {
  console.log('Adding skills to users...');
  
  // Get all existing users
  const allUsers = await storage.getAllUsers();
  
  // Get all existing skills
  const allSkills = await storage.getAllSkills();
  
  // For each user, add between 3-8 random skills
  for (const user of allUsers) {
    // Get random subset of skills
    const skillsToAdd = getRandomSubset(allSkills, 3, 8);
    
    for (const skill of skillsToAdd) {
      try {
        await storage.addUserSkill({
          userId: user.id,
          skillId: skill.id
        });
      } catch (error) {
        // Ignore duplicate errors
        console.log(`Error adding skill ${skill.name} to user ${user.fullName}`);
      }
    }
    
    console.log(`Added ${skillsToAdd.length} skills to user ${user.fullName}`);
  }
}

// Add availability to users
async function addAvailabilityToUsers() {
  console.log('Adding availability to users...');
  
  // Get all existing users
  const allUsers = await storage.getAllUsers();
  
  // For each user, generate 1-5 availability slots
  for (const user of allUsers) {
    const slots = generateAvailabilitySlots(user.id, Math.floor(Math.random() * 5) + 1);
    
    for (const slot of slots) {
      try {
        await storage.addAvailabilitySlot(slot);
      } catch (error) {
        console.error(`Error adding availability slot for user ${user.fullName}:`, error);
      }
    }
    
    console.log(`Added ${slots.length} availability slots for user ${user.fullName}`);
  }
}

// Generate 100 job postings
async function generateJobs() {
  console.log('Generating jobs...');
  
  const jobTitles = [
    'Frontend Developer', 'Backend Developer', 'Full Stack Developer', 'UI/UX Designer',
    'Product Manager', 'Project Manager', 'Data Scientist', 'DevOps Engineer',
    'Content Writer', 'Digital Marketer', 'SEO Specialist', 'Social Media Manager',
    'Customer Support Representative', 'Virtual Assistant', 'Graphic Designer',
    'Mobile App Developer', 'React Developer', 'Python Developer', 'Java Developer',
    'Technical Writer', 'QA Engineer', 'Systems Administrator', 'Network Engineer',
    'Business Analyst', 'Financial Analyst', 'HR Manager', 'Recruitment Specialist',
    'Sales Representative', 'Account Manager', 'Community Manager'
  ];
  
  const companyNames = [
    'Innovatech Solutions', 'Digital Dynamics', 'Global Connect', 'TechSphere',
    'Horizon Innovations', 'NextGen Systems', 'CloudWave Technologies', 'PrimeCore Software',
    'BlueScale Solutions', 'Elevate Digital', 'FutureWorks', 'Smart Systems',
    'Vertex Solutions', 'Quantum Technologies', 'Zephyr Innovations', 'Pixel Perfect',
    'Alliance Global', 'Spectrum Enterprises', 'Phoenix Solutions', 'Apex Technologies',
    'Emerald Systems', 'Catalyst Technologies', 'Synergy Solutions', 'Fusion Labs',
    'Helix Software', 'Matrix Solutions', 'Radiant Technologies', 'Eclipse Systems',
    'Nova Innovations', 'Velocity Technologies'
  ];
  
  const jobTypes = ['Full-time', 'Part-time', 'Contract', 'Freelance'];
  
  const salaryRanges = [
    '£30,000 - £40,000', '£40,000 - £50,000', '£50,000 - £60,000', '£60,000 - £70,000',
    '£70,000 - £80,000', '£80,000 - £90,000', '£90,000 - £100,000', '£100,000+',
    '$30,000 - $40,000', '$40,000 - $50,000', '$50,000 - $60,000', '$60,000 - $70,000',
    '$70,000 - $80,000', '$80,000 - $90,000', '$90,000 - $100,000', '$100,000+',
    '€30,000 - €40,000', '€40,000 - €50,000', '€50,000 - €60,000', '€60,000 - €70,000',
    '€70,000 - €80,000', '€80,000 - €90,000', '€90,000 - €100,000', '€100,000+'
  ];
  
  const timeZoneRequirements = [
    'Must overlap with EST business hours',
    'European time zones preferred',
    'Asia-Pacific time zones preferred',
    'Must have at least 4 hours overlap with GMT',
    'Any time zone, flexible working hours',
    'Must be available during 9 AM - 5 PM GMT',
    'Must be available during 9 AM - 5 PM EST',
    'Must be available during 9 AM - 5 PM PST',
    'Flexible working hours, but must attend team meetings',
    null
  ];
  
  const descriptionTemplates = [
    `We are looking for an experienced [TITLE] to join our remote team. The ideal candidate will have strong skills in [SKILL] and [SKILL], with at least [X]+ years of experience in [INDUSTRY].

Responsibilities:
- [RESPONSIBILITY]
- [RESPONSIBILITY]
- [RESPONSIBILITY]

Requirements:
- Proven experience in [TITLE] role
- Excellent knowledge of [SKILL]
- Strong understanding of [SKILL]
- Bachelor's degree in related field preferred
- Excellent written and verbal communication skills
- Self-motivated and able to work independently`,

    `Our company is seeking a talented [TITLE] to work remotely with our international team. You will be responsible for [RESPONSIBILITY] and [RESPONSIBILITY].

Key Skills Required:
- [SKILL]
- [SKILL]
- [SKILL]

What We Offer:
- Competitive salary: [SALARY]
- Flexible working hours
- Professional development opportunities
- Collaborative and innovative work environment`,

    `[TITLE] Needed - Remote Position

About the Role:
We're looking for a [TITLE] to help us [RESPONSIBILITY]. The ideal candidate should have experience with [SKILL] and [SKILL].

What You'll Do:
- [RESPONSIBILITY]
- [RESPONSIBILITY]
- Collaborate with cross-functional teams

What You Need:
- [X]+ years of experience in [INDUSTRY]
- Strong proficiency in [SKILL]
- Excellent communication skills
- Ability to work independently and as part of a team`
  ];
  
  const responsibilities = [
    'Develop and maintain web applications',
    'Design user interfaces and experiences',
    'Create content for various platforms',
    'Manage digital marketing campaigns',
    'Analyze data and provide insights',
    'Lead and manage project teams',
    'Provide customer support',
    'Develop and execute marketing strategies',
    'Optimize system performance',
    'Ensure software quality through testing',
    'Manage client relationships',
    'Create and implement business strategies',
    'Develop mobile applications',
    'Coordinate with stakeholders',
    'Build and maintain databases',
    'Create technical documentation',
    'Develop and maintain APIs',
    'Design and implement system architecture',
    'Create and maintain cloud infrastructure',
    'Optimize SEO for websites'
  ];
  
  const industries = [
    'software development', 'e-commerce', 'healthcare', 'finance',
    'education', 'media', 'marketing', 'technology', 'retail',
    'manufacturing', 'hospitality', 'telecommunications', 'consulting'
  ];
  
  // Get all existing users and skills
  const allUsers = await storage.getAllUsers();
  const allSkills = await storage.getAllSkills();
  
  for (let i = 0; i < 100; i++) {
    // Choose a random employer from existing users
    const employer = getRandomItem(allUsers);
    
    // Choose a random job title
    const title = getRandomItem(jobTitles);
    
    // Choose 3-6 random skills for the job
    const requiredSkills = getRandomSubset(allSkills, 3, 6).map(skill => skill.id);
    
    // Generate description
    let description = getRandomItem(descriptionTemplates);
    description = description.replace(/\[TITLE\]/g, title);
    
    // Replace SKILL placeholders with actual skills
    const skillNames = allSkills
      .filter(skill => requiredSkills.includes(skill.id))
      .map(skill => skill.name);
    
    let skillIndex = 0;
    description = description.replace(/\[SKILL\]/g, () => {
      return skillNames[skillIndex++ % skillNames.length];
    });
    
    // Replace other placeholders
    description = description
      .replace(/\[X\]/g, getRandomItem(['2', '3', '4', '5']))
      .replace(/\[INDUSTRY\]/g, getRandomItem(industries))
      .replace(/\[SALARY\]/g, getRandomItem(salaryRanges));
    
    // Replace RESPONSIBILITY placeholders
    const jobResponsibilities = getRandomSubset(responsibilities, 3, 3);
    let respIndex = 0;
    description = description.replace(/\[RESPONSIBILITY\]/g, () => {
      return jobResponsibilities[respIndex++ % jobResponsibilities.length];
    });
    
    // Generate job data
    const jobData = {
      title,
      employerId: employer.id,
      companyName: getRandomItem(companyNames),
      description,
      hoursPerWeek: Math.floor(Math.random() * 30) + 10, // 10-40 hours
      minHoursPerWeek: Math.floor(Math.random() * 10) + 5, // 5-15 hours
      maxHoursPerWeek: Math.floor(Math.random() * 25) + 15, // 15-40 hours
      timeZoneRequirements: getRandomItem(timeZoneRequirements),
      timeZoneOverlap: (Math.floor(Math.random() * 8) + 2).toString(), // 2-10 hours
      salary: getRandomItem(salaryRanges),
      jobType: getRandomItem(jobTypes),
      location: 'Remote',
      requiredSkills
    };
    
    try {
      await storage.createJob(jobData);
      console.log(`Created job ${i+1}/100: ${title}`);
    } catch (error) {
      console.error(`Error creating job ${title}:`, error);
    }
  }
}

// Generate job applications
async function generateJobApplications() {
  console.log('Generating job applications...');
  
  // Get all existing users and jobs
  const allUsers = await storage.getAllUsers();
  const allJobs = await storage.getAllJobs();
  
  // Each user applies to 0-5 random jobs
  for (const user of allUsers) {
    // Skip applications for 30% of users
    if (Math.random() < 0.3) continue;
    
    // Get jobs that this user didn't create
    const applicableJobs = allJobs.filter(job => job.employerId !== user.id);
    
    // Apply to 1-5 random jobs
    const jobsToApply = getRandomSubset(applicableJobs, 0, 5);
    
    for (const job of jobsToApply) {
      const applicationData = {
        jobId: job.id,
        jobseekerId: user.id,
        message: `I'm very interested in this ${job.title} position. With my experience in ${job.requiredSkills.length > 0 ? 'the required skills' : 'this field'}, I believe I would be a great fit for the role.`,
        status: getRandomItem(['pending', 'reviewing', 'accepted', 'rejected'])
      };
      
      try {
        await storage.createJobApplication(applicationData);
        console.log(`Created job application: ${user.fullName} for ${job.title}`);
      } catch (error) {
        console.error(`Error creating job application:`, error);
      }
    }
  }
}

// Main function to orchestrate the mock data generation
async function generateMockData() {
  try {
    await generateSubscriptionPlans();
    await generateSkills();
    const users = await generateUsers();
    await addSkillsToUsers();
    await addAvailabilityToUsers();
    await generateJobs();
    await generateJobApplications();
    
    console.log('Mock data generation completed successfully!');
  } catch (error) {
    console.error('Error generating mock data:', error);
  }
}

// Run the generator
generateMockData();