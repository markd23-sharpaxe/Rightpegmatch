#!/bin/bash
npx tsx scripts/generate-mock-data.ts