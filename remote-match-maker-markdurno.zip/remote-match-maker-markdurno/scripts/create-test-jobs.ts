/**
 * This script creates test job posts with various skillsets and availability requirements
 * to demonstrate the matching functionality.
 */

import { storage } from "../server/storage";
import { InsertJob } from "../shared/schema";

// Helper to create job data with different attributes
async function createTestJob(jobData: InsertJob) {
  try {
    const job = await storage.createJob(jobData);
    console.log(`Created job: ${job.title} (ID: ${job.id})`);
    return job;
  } catch (error) {
    console.error(`Failed to create job '${jobData.title}':`, error);
    return null;
  }
}

async function main() {
  try {
    console.log("Starting to create test jobs...");
    
    // First get all available job roles and skills to use
    const jobRoles = await storage.getAllJobRoles();
    if (jobRoles.length === 0) {
      console.error("No job roles found in the database. Please seed job roles first.");
      return;
    }
    
    const skills = await storage.getAllSkills();
    if (skills.length === 0) {
      console.error("No skills found in the database. Please seed skills first.");
      return;
    }
    
    console.log(`Found ${jobRoles.length} job roles and ${skills.length} skills.`);
    
    // Job 1: Full-stack developer with specific time requirements
    await createTestJob({
      title: "Remote Full-stack Developer",
      employerId: 1, // Assuming user ID 1 exists as an employer
      companyName: "TechSolutions Inc.",
      location: "Remote",
      jobRoleId: jobRoles.find(role => role.name.includes("Developer") || role.name.includes("Engineer"))?.id || 1,
      hourlyRate: "$40-60",
      salary: "$80,000-120,000",
      description: "We're looking for a skilled full-stack developer to join our remote team. Experience with React and Node.js required.",
      requiredSkills: skills.filter(s => 
        ["JavaScript", "React", "Node.js", "TypeScript"].some(name => 
          s.name.toLowerCase().includes(name.toLowerCase())
        )
      ).map(s => s.id),
      requiredAvailability: [
        { dayOfWeek: 1, startHour: 9, endHour: 17, timeZone: "GMT+0" },
        { dayOfWeek: 2, startHour: 9, endHour: 17, timeZone: "GMT+0" },
        { dayOfWeek: 3, startHour: 9, endHour: 17, timeZone: "GMT+0" },
        { dayOfWeek: 4, startHour: 9, endHour: 17, timeZone: "GMT+0" },
        { dayOfWeek: 5, startHour: 9, endHour: 17, timeZone: "GMT+0" }
      ],
      timeZoneOverlap: ["GMT-8", "GMT-5", "GMT+0", "GMT+1", "GMT+2"],
      jobType: "Full-time",
      hoursPerWeek: 40
    });
    
    // Job 2: UX/UI Designer with flexible hours
    await createTestJob({
      title: "UX/UI Designer - Flexible Hours",
      employerId: 1,
      companyName: "CreativeMinds Studio",
      location: "Remote",
      jobRoleId: jobRoles.find(role => role.name.includes("Design"))?.id || 2,
      hourlyRate: "$30-45",
      description: "Join our creative team to design beautiful and intuitive interfaces. Experience with Figma and user research required.",
      requiredSkills: skills.filter(s => 
        ["Figma", "UI", "UX", "Design", "Sketch"].some(name => 
          s.name.toLowerCase().includes(name.toLowerCase())
        )
      ).map(s => s.id),
      requiredAvailability: [
        { dayOfWeek: 1, startHour: 12, endHour: 16, timeZone: "GMT+0" },
        { dayOfWeek: 3, startHour: 12, endHour: 16, timeZone: "GMT+0" },
        { dayOfWeek: 5, startHour: 12, endHour: 16, timeZone: "GMT+0" }
      ],
      timeZoneOverlap: ["GMT-8", "GMT-5", "GMT+0", "GMT+1", "GMT+2"],
      jobType: "Part-time",
      hoursPerWeek: 20
    });
    
    // Job 3: Project Manager for Asian time zones
    await createTestJob({
      title: "Project Manager for APAC Region",
      employerId: 1,
      companyName: "Global Innovations Ltd.",
      location: "Remote - Asia Pacific",
      jobRoleId: jobRoles.find(role => role.name.includes("Manager") || role.name.includes("Project"))?.id || 3,
      salary: "$90,000-130,000",
      description: "Managing software development projects for our APAC clients. Experience with agile methodologies and team leadership required.",
      requiredSkills: skills.filter(s => 
        ["Project Management", "Agile", "Scrum", "Leadership", "JIRA"].some(name => 
          s.name.toLowerCase().includes(name.toLowerCase())
        )
      ).map(s => s.id),
      requiredAvailability: [
        { dayOfWeek: 1, startHour: 1, endHour: 9, timeZone: "GMT+0" },
        { dayOfWeek: 2, startHour: 1, endHour: 9, timeZone: "GMT+0" },
        { dayOfWeek: 3, startHour: 1, endHour: 9, timeZone: "GMT+0" },
        { dayOfWeek: 4, startHour: 1, endHour: 9, timeZone: "GMT+0" },
        { dayOfWeek: 5, startHour: 1, endHour: 9, timeZone: "GMT+0" }
      ],
      timeZoneOverlap: ["GMT+8", "GMT+9", "GMT+10"],
      jobType: "Full-time",
      hoursPerWeek: 40
    });
    
    // Job 4: Data Scientist (weekend hours)
    await createTestJob({
      title: "Weekend Data Analyst",
      employerId: 1,
      companyName: "DataInsight Analytics",
      location: "Remote",
      jobRoleId: jobRoles.find(role => role.name.includes("Data") || role.name.includes("Analyst"))?.id || 4,
      hourlyRate: "$50-70",
      description: "Analyze customer data during weekend hours to provide insights for our marketing team. Experience with Python and data visualization required.",
      requiredSkills: skills.filter(s => 
        ["Python", "Data", "Analysis", "SQL", "Tableau"].some(name => 
          s.name.toLowerCase().includes(name.toLowerCase())
        )
      ).map(s => s.id),
      requiredAvailability: [
        { dayOfWeek: 6, startHour: 9, endHour: 17, timeZone: "GMT+0" },
        { dayOfWeek: 0, startHour: 9, endHour: 17, timeZone: "GMT+0" }
      ],
      timeZoneOverlap: ["GMT-8", "GMT-5", "GMT+0", "GMT+1"],
      jobType: "Part-time",
      hoursPerWeek: 16
    });
    
    // Job 5: DevOps Engineer (overnight shifts)
    await createTestJob({
      title: "Night Shift DevOps Engineer",
      employerId: 1,
      companyName: "CloudScale Solutions",
      location: "Remote",
      jobRoleId: jobRoles.find(role => role.name.includes("DevOps") || role.name.includes("Engineer"))?.id || 5,
      salary: "$95,000-140,000",
      description: "Manage our cloud infrastructure during overnight hours. Experience with AWS, Kubernetes, and CI/CD pipelines required.",
      requiredSkills: skills.filter(s => 
        ["AWS", "Kubernetes", "Docker", "DevOps", "CI/CD"].some(name => 
          s.name.toLowerCase().includes(name.toLowerCase())
        )
      ).map(s => s.id),
      requiredAvailability: [
        { dayOfWeek: 1, startHour: 22, endHour: 6, timeZone: "GMT+0" },
        { dayOfWeek: 2, startHour: 22, endHour: 6, timeZone: "GMT+0" },
        { dayOfWeek: 3, startHour: 22, endHour: 6, timeZone: "GMT+0" },
        { dayOfWeek: 4, startHour: 22, endHour: 6, timeZone: "GMT+0" },
        { dayOfWeek: 5, startHour: 22, endHour: 6, timeZone: "GMT+0" }
      ],
      timeZoneOverlap: ["GMT-8", "GMT+8", "GMT+9"],
      jobType: "Full-time",
      hoursPerWeek: 40
    });
    
    console.log("Test jobs created successfully!");
    
  } catch (error) {
    console.error("Error creating test jobs:", error);
  } finally {
    process.exit(0);
  }
}

main();