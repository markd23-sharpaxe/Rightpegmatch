/**
 * Script to generate test data for end-to-end testing
 * 
 * This script:
 * 1. Removes all existing users, jobs, and related data
 * 2. Creates 4 test users with usernames test1-test4 and password testing123
 * 3. Generates 1000 realistic job postings with various requirements
 * 4. Sets up matching user profiles with relevant skills
 */

import { db } from "../server/db";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import {
  users, jobs, userSkills, skills, jobRoles, userJobRoles,
  availabilitySlots, jobApplications, messages, jobMatchesCache,
  subscriptionPlans, userSubscriptions, directMessages, jobRequiredSkills,
  JobFamily, SalaryType, StartDateFlexibilityType,
  InsertUser, InsertJob, InsertSkill, InsertJobRole, InsertUserSkill,
  InsertUserJobRole, InsertAvailabilitySlot, JobAvailabilityRequirement
} from "../shared/schema";
import { sql } from "drizzle-orm";

const scryptAsync = promisify(scrypt);

// Skills by job family for realistic job and profile creation
const skillsByJobFamily: Record<JobFamily, string[]> = {
  [JobFamily.ProjectManagement]: [
    "Agile", "Scrum", "Kanban", "JIRA", "Project Planning", "Risk Management", 
    "Stakeholder Management", "PMP", "Budgeting", "MS Project", "Team Leadership",
    "Resource Allocation"
  ],
  [JobFamily.SoftwareDevelopment]: [
    "JavaScript", "TypeScript", "React", "Node.js", "Python", "Java", "C#", 
    "SQL", "NoSQL", "AWS", "Azure", "Docker", "Kubernetes", "Git", "CI/CD",
    "REST API", "GraphQL", "MongoDB", "PostgreSQL", "Redis", "Vue.js", "Angular",
    "Next.js", "Django", "Flask", "Spring Boot", "ASP.NET", "Ruby on Rails"
  ],
  [JobFamily.Design]: [
    "UI Design", "UX Design", "Figma", "Adobe XD", "Sketch", "Photoshop", 
    "Illustrator", "InDesign", "User Research", "Wireframing", "Prototyping",
    "Typography", "Color Theory", "Responsive Design", "Accessibility"
  ],
  [JobFamily.Sales]: [
    "Sales Strategy", "B2B Sales", "B2C Sales", "CRM", "Salesforce", "Lead Generation",
    "Account Management", "Negotiation", "Closing Techniques", "Pipeline Management",
    "Customer Acquisition", "Sales Analytics", "Sales Presentation"
  ],
  [JobFamily.Marketing]: [
    "Digital Marketing", "Content Marketing", "SEO", "SEM", "Social Media Marketing",
    "Email Marketing", "Marketing Analytics", "Google Analytics", "Facebook Ads",
    "Google Ads", "Campaign Management", "Brand Management", "Market Research",
    "Marketing Strategy", "Growth Hacking", "Copywriting"
  ],
  [JobFamily.CustomerSupport]: [
    "Customer Service", "Help Desk", "Zendesk", "Intercom", "Freshdesk", "Live Chat",
    "Complaint Resolution", "Technical Support", "Customer Relationship Management",
    "Call Center Management", "Customer Satisfaction Metrics", "Support Ticketing"
  ],
  [JobFamily.Finance]: [
    "Financial Analysis", "Accounting", "Budgeting", "QuickBooks", "Financial Reporting",
    "Forecasting", "Financial Modeling", "Excel", "Risk Assessment", "Tax Compliance",
    "Investment Analysis", "Cost Accounting", "Financial Planning", "Bookkeeping"
  ],
  [JobFamily.HumanResources]: [
    "Recruitment", "Talent Acquisition", "Employee Relations", "Performance Management",
    "Compensation & Benefits", "HRIS", "Training & Development", "Workforce Planning",
    "Compliance", "Employee Engagement", "Diversity & Inclusion", "HR Analytics",
    "Onboarding", "Succession Planning", "HR Policy"
  ],
  [JobFamily.Executive]: [
    "Strategic Planning", "Leadership", "Business Development", "Executive Management",
    "Board Relations", "Corporate Governance", "Change Management", "Organizational Development",
    "P&L Management", "Vision Setting", "Mergers & Acquisitions", "Strategic Partnerships"
  ],
  [JobFamily.Operations]: [
    "Operations Management", "Supply Chain", "Logistics", "Inventory Management",
    "Process Improvement", "Vendor Management", "Quality Control", "Six Sigma",
    "Lean Methodology", "Facilities Management", "Production Planning", "Procurement"
  ],
  [JobFamily.DataAnalysis]: [
    "Data Analysis", "SQL", "Python", "R", "Tableau", "Power BI", "Excel",
    "Data Visualization", "Statistical Analysis", "Big Data", "Data Mining",
    "Machine Learning", "Predictive Analytics", "A/B Testing", "Data Modeling",
    "ETL", "Data Warehousing", "Business Intelligence"
  ],
  [JobFamily.Other]: [
    "Communication", "Time Management", "Problem Solving", "Critical Thinking",
    "Adaptability", "Creativity", "Teamwork", "Public Speaking", "Writing",
    "Research", "Analytical Skills", "Decision Making", "Conflict Resolution",
    "Active Listening", "Emotional Intelligence", "Stress Management"
  ]
};

// Example job roles by family
const rolesByJobFamily: Record<JobFamily, string[]> = {
  [JobFamily.ProjectManagement]: [
    "Project Manager", "Program Manager", "Project Coordinator", "Scrum Master", 
    "Product Owner", "Agile Coach", "Project Management Officer", "Delivery Manager"
  ],
  [JobFamily.SoftwareDevelopment]: [
    "Software Engineer", "Full Stack Developer", "Frontend Developer", "Backend Developer",
    "Mobile Developer", "DevOps Engineer", "QA Engineer", "Site Reliability Engineer",
    "Data Engineer", "Cloud Engineer", "Embedded Systems Developer", "Game Developer"
  ],
  [JobFamily.Design]: [
    "UI Designer", "UX Designer", "Product Designer", "Graphic Designer", 
    "Web Designer", "Interaction Designer", "Visual Designer", "Brand Designer",
    "UI/UX Designer", "User Researcher", "UX Researcher", "Creative Director"
  ],
  [JobFamily.Sales]: [
    "Sales Representative", "Account Executive", "Sales Manager", "Business Development Representative", 
    "Sales Director", "Inside Sales Representative", "Field Sales Representative", "Sales Operations Manager"
  ],
  [JobFamily.Marketing]: [
    "Marketing Manager", "Digital Marketing Specialist", "Content Marketer", "SEO Specialist", 
    "Social Media Manager", "Marketing Analyst", "Brand Manager", "Growth Marketer",
    "Email Marketing Specialist", "Marketing Coordinator", "Product Marketing Manager"
  ],
  [JobFamily.CustomerSupport]: [
    "Customer Support Representative", "Customer Success Manager", "Technical Support Specialist", 
    "Customer Experience Manager", "Support Engineer", "Customer Service Agent", "Help Desk Analyst"
  ],
  [JobFamily.Finance]: [
    "Financial Analyst", "Accountant", "Financial Controller", "Treasury Analyst", 
    "Financial Planner", "Bookkeeper", "Financial Manager", "Finance Director",
    "FP&A Analyst", "Tax Specialist", "Payroll Specialist", "Audit Manager"
  ],
  [JobFamily.HumanResources]: [
    "HR Manager", "Recruiter", "Talent Acquisition Specialist", "HR Business Partner", 
    "Compensation Analyst", "Training Specialist", "HR Generalist", "Benefits Administrator",
    "HR Director", "Employee Relations Specialist", "HRIS Analyst"
  ],
  [JobFamily.Executive]: [
    "Chief Executive Officer", "Chief Operating Officer", "Chief Financial Officer", 
    "Chief Technology Officer", "Chief Marketing Officer", "Chief Product Officer",
    "President", "Vice President", "Director", "Managing Director", "General Manager"
  ],
  [JobFamily.Operations]: [
    "Operations Manager", "Supply Chain Manager", "Logistics Coordinator", "Procurement Specialist", 
    "Inventory Manager", "Operations Analyst", "Facilities Manager", "Production Manager"
  ],
  [JobFamily.DataAnalysis]: [
    "Data Analyst", "Business Intelligence Analyst", "Data Scientist", "Analytics Manager", 
    "Reporting Analyst", "Business Analyst", "Quantitative Analyst", "Research Analyst"
  ],
  [JobFamily.Other]: [
    "Consultant", "Freelancer", "Researcher", "Administrative Assistant", "Virtual Assistant", 
    "Teacher", "Writer", "Content Creator", "Editor", "Translator", "Legal Counsel", "Architect"
  ]
};

// Common languages for jobs and profiles
const languages = [
  "English", "Spanish", "French", "German", "Chinese", "Japanese", "Russian", 
  "Portuguese", "Italian", "Arabic", "Hindi", "Dutch", "Swedish", "Korean"
];

// Company names for job listings
const companyNames = [
  "TechNova Solutions", "Global Innovations Group", "NextGen Systems", "Horizon Analytics",
  "Blue Ocean Consulting", "CloudSphere Technologies", "Apex Digital Ventures", "Quantum Leap Networks",
  "Pinnacle Solutions", "Stellar Systems", "Catalyst Dynamics", "Fusion Technologies",
  "Prism Solutions", "Emerge Digital", "Traverse Industries", "Nexus Innovations",
  "Vertex Systems", "Elevate Technologies", "Spark Analytics", "Pulse Dynamics",
  "Echo Technologies", "Vanguard Solutions", "Mosaic Digital", "Zenith Systems",
  "Orbit Innovations", "Summit Technologies", "Spectrum Solutions", "Beacon Consulting",
  "Phoenix Technologies", "Axiom Solutions", "Everest Innovations", "Meridian Systems"
];

// Time zones for availability
const timeZones = [
  "GMT+0", "GMT-5", "GMT-8", "GMT+1", "GMT+2", "GMT+3", "GMT+5:30", "GMT+8", "GMT+9", "GMT+10"
];

// Currency options
const currencies = ["USD", "EUR", "GBP", "CAD", "AUD", "JPY"];

// Salary types
const salaryTypes: SalaryType[] = ["hourly", "weekly", "monthly", "yearly"];

// Start date flexibility options
const startDateFlexibilityOptions: StartDateFlexibilityType[] = ["exact", "month", "immediate"];

/**
 * Hash a password using scrypt
 */
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

/**
 * Generate a random integer between min and max (inclusive)
 */
function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Select a random item from an array
 */
function getRandomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Select a random subset of items from an array
 */
function getRandomSubset<T>(arr: T[], min: number, max: number): T[] {
  const count = getRandomInt(min, Math.min(max, arr.length));
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

/**
 * Generate a random date within a range
 */
function getRandomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

/**
 * Generate random availability slots for a user or job
 */
function generateAvailabilitySlots(count: number): JobAvailabilityRequirement[] {
  const slots = [];
  const days = [1, 2, 3, 4, 5]; // Monday to Friday
  
  // Generate random availability slots
  for (let i = 0; i < count; i++) {
    const dayOfWeek = getRandomItem(days);
    const startHour = getRandomInt(8, 16); // 8 AM to 4 PM
    const endHour = getRandomInt(startHour + 1, Math.min(startHour + 8, 23)); // End 1-8 hours after start
    const timeZone = getRandomItem(timeZones);
    
    slots.push({
      dayOfWeek,
      startHour,
      endHour,
      timeZone
    });
  }
  
  return slots;
}

/**
 * Clear all existing data from the database
 */
async function clearDatabase() {
  console.log("Clearing existing data...");
  
  // Delete data from tables in reverse order of dependencies
  await db.delete(directMessages);
  await db.delete(messages);
  await db.delete(jobMatchesCache);
  await db.delete(jobApplications);
  await db.delete(userSubscriptions);
  await db.delete(availabilitySlots);
  await db.delete(userSkills);
  await db.delete(userJobRoles);
  await db.delete(jobRequiredSkills);
  await db.delete(jobs);
  await db.delete(users);
  await db.delete(skills);
  await db.delete(jobRoles);
  
  console.log("Database cleared successfully");
}

/**
 * Create subscription plans if they don't exist
 */
async function createSubscriptionPlans() {
  console.log("Setting up subscription plans...");
  
  // Check if subscription plans already exist
  const existingPlans = await db.select().from(subscriptionPlans);
  
  if (existingPlans.length > 0) {
    console.log(`${existingPlans.length} subscription plan(s) already exist`);
    return;
  }
  
  // Otherwise, create the plans - make sure it matches the DB schema
  await db.insert(subscriptionPlans).values([
    {
      name: "Basic",
      description: "View applications for a single job posting",
      price: "999", // £9.99
      maxSearches: 0,
      maxApplicantViews: 50,
      isUnlimited: false
    },
    {
      name: "Professional",
      description: "View applications across all posted jobs",
      price: "2999", // £29.99
      maxSearches: 0,
      maxApplicantViews: 9999, // Using a high number instead of null
      isUnlimited: false
    },
    {
      name: "Recruiter",
      description: "Full access including talent database search",
      price: "19999", // £199.99
      maxSearches: 9999, // Using a high number instead of null
      maxApplicantViews: 9999, // Using a high number instead of null
      isUnlimited: true
    }
  ]);
  
  console.log("Subscription plans created successfully");
}

/**
 * Create skills in the database
 */
async function createSkills() {
  console.log("Creating skills...");
  
  // Collect all skills from all job families
  const allSkills = new Set<string>();
  Object.values(skillsByJobFamily).forEach(familySkills => {
    familySkills.forEach(skill => allSkills.add(skill));
  });
  
  // Insert all skills
  const skillsToInsert: InsertSkill[] = [...allSkills].map(name => ({ name }));
  await db.insert(skills).values(skillsToInsert);
  
  console.log(`Created ${skillsToInsert.length} skills`);
}

/**
 * Create job roles in the database
 */
async function createJobRoles() {
  console.log("Creating job roles...");
  
  // Collect job roles
  const jobRolesToInsert: InsertJobRole[] = [];
  
  Object.entries(rolesByJobFamily).forEach(([family, roles]) => {
    roles.forEach(name => {
      jobRolesToInsert.push({
        name,
        jobFamily: family as JobFamily
      });
    });
  });
  
  // Insert all job roles
  await db.insert(jobRoles).values(jobRolesToInsert);
  
  console.log(`Created ${jobRolesToInsert.length} job roles`);
}

/**
 * Create test users with specified credentials
 */
async function createTestUsers() {
  console.log("Creating test users...");
  
  const hashedPassword = await hashPassword("testing123");
  
  // Create 4 test users
  for (let i = 1; i <= 4; i++) {
    const username = `test${i}`;
    const email = `test${i}@example.com`;
    
    const userData: InsertUser = {
      username,
      email,
      password: hashedPassword,
      fullName: `Test User ${i}`,
      bio: `This is a test user account for end-to-end testing. User ID: ${i}`,
      location: getRandomItem(["Remote", "London, UK", "New York, USA", "Berlin, Germany", "Sydney, Australia"]),
      avatarUrl: `https://ui-avatars.com/api/?name=Test+${i}&background=random`,
      preferredHoursPerWeek: getRandomInt(10, 40)
    };
    
    // Insert user
    const [user] = await db.insert(users).values(userData).returning();
    console.log(`Created test user: ${username} (ID: ${user.id})`);
  }
  
  console.log("Test users created successfully");
}

/**
 * Set up user profiles with skills, job roles, and availability
 */
async function setupUserProfiles() {
  console.log("Setting up user profiles...");
  
  // Get all users, skills, and job roles
  const allUsers = await db.select().from(users);
  const allSkills = await db.select().from(skills);
  const allJobRoles = await db.select().from(jobRoles);
  
  // Map to keep track of skill IDs by name for quick lookup
  const skillMap = new Map(allSkills.map(skill => [skill.name, skill.id]));
  
  // For each user, set up a complete profile
  for (const user of allUsers) {
    // 1. Assign job roles (1-3 roles per user, one as primary)
    const jobFamily = getRandomItem(Object.values(JobFamily));
    const relevantJobRoles = allJobRoles.filter(role => role.jobFamily === jobFamily);
    const selectedRoles = getRandomSubset(relevantJobRoles, 1, 3);
    
    // Insert primary job role first
    const primaryRole = selectedRoles[0];
    const userJobRoleData: InsertUserJobRole = {
      userId: user.id,
      jobRoleId: primaryRole.id,
      isPrimary: true
    };
    await db.insert(userJobRoles).values(userJobRoleData);
    
    // Insert additional roles if any
    if (selectedRoles.length > 1) {
      for (let i = 1; i < selectedRoles.length; i++) {
        await db.insert(userJobRoles).values({
          userId: user.id,
          jobRoleId: selectedRoles[i].id,
          isPrimary: false
        });
      }
    }
    
    // 2. Assign skills (5-15 skills per user)
    // Get skills in the user's job family
    const familySkills = skillsByJobFamily[jobFamily] || [];
    const relevantSkillIds = familySkills
      .filter(skillName => skillMap.has(skillName))
      .map(skillName => skillMap.get(skillName)!);
    
    // Add some general skills from "Other" category
    const generalSkills = skillsByJobFamily[JobFamily.Other] || [];
    const generalSkillIds = generalSkills
      .filter(skillName => skillMap.has(skillName))
      .map(skillName => skillMap.get(skillName)!);
    
    // Combine and select random subset
    const allRelevantSkillIds = [...new Set([...relevantSkillIds, ...generalSkillIds])];
    const selectedSkills = getRandomSubset(allRelevantSkillIds, 5, 15);
    
    // Insert skills
    for (const skillId of selectedSkills) {
      const userSkillData: InsertUserSkill = {
        userId: user.id,
        skillId
      };
      await db.insert(userSkills).values(userSkillData);
    }
    
    // 3. Set up availability (2-5 slots per user)
    const availabilityCount = getRandomInt(2, 5);
    const slots = generateAvailabilitySlots(availabilityCount);
    
    for (const slot of slots) {
      const availabilityData: InsertAvailabilitySlot = {
        userId: user.id,
        dayOfWeek: slot.dayOfWeek,
        startHour: slot.startHour,
        endHour: slot.endHour,
        timeZone: slot.timeZone
      };
      await db.insert(availabilitySlots).values(availabilityData);
    }
  }
  
  console.log("User profiles set up successfully");
}

/**
 * Generate 1000 realistic job postings
 */
async function createJobPostings() {
  console.log("Creating job postings...");
  
  // Get all users to assign as job creators
  const allUsers = await db.select().from(users);
  
  // Get all job roles and skills for reference
  const allJobRoles = await db.select().from(jobRoles);
  const allSkills = await db.select().from(skills);
  
  // Map to keep track of skill IDs by name for quick lookup
  const skillMap = new Map(allSkills.map(skill => [skill.name, skill.id]));
  
  // Create 100 job postings instead of 1000 to avoid timeout
  const totalJobs = 100;
  const batchSize = 20; // Smaller batch size to avoid memory issues
  
  for (let batchStart = 0; batchStart < totalJobs; batchStart += batchSize) {
    const endIndex = Math.min(batchStart + batchSize, totalJobs);
    console.log(`Creating jobs ${batchStart + 1} to ${endIndex}...`);
    
    const jobBatch = [];
    
    for (let i = batchStart; i < endIndex; i++) {
      // Select random job role
      const jobRole = getRandomItem(allJobRoles);
      const jobFamily = jobRole.jobFamily;
      
      // Select random employer
      const employer = getRandomItem(allUsers);
      
      // Generate random date range for the job
      const now = new Date();
      const futureDate = new Date();
      futureDate.setMonth(now.getMonth() + 6);
      
      // Randomly decide if job is permanent
      const isPermanent = Math.random() > 0.6; // 40% chance of being a contract job
      
      // Generate availability slots
      const availabilitySlots = generateAvailabilitySlots(getRandomInt(1, 3));
      
      // Set up job data
      // Format dates correctly to avoid TypeScript errors
      const startDate = getRandomDate(now, new Date(now.getTime() + 90 * 24 * 60 * 60 * 1000));
      const endDate = isPermanent ? undefined : getRandomDate(futureDate, new Date(futureDate.getTime() + 180 * 24 * 60 * 60 * 1000));
      
      const jobData: InsertJob = {
        title: `${jobRole.name} at ${getRandomItem(companyNames)}`,
        employerId: employer.id,
        companyName: getRandomItem(companyNames),
        jobRoleId: jobRole.id,
        hoursPerWeek: getRandomInt(10, 40),
        salaryAmount: getRandomInt(20, 100).toString(),
        salaryType: getRandomItem(salaryTypes),
        currency: getRandomItem(currencies),
        requiredLanguages: getRandomSubset(languages, 1, 3).join(", "),
        requiredAvailability: availabilitySlots,
        jobFamily: jobRole.jobFamily,
        description: generateJobDescription(jobRole.name, jobFamily),
        location: "Remote",
        
        // Job term fields
        startDate, 
        endDate,
        startDateFlexibility: getRandomItem(startDateFlexibilityOptions),
        isPermanent
      };
      
      jobBatch.push(jobData);
    }
    
    // Insert batch of jobs
    const insertedJobs = await db.insert(jobs).values(jobBatch).returning({ id: jobs.id, jobRoleId: jobs.jobRoleId });
    
    // Now add required skills for each job
    for (const job of insertedJobs) {
      // Find the job role for this job
      const jobRole = allJobRoles.find(role => role.id === job.jobRoleId);
      if (!jobRole) continue;
      
      // Get skills in the job's family
      const familySkills = skillsByJobFamily[jobRole.jobFamily] || [];
      const relevantSkillIds = familySkills
        .filter(skillName => skillMap.has(skillName))
        .map(skillName => skillMap.get(skillName)!);
      
      // Select 2-4 skills for this job (reduced for faster execution)
      const selectedSkillIds = getRandomSubset(relevantSkillIds, 2, 4);
      
      // Add required skills one by one to avoid complex SQL generation
      if (selectedSkillIds.length > 0) {
        for (const skillId of selectedSkillIds) {
          await db.execute(sql`
            INSERT INTO job_required_skills (job_id, skill_id)
            VALUES (${job.id}, ${skillId})
          `);
        }
      }
    }
  }
  
  console.log(`Created ${totalJobs} job postings`);
}

/**
 * Generate a realistic job description based on role and family
 */
function generateJobDescription(roleName: string, jobFamily: string): string {
  const companyDescriptions = [
    "a fast-growing startup",
    "an established industry leader",
    "a dynamic tech company",
    "an innovative software firm",
    "a global consulting group",
    "a remote-first organization"
  ];
  
  const companyDesc = getRandomItem(companyDescriptions);
  const familySkills = skillsByJobFamily[jobFamily as JobFamily] || [];
  const requiredSkills = getRandomSubset(familySkills, 3, 5).join(", ");
  
  const openingSentences = [
    `We are ${companyDesc} looking for a talented ${roleName} to join our team.`,
    `${companyDesc.charAt(0).toUpperCase() + companyDesc.slice(1)} seeking an experienced ${roleName} for a ${Math.random() > 0.6 ? 'full-time' : 'part-time'} position.`,
    `Join our team as a ${roleName} and help us build the future of our industry.`
  ];
  
  const responsibilitySentences = [
    `You will be responsible for working with cross-functional teams to deliver high-quality solutions.`,
    `Your primary focus will be developing and implementing strategies to meet our business objectives.`,
    `You'll collaborate with stakeholders to understand requirements and deliver exceptional results.`,
    `This role involves managing projects from conception to completion while ensuring quality and timeliness.`
  ];
  
  const skillSentences = [
    `The ideal candidate will have experience with ${requiredSkills}.`,
    `We're looking for someone proficient in ${requiredSkills}.`,
    `Required skills include ${requiredSkills}.`,
    `Experience with ${requiredSkills} is essential for this role.`
  ];
  
  const closingSentences = [
    `We offer competitive compensation, flexible working hours, and a supportive remote environment.`,
    `This is a great opportunity to work on challenging projects with a talented global team.`,
    `Join us and be part of an innovative team that values creativity, diversity, and continuous learning.`,
    `We provide excellent benefits, professional growth opportunities, and a collaborative work culture.`
  ];
  
  // Assemble the description
  return [
    getRandomItem(openingSentences),
    getRandomItem(responsibilitySentences),
    getRandomItem(skillSentences),
    getRandomItem(closingSentences)
  ].join(' ');
}

/**
 * Main function to generate all test data
 */
async function generateTestData() {
  try {
    console.log("Starting test data generation...");
    
    // Clear existing data
    await clearDatabase();
    
    // Create subscription plans
    await createSubscriptionPlans();
    
    // Create skills and job roles
    await createSkills();
    await createJobRoles();
    
    // Create test users
    await createTestUsers();
    
    // Set up user profiles
    await setupUserProfiles();
    
    // Create job postings
    await createJobPostings();
    
    console.log("Test data generation completed successfully!");
  } catch (error) {
    console.error("Error generating test data:", error);
    process.exit(1);
  }
}

// Run the script
generateTestData().then(() => {
  console.log("Done!");
  process.exit(0);
}).catch((error) => {
  console.error("Script failed:", error);
  process.exit(1);
});