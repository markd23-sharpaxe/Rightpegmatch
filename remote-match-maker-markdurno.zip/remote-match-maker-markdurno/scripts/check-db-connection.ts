/**
 * This script checks if the database connection is working
 */

import { pool } from "../server/db";

async function checkDbConnection() {
  try {
    // Try to execute a simple query
    const result = await pool.query("SELECT current_timestamp as now");
    
    if (result && result.rows && result.rows.length > 0) {
      const timestamp = result.rows[0].now;
      console.log(`✅ Successfully connected to database at ${timestamp}`);
      return true;
    } else {
      console.error("❌ Database connection failed: No result returned");
      return false;
    }
  } catch (error) {
    console.error("❌ Database connection failed:", error.message);
    return false;
  } finally {
    // Close the connection pool
    await pool.end();
  }
}

// Run the check
checkDbConnection()
  .then(success => {
    // Exit with success (0) or failure (1) code
    process.exit(success ? 0 : 1);
  })
  .catch(error => {
    console.error("Error running check:", error);
    process.exit(1);
  });