/**
 * This script adds the salaryAmount column to the jobs table
 */
import { Pool } from 'pg';

// Load environment variables from the server

// Initialize the database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

async function addSalaryAmountColumn() {
  try {
    // Check if column already exists
    const checkColumnSQL = `
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'jobs' 
      AND column_name = 'salary_amount'
    `;
    
    const result = await pool.query(checkColumnSQL);
    
    if (result.rows.length === 0) {
      // Column doesn't exist, add it
      const addColumnSQL = `
        ALTER TABLE jobs 
        ADD COLUMN salary_amount TEXT
      `;
      
      await pool.query(addColumnSQL);
      console.log('Successfully added salary_amount column to jobs table');
      
      // Copy data from hourly_rate to salary_amount for existing records
      const updateSQL = `
        UPDATE jobs 
        SET salary_amount = hourly_rate 
        WHERE salary_amount IS NULL AND hourly_rate IS NOT NULL
      `;
      
      await pool.query(updateSQL);
      console.log('Copied existing hourly_rate values to salary_amount column');
    } else {
      console.log('salary_amount column already exists in jobs table');
    }
  } catch (error) {
    console.error('Error adding salary_amount column:', error);
  } finally {
    // Close the database connection
    await pool.end();
  }
}

// Run the migration
addSalaryAmountColumn()
  .then(() => {
    console.log('Migration completed successfully');
    process.exit(0);
  })
  .catch((err) => {
    console.error('Migration failed:', err);
    process.exit(1);
  });