/**
 * This script adds a small batch of jobs (10 at a time)
 * Run this script multiple times to reach the desired job count
 */

import { db } from "../server/db";
import { sql } from "drizzle-orm";
import {
  users, jobs, skills, jobRoles, jobRequiredSkills,
  JobFamily, SalaryType, StartDateFlexibilityType,
  InsertJob, JobAvailabilityRequirement
} from "../shared/schema";

// Common test data
const companyNames = [
  "TechNova Solutions", "Global Innovations Group", "NextGen Systems", "Horizon Analytics",
  "Blue Ocean Consulting", "CloudSphere Technologies", "Apex Digital Ventures", "Quantum Leap Networks",
  "Pinnacle Solutions", "Stellar Systems", "Catalyst Dynamics", "Fusion Technologies",
  "Prism Solutions", "Emerge Digital", "Traverse Industries", "Nexus Innovations",
  "Vertex Systems", "Elevate Technologies", "Spark Analytics", "Pulse Dynamics"
];

const languages = ["English", "Spanish", "French", "German", "Chinese", "Japanese"];
const currencies = ["USD", "EUR", "GBP", "CAD"];
const salaryTypes: SalaryType[] = ["hourly", "weekly", "monthly", "yearly"];
const startDateFlexibilityOptions: StartDateFlexibilityType[] = ["exact", "month", "immediate"];
const timeZones = ["GMT+0", "GMT-5", "GMT-8", "GMT+1", "GMT+2", "GMT+5:30"];

/**
 * Generate a random integer between min and max (inclusive)
 */
function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Select a random item from an array
 */
function getRandomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Select a random subset of items from an array
 */
function getRandomSubset<T>(arr: T[], min: number, max: number): T[] {
  const count = getRandomInt(min, Math.min(max, arr.length));
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

/**
 * Generate a random date within a range
 */
function getRandomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

/**
 * Generate random availability slots
 */
function generateAvailabilitySlots(count: number): JobAvailabilityRequirement[] {
  const slots: JobAvailabilityRequirement[] = [];
  const days = [1, 2, 3, 4, 5]; // Monday to Friday
  
  for (let i = 0; i < count; i++) {
    const dayOfWeek = getRandomItem(days);
    const startHour = getRandomInt(8, 16);
    const endHour = getRandomInt(startHour + 1, Math.min(startHour + 8, 23));
    const timeZone = getRandomItem(timeZones);
    
    slots.push({
      dayOfWeek,
      startHour,
      endHour,
      timeZone
    });
  }
  
  return slots;
}

/**
 * Generate job descriptions
 */
function generateJobDescription(roleName: string, jobFamily: string): string {
  const descriptions = [
    `We are looking for a talented ${roleName} with experience in ${jobFamily} to join our remote team.`,
    `Join our team as a ${roleName} and help us build innovative solutions.`,
    `Experienced ${roleName} needed for our growing ${jobFamily} team.`,
    `Remote ${roleName} position available for a motivated professional.`,
    `We're hiring a ${roleName} to join our ${jobFamily} department.`
  ];
  
  return getRandomItem(descriptions);
}

/**
 * Add a small batch of jobs
 */
async function addJobBatch() {
  // Get current job count
  const [result] = await db.select({ count: sql<number>`count(*)` }).from(jobs);
  const currentJobCount = result?.count || 0;
  
  console.log(`Current job count: ${currentJobCount}`);
  
  if (currentJobCount >= 200) {
    console.log("Already have 200+ jobs in the database. No need to add more.");
    return;
  }
  
  // Get all users, job roles, and skills
  const allUsers = await db.select().from(users);
  const allJobRoles = await db.select().from(jobRoles);
  const allSkills = await db.select().from(skills);
  
  // Add 10 jobs in this batch
  const batchSize = 10;
  console.log(`Adding a batch of ${batchSize} jobs...`);
  
  const jobBatch = [];
  
  for (let i = 0; i < batchSize; i++) {
    // Select random job role and employer
    const jobRole = getRandomItem(allJobRoles);
    const employer = getRandomItem(allUsers);
    
    // Job dates
    const now = new Date();
    const futureDate = new Date();
    futureDate.setMonth(now.getMonth() + 3);
    
    const isPermanent = Math.random() > 0.5;
    const startDate = getRandomDate(now, new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000));
    const endDate = isPermanent ? undefined : getRandomDate(futureDate, new Date(futureDate.getTime() + 90 * 24 * 60 * 60 * 1000));
    
    // Generate availability slots
    const availabilitySlots = generateAvailabilitySlots(getRandomInt(1, 2));
    
    // Create job
    const jobData: InsertJob = {
      title: `${jobRole.name} at ${getRandomItem(companyNames)}`,
      employerId: employer.id,
      companyName: getRandomItem(companyNames),
      jobRoleId: jobRole.id,
      jobFamily: jobRole.jobFamily,
      hoursPerWeek: getRandomInt(10, 40),
      salaryAmount: getRandomInt(20, 120).toString(),
      salaryType: getRandomItem(salaryTypes),
      currency: getRandomItem(currencies),
      requiredLanguages: getRandomItem(languages),
      requiredAvailability: availabilitySlots,
      description: generateJobDescription(jobRole.name, jobRole.jobFamily),
      location: "Remote",
      startDate,
      endDate,
      startDateFlexibility: getRandomItem(startDateFlexibilityOptions),
      isPermanent
    };
    
    jobBatch.push(jobData);
  }
  
  // Insert job batch
  const insertedJobs = await db.insert(jobs).values(jobBatch).returning({ id: jobs.id, jobRoleId: jobs.jobRoleId });
  
  // Add required skills
  for (const job of insertedJobs) {
    // Get skills for the job (2-3 skills per job)
    const skillsToAdd = getRandomSubset(allSkills, 2, 3);
    
    for (const skill of skillsToAdd) {
      await db.execute(sql`
        INSERT INTO job_required_skills (job_id, skill_id)
        VALUES (${job.id}, ${skill.id})
      `);
    }
  }
  
  console.log(`Added batch of ${insertedJobs.length} jobs`);
  
  // Get new job count
  const [newResult] = await db.select({ count: sql<number>`count(*)` }).from(jobs);
  const newJobCount = newResult?.count || 0;
  
  console.log(`New job count: ${newJobCount}`);
  console.log(`Need ${Math.max(200 - newJobCount, 0)} more jobs to reach 200`);
}

/**
 * Main function
 */
async function main() {
  try {
    await addJobBatch();
    console.log("Completed adding jobs batch!");
  } catch (error) {
    console.error("Error adding jobs:", error);
    process.exit(1);
  }
}

// Run the script
main().then(() => {
  console.log("Done!");
  process.exit(0);
}).catch((error) => {
  console.error("Script failed:", error);
  process.exit(1);
});