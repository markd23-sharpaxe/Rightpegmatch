/**
 * This script creates job and user matching indexes for faster job matching
 * 
 * It:
 * 1. Creates the necessary DB tables (if they don't exist)
 * 2. Populates job language and job family indexes
 * 3. Populates user language and user job family indexes
 */

import { db } from "../server/db";
import * as schema from "../shared/schema";
import { eq, sql } from "drizzle-orm";

/**
 * Main function to build job matching indexes
 */
async function buildJobMatchingIndexes() {
  console.log("Starting to build job matching indexes...");
  
  // Get all jobs
  const jobs = await db.select().from(schema.jobs);
  console.log(`Found ${jobs.length} jobs to index`);
  
  // Get all users
  const users = await db.select().from(schema.users);
  console.log(`Found ${users.length} users to index`);
  
  // Clear existing indexes first
  console.log("Clearing existing indexes...");
  await db.delete(schema.jobLanguageIndex);
  await db.delete(schema.jobFamilyIndex);
  await db.delete(schema.userLanguageIndex);
  await db.delete(schema.userJobFamilyIndex);
  
  // Process each job
  console.log("Building job indexes...");
  for (const job of jobs) {
    try {
      // Process job languages
      if (job.requiredLanguages) {
        const languages = job.requiredLanguages.split(',').map(lang => lang.trim());
        
        // Create job language index entries
        for (const language of languages) {
          if (language) {
            await db.insert(schema.jobLanguageIndex).values({
              jobId: job.id,
              language
            });
          }
        }
      }
      
      // Process job family
      if (job.jobFamily) {
        await db.insert(schema.jobFamilyIndex).values({
          jobId: job.id,
          jobFamily: job.jobFamily
        });
      }
    } catch (error) {
      console.error(`Error processing job ${job.id}:`, error);
    }
  }
  
  // Process each user
  console.log("Building user indexes...");
  for (const user of users) {
    try {
      // Process user languages
      if (user.languages) {
        const languages = user.languages.split(',').map(lang => lang.trim());
        
        // Create user language index entries
        for (const language of languages) {
          if (language) {
            await db.insert(schema.userLanguageIndex).values({
              userId: user.id,
              language
            });
          }
        }
      }
      
      // Get user job roles to determine job families
      const userJobRoles = await db.select({
        role: schema.jobRoles
      })
      .from(schema.userJobRoles)
      .innerJoin(schema.jobRoles, eq(schema.userJobRoles.jobRoleId, schema.jobRoles.id))
      .where(eq(schema.userJobRoles.userId, user.id));
      
      // Track processed job families to avoid duplicates
      const processedJobFamilies = new Set<string>();
      
      // Process each job role
      for (const userJobRole of userJobRoles) {
        if (userJobRole.role.jobFamily && !processedJobFamilies.has(userJobRole.role.jobFamily)) {
          processedJobFamilies.add(userJobRole.role.jobFamily);
          
          // Create user job family index entry
          await db.insert(schema.userJobFamilyIndex).values({
            userId: user.id,
            jobFamily: userJobRole.role.jobFamily
          });
        }
      }
      
      // Also check legacy job role ID if it exists
      if (user.jobRoleId) {
        const legacyJobRole = await db.select().from(schema.jobRoles).where(eq(schema.jobRoles.id, user.jobRoleId)).limit(1);
        
        if (legacyJobRole.length > 0 && legacyJobRole[0].jobFamily && !processedJobFamilies.has(legacyJobRole[0].jobFamily)) {
          // Create user job family index entry for legacy role
          await db.insert(schema.userJobFamilyIndex).values({
            userId: user.id,
            jobFamily: legacyJobRole[0].jobFamily
          });
        }
      }
    } catch (error) {
      console.error(`Error processing user ${user.id}:`, error);
    }
  }
  
  // Create database indexes for faster queries
  console.log("Creating database indexes...");
  await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_job_language_index_language ON job_language_index (language)`);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_job_family_index_job_family ON job_family_index (job_family)`);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_user_language_index_language ON user_language_index (language)`);
  await db.execute(sql`CREATE INDEX IF NOT EXISTS idx_user_job_family_index_job_family ON user_job_family_index (job_family)`);
  
  console.log("Job matching indexes built successfully!");
}

// Run the script
buildJobMatchingIndexes()
  .then(() => {
    console.log("All done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error building job matching indexes:", error);
    process.exit(1);
  });