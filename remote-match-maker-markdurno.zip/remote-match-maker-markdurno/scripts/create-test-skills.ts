/**
 * This script creates test skills in the database
 */

import { storage } from "../server/storage";
import { InsertSkill } from "../shared/schema";

const technicalSkills = [
  { name: "JavaScript", category: "Technical" },
  { name: "TypeScript", category: "Technical" },
  { name: "React", category: "Technical" },
  { name: "Angular", category: "Technical" },
  { name: "Vue.js", category: "Technical" },
  { name: "Node.js", category: "Technical" },
  { name: "Express", category: "Technical" },
  { name: "NestJS", category: "Technical" },
  { name: "Python", category: "Technical" },
  { name: "Django", category: "Technical" },
  { name: "Flask", category: "Technical" },
  { name: "Ruby", category: "Technical" },
  { name: "Ruby on Rails", category: "Technical" },
  { name: "PHP", category: "Technical" },
  { name: "Laravel", category: "Technical" },
  { name: "Java", category: "Technical" },
  { name: "Spring Boot", category: "Technical" },
  { name: "C#", category: "Technical" },
  { name: ".NET", category: "Technical" },
  { name: "ASP.NET", category: "Technical" },
  { name: "SQL", category: "Technical" },
  { name: "PostgreSQL", category: "Technical" },
  { name: "MySQL", category: "Technical" },
  { name: "MongoDB", category: "Technical" },
  { name: "Redis", category: "Technical" },
  { name: "AWS", category: "Technical" },
  { name: "Azure", category: "Technical" },
  { name: "Google Cloud", category: "Technical" },
  { name: "Docker", category: "Technical" },
  { name: "Kubernetes", category: "Technical" },
  { name: "Git", category: "Technical" },
  { name: "CI/CD", category: "Technical" },
  { name: "GraphQL", category: "Technical" },
  { name: "REST API", category: "Technical" },
  { name: "Microservices", category: "Technical" },
  { name: "TDD", category: "Technical" },
  { name: "Agile", category: "Technical" },
  { name: "Scrum", category: "Technical" },
  { name: "DevOps", category: "Technical" },
  { name: "Mobile Development", category: "Technical" },
  { name: "React Native", category: "Technical" },
  { name: "Flutter", category: "Technical" },
  { name: "Swift", category: "Technical" },
  { name: "Kotlin", category: "Technical" },
  { name: "Data Science", category: "Technical" },
  { name: "Machine Learning", category: "Technical" },
  { name: "AI", category: "Technical" },
  { name: "Deep Learning", category: "Technical" },
  { name: "TensorFlow", category: "Technical" },
  { name: "PyTorch", category: "Technical" }
];

const designSkills = [
  { name: "UI Design", category: "Design" },
  { name: "UX Design", category: "Design" },
  { name: "Figma", category: "Design" },
  { name: "Sketch", category: "Design" },
  { name: "Adobe XD", category: "Design" },
  { name: "Adobe Photoshop", category: "Design" },
  { name: "Adobe Illustrator", category: "Design" },
  { name: "Responsive Design", category: "Design" },
  { name: "Design Systems", category: "Design" },
  { name: "User Research", category: "Design" },
  { name: "Prototyping", category: "Design" },
  { name: "Wireframing", category: "Design" },
  { name: "Information Architecture", category: "Design" },
  { name: "Visual Design", category: "Design" },
  { name: "Interaction Design", category: "Design" }
];

const softSkills = [
  { name: "Communication", category: "Soft" },
  { name: "Teamwork", category: "Soft" },
  { name: "Problem Solving", category: "Soft" },
  { name: "Critical Thinking", category: "Soft" },
  { name: "Time Management", category: "Soft" },
  { name: "Leadership", category: "Soft" },
  { name: "Adaptability", category: "Soft" },
  { name: "Creativity", category: "Soft" },
  { name: "Emotional Intelligence", category: "Soft" },
  { name: "Negotiation", category: "Soft" },
  { name: "Conflict Resolution", category: "Soft" },
  { name: "Decision Making", category: "Soft" },
  { name: "Mentoring", category: "Soft" },
  { name: "Project Management", category: "Soft" },
  { name: "Public Speaking", category: "Soft" }
];

const allSkills = [...technicalSkills, ...designSkills, ...softSkills];

async function main() {
  console.log(`Creating ${allSkills.length} skills...`);
  
  for (const skillData of allSkills) {
    try {
      // Check if skill already exists
      const existingSkill = await storage.getSkillByName(skillData.name);
      
      if (existingSkill) {
        console.log(`Skill "${skillData.name}" already exists.`);
      } else {
        const skill = await storage.createSkill(skillData);
        console.log(`Created skill: ${skill.name} (ID: ${skill.id})`);
      }
    } catch (error) {
      console.error(`Failed to create skill '${skillData.name}':`, error);
    }
  }
  
  console.log("Skills creation complete!");
  process.exit(0);
}

main();