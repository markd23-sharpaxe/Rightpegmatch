/**
 * This script creates minimal test data for end-to-end testing
 * 
 * This script:
 * 1. Creates 4 test users with usernames test1-test4 and password testing123
 * 2. Generates 20 realistic job postings with various requirements
 * 3. Sets up user profiles with relevant skills
 */

import { db } from "../server/db";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";
import {
  users, jobs, userSkills, skills, jobRoles, userJobRoles,
  availabilitySlots, jobRequiredSkills,
  JobFamily, SalaryType, StartDateFlexibilityType,
  InsertUser, InsertJob, InsertSkill, InsertJobRole, InsertUserSkill,
  InsertUserJobRole, InsertAvailabilitySlot, JobAvailabilityRequirement
} from "../shared/schema";
import { sql } from "drizzle-orm";

const scryptAsync = promisify(scrypt);

// Common test data
const companyNames = [
  "TechNova Solutions", "Global Innovations Group", "NextGen Systems", "Horizon Analytics",
  "Blue Ocean Consulting", "CloudSphere Technologies", "Apex Digital Ventures", "Quantum Leap Networks"
];

const languages = ["English", "Spanish", "French", "German", "Chinese"];
const currencies = ["USD", "EUR", "GBP"];
const salaryTypes: SalaryType[] = ["hourly", "weekly", "monthly", "yearly"];
const startDateFlexibilityOptions: StartDateFlexibilityType[] = ["exact", "month", "immediate"];
const timeZones = ["GMT+0", "GMT-5", "GMT-8", "GMT+1", "GMT+2"];

/**
 * Hash a password using scrypt
 */
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

/**
 * Generate a random integer between min and max (inclusive)
 */
function getRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * Select a random item from an array
 */
function getRandomItem<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/**
 * Select a random subset of items from an array
 */
function getRandomSubset<T>(arr: T[], min: number, max: number): T[] {
  const count = getRandomInt(min, Math.min(max, arr.length));
  const shuffled = [...arr].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

/**
 * Generate a random date within a range
 */
function getRandomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

/**
 * Generate random availability slots
 */
function generateAvailabilitySlots(count: number): JobAvailabilityRequirement[] {
  const slots: JobAvailabilityRequirement[] = [];
  const days = [1, 2, 3, 4, 5]; // Monday to Friday
  
  for (let i = 0; i < count; i++) {
    const dayOfWeek = getRandomItem(days);
    const startHour = getRandomInt(8, 16);
    const endHour = getRandomInt(startHour + 1, Math.min(startHour + 8, 23));
    const timeZone = getRandomItem(timeZones);
    
    slots.push({
      dayOfWeek,
      startHour,
      endHour,
      timeZone
    });
  }
  
  return slots;
}

/**
 * Create test users with specified credentials
 */
async function createTestUsers() {
  console.log("Creating test users...");
  
  const hashedPassword = await hashPassword("testing123");
  
  // Create 4 test users
  for (let i = 1; i <= 4; i++) {
    const username = `test${i}`;
    const email = `test${i}@example.com`;
    
    const userData: InsertUser = {
      username,
      email,
      password: hashedPassword,
      fullName: `Test User ${i}`,
      bio: `This is a test user account for end-to-end testing. User ID: ${i}`,
      location: getRandomItem(["Remote", "London, UK", "New York, USA", "Berlin, Germany"]),
      avatarUrl: `https://ui-avatars.com/api/?name=Test+${i}&background=random`,
      preferredHoursPerWeek: getRandomInt(10, 40),
      languages: getRandomItem(languages),
      timeZone: getRandomItem(timeZones)
    };
    
    // Insert user
    const [user] = await db.insert(users).values(userData).returning();
    console.log(`Created test user: ${username} (ID: ${user.id})`);
  }
  
  console.log("Test users created successfully");
}

/**
 * Set up user profiles with job roles, skills, and availability
 */
async function setupUserProfiles() {
  console.log("Setting up user profiles...");
  
  // Get all users, skills, and job roles
  const allUsers = await db.select().from(users);
  const allSkills = await db.select().from(skills);
  const allJobRoles = await db.select().from(jobRoles);
  
  // For each user, set up a basic profile
  for (const user of allUsers) {
    // Assign 1-2 job roles (one as primary)
    const roleCount = getRandomInt(1, 2);
    const selectedRoles = getRandomSubset(allJobRoles, roleCount, roleCount);
    
    // Primary role
    await db.insert(userJobRoles).values({
      userId: user.id,
      jobRoleId: selectedRoles[0].id,
      isPrimary: true
    });
    
    // Additional role if any
    if (selectedRoles.length > 1) {
      await db.insert(userJobRoles).values({
        userId: user.id,
        jobRoleId: selectedRoles[1].id,
        isPrimary: false
      });
    }
    
    // Add 3-5 skills
    const selectedSkills = getRandomSubset(allSkills, 3, 5);
    for (const skill of selectedSkills) {
      await db.insert(userSkills).values({
        userId: user.id,
        skillId: skill.id
      });
    }
    
    // Add 2-3 availability slots
    const availCount = getRandomInt(2, 3);
    const slots = generateAvailabilitySlots(availCount);
    
    for (const slot of slots) {
      await db.insert(availabilitySlots).values({
        userId: user.id,
        dayOfWeek: slot.dayOfWeek,
        startHour: slot.startHour,
        endHour: slot.endHour,
        timeZone: slot.timeZone
      });
    }
  }
  
  console.log("User profiles set up successfully");
}

/**
 * Create a small number of job postings
 */
async function createJobPostings() {
  console.log("Creating job postings...");
  
  const allUsers = await db.select().from(users);
  const allJobRoles = await db.select().from(jobRoles);
  const allSkills = await db.select().from(skills);
  
  // Create just 20 job postings for testing
  const totalJobs = 20;
  
  for (let i = 0; i < totalJobs; i++) {
    // Select random job role and employer
    const jobRole = getRandomItem(allJobRoles);
    const employer = getRandomItem(allUsers);
    
    // Job dates
    const now = new Date();
    const futureDate = new Date();
    futureDate.setMonth(now.getMonth() + 3);
    
    const isPermanent = Math.random() > 0.5;
    const startDate = getRandomDate(now, new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000));
    const endDate = isPermanent ? undefined : getRandomDate(futureDate, new Date(futureDate.getTime() + 90 * 24 * 60 * 60 * 1000));
    
    // Generate availability slots
    const availabilitySlots = generateAvailabilitySlots(getRandomInt(1, 2));
    
    // Create job
    const jobData: InsertJob = {
      title: `${jobRole.name} at ${getRandomItem(companyNames)}`,
      employerId: employer.id,
      companyName: getRandomItem(companyNames),
      jobRoleId: jobRole.id,
      jobFamily: jobRole.jobFamily,
      hoursPerWeek: getRandomInt(10, 40),
      salaryAmount: getRandomInt(20, 100).toString(),
      salaryType: getRandomItem(salaryTypes),
      currency: getRandomItem(currencies),
      requiredLanguages: getRandomItem(languages),
      requiredAvailability: availabilitySlots,
      description: `This is a test job posting for a ${jobRole.name} position. Looking for someone with experience in the ${jobRole.jobFamily} field.`,
      location: "Remote",
      startDate,
      endDate,
      startDateFlexibility: getRandomItem(startDateFlexibilityOptions),
      isPermanent
    };
    
    // Insert job
    const [job] = await db.insert(jobs).values(jobData).returning();
    
    // Add 1-3 required skills
    const skillsToAdd = getRandomSubset(allSkills, 1, 3);
    
    for (const skill of skillsToAdd) {
      await db.execute(sql`
        INSERT INTO job_required_skills (job_id, skill_id)
        VALUES (${job.id}, ${skill.id})
      `);
    }
    
    console.log(`Created job #${i+1}: ${jobData.title}`);
  }
  
  console.log(`Created ${totalJobs} job postings`);
}

/**
 * Main function
 */
async function createMinimalTestData() {
  try {
    // We don't want to clear all data - just verify if test users exist
    const existingUsers = await db.select().from(users).where(sql`username LIKE 'test%'`);
    
    if (existingUsers.length >= 4) {
      console.log("Test users already exist, skipping user creation");
    } else {
      await createTestUsers();
      await setupUserProfiles();
    }
    
    // Create job postings
    await createJobPostings();
    
    console.log("Test data creation completed successfully!");
  } catch (error) {
    console.error("Error creating test data:", error);
    process.exit(1);
  }
}

// Run the script
createMinimalTestData().then(() => {
  console.log("Done!");
  process.exit(0);
}).catch((error) => {
  console.error("Script failed:", error);
  process.exit(1);
});