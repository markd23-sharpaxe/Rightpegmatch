/**
 * This script creates test job roles in the database
 */

import { storage } from "../server/storage";
import { InsertJobRole } from "../shared/schema";

const developmentRoles = [
  { name: "Frontend Developer", category: "Development" },
  { name: "Backend Developer", category: "Development" },
  { name: "Full-stack Developer", category: "Development" },
  { name: "Mobile Developer", category: "Development" },
  { name: "Game Developer", category: "Development" },
  { name: "DevOps Engineer", category: "Development" },
  { name: "Cloud Engineer", category: "Development" },
  { name: "Security Engineer", category: "Development" },
  { name: "Blockchain Developer", category: "Development" },
  { name: "AI/ML Engineer", category: "Development" }
];

const designRoles = [
  { name: "UI Designer", category: "Design" },
  { name: "UX Designer", category: "Design" },
  { name: "Product Designer", category: "Design" },
  { name: "Graphic Designer", category: "Design" },
  { name: "Motion Designer", category: "Design" },
  { name: "Interaction Designer", category: "Design" },
  { name: "Visual Designer", category: "Design" },
  { name: "Brand Designer", category: "Design" },
  { name: "Web Designer", category: "Design" },
  { name: "Art Director", category: "Design" }
];

const managementRoles = [
  { name: "Project Manager", category: "Management" },
  { name: "Product Manager", category: "Management" },
  { name: "Technical Lead", category: "Management" },
  { name: "Engineering Manager", category: "Management" },
  { name: "CTO", category: "Management" },
  { name: "VP of Engineering", category: "Management" },
  { name: "Scrum Master", category: "Management" },
  { name: "Agile Coach", category: "Management" },
  { name: "Operations Manager", category: "Management" },
  { name: "Delivery Manager", category: "Management" }
];

const dataRoles = [
  { name: "Data Analyst", category: "Data" },
  { name: "Data Scientist", category: "Data" },
  { name: "Data Engineer", category: "Data" },
  { name: "BI Analyst", category: "Data" },
  { name: "Database Administrator", category: "Data" },
  { name: "Big Data Engineer", category: "Data" },
  { name: "Machine Learning Engineer", category: "Data" },
  { name: "Data Architect", category: "Data" },
  { name: "Analytics Engineer", category: "Data" },
  { name: "Research Scientist", category: "Data" }
];

const allRoles = [...developmentRoles, ...designRoles, ...managementRoles, ...dataRoles];

async function main() {
  console.log(`Creating ${allRoles.length} job roles...`);
  
  for (const roleData of allRoles) {
    try {
      // Check if role already exists
      const existingRole = await storage.getJobRoleByName(roleData.name);
      
      if (existingRole) {
        console.log(`Job role "${roleData.name}" already exists.`);
      } else {
        const role = await storage.createJobRole(roleData);
        console.log(`Created job role: ${role.name} (ID: ${role.id})`);
      }
    } catch (error) {
      console.error(`Failed to create job role '${roleData.name}':`, error);
    }
  }
  
  console.log("Job roles creation complete!");
  process.exit(0);
}

main();