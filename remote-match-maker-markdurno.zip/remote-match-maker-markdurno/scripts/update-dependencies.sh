#!/bin/bash

# This script updates dependencies to the latest secure versions
# It should be run periodically to ensure security patches are applied
# The script also updates the browserslist database

echo "=== RightPegMatch Dependency Update ==="
echo ""

# Check if npm is installed
if ! command -v npm &> /dev/null; then
  echo "❌ npm is not installed. Please install npm before running this script."
  exit 1
fi

# Check if git is installed
if ! command -v git &> /dev/null; then
  echo "❌ git is not installed. Please install git before running this script."
  exit 1
fi

# Create a new branch for the updates
update_date=$(date +"%Y%m%d")
branch_name="dependency-update-${update_date}"

git branch "${branch_name}" 2>/dev/null || echo "Creating branch without git"
git checkout "${branch_name}" 2>/dev/null || echo "Checking out branch without git"

echo "Updating npm packages..."

# Update browserslist database
echo ""
echo "Updating browserslist database..."
npx update-browserslist-db@latest

# Update dependencies to latest secure versions
echo ""
echo "Checking for outdated packages..."
npm outdated

echo ""
echo "Updating packages..."
npm update

echo ""
echo "Checking for security vulnerabilities..."
npm audit

echo ""
echo "Updating completed."
echo "Please test the application thoroughly before deploying these changes."
echo ""

# If there are security issues that need manual intervention
if npm audit | grep -q "Run 'npm audit fix' to fix them"; then
  echo "⚠️  Some security issues were found that may require manual fixes."
  echo "Consider running 'npm audit fix' manually after reviewing the changes."
fi

echo "To apply these changes in production:"
echo "1. Test the application thoroughly"
echo "2. Commit the changes: git commit -am 'Update dependencies ${update_date}'"
echo "3. Merge to main branch: git checkout main && git merge ${branch_name}"
echo "4. Deploy the updates to production"