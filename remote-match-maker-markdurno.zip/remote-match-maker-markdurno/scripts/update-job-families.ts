/**
 * This script updates job roles with appropriate job families
 */
import { db } from "../server/db";
import { JobFamily, jobRoles } from "../shared/schema";
import { eq } from "drizzle-orm";

// Define mappings for job roles to job families
type JobRoleFamilyMapping = {
  [key: string]: JobFamily;
};

// Define regex patterns to match job role names with job families
const jobFamilyPatterns: { pattern: RegExp; family: JobFamily }[] = [
  { pattern: /project manager|program manager|product manager|scrum master|agile coach|delivery manager|project lead/i, family: JobFamily.ProjectManagement },
  { pattern: /developer|engineer|programmer|architect|coder|fullstack|front.?end|back.?end|devops|mobile|ios|android|web|software/i, family: JobFamily.SoftwareDevelopment },
  { pattern: /design|designer|ux|ui|user experience|user interface|graphic/i, family: JobFamily.Design },
  { pattern: /sales|account executive|business development|sales representative|sales manager/i, family: JobFamily.Sales },
  { pattern: /marketing|seo|content|social media|growth hacker|brand|campaign/i, family: JobFamily.Marketing },
  { pattern: /customer|support|service|help desk|technical support/i, family: JobFamily.CustomerSupport },
  { pattern: /finance|accounting|financial|accountant|controller|cfo/i, family: JobFamily.Finance },
  { pattern: /hr|human resources|recruiting|talent acquisition|people ops/i, family: JobFamily.HumanResources },
  { pattern: /ceo|cto|coo|chief|executive|director|vp|vice president|head of/i, family: JobFamily.Executive },
  { pattern: /operations|office manager|facilities|administrative|coord/i, family: JobFamily.Operations },
  { pattern: /data|analyst|analytics|business intelligence|bi developer|statistician|machine learning|ml|ai|artificial intelligence/i, family: JobFamily.DataAnalysis },
];

// Explicitly map certain job roles that might be ambiguous
const explicitMappings: JobRoleFamilyMapping = {
  "Project Manager": JobFamily.ProjectManagement,
  "Pensions Project Manager": JobFamily.ProjectManagement,
  "Product Manager": JobFamily.ProjectManagement,
  "Software Engineer": JobFamily.SoftwareDevelopment,
  "Frontend Developer": JobFamily.SoftwareDevelopment,
  "Backend Developer": JobFamily.SoftwareDevelopment,
  "Full Stack Developer": JobFamily.SoftwareDevelopment,
  "Mobile Developer": JobFamily.SoftwareDevelopment,
  "UI/UX Designer": JobFamily.Design,
  "Graphic Designer": JobFamily.Design,
  "Digital Marketer": JobFamily.Marketing,
  "Content Writer": JobFamily.Marketing,
  "Data Analyst": JobFamily.DataAnalysis,
  "Data Scientist": JobFamily.DataAnalysis,
  "HR Manager": JobFamily.HumanResources,
  "Recruitment Specialist": JobFamily.HumanResources,
  "Customer Support": JobFamily.CustomerSupport,
  "Sales Representative": JobFamily.Sales,
  "Account Manager": JobFamily.Sales,
  "Financial Analyst": JobFamily.Finance,
  "Accountant": JobFamily.Finance,
  "Operations Manager": JobFamily.Operations,
  "CEO": JobFamily.Executive,
  "CTO": JobFamily.Executive,
  "CFO": JobFamily.Executive,
};

async function updateJobFamilies() {
  try {
    console.log("Starting job family update...");
    
    // Get all job roles
    const roles = await db.select().from(jobRoles);
    console.log(`Found ${roles.length} job roles to process`);
    
    let updateCount = 0;
    
    // Process each role
    for (const role of roles) {
      let family = JobFamily.Other;
      
      // First check explicit mappings
      if (explicitMappings[role.name]) {
        family = explicitMappings[role.name];
      } else {
        // Then try pattern matching
        for (const { pattern, family: patternFamily } of jobFamilyPatterns) {
          if (pattern.test(role.name)) {
            family = patternFamily;
            break;
          }
        }
      }
      
      // Update the job role
      await db.update(jobRoles)
        .set({ jobFamily: family })
        .where(eq(jobRoles.id, role.id));
      
      console.log(`Updated job role: ${role.name} -> ${family}`);
      updateCount++;
    }
    
    console.log(`Successfully updated ${updateCount} job roles with job families`);
  } catch (error) {
    console.error("Error updating job families:", error);
  }
}

updateJobFamilies()
  .then(() => {
    console.log("Job family update completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed to update job families:", error);
    process.exit(1);
  });