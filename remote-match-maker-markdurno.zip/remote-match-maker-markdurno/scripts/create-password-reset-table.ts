/**
 * This script creates the password reset tokens table in the database
 */
import { db } from "../server/db";
import { passwordResetTokens } from "../shared/schema";
import { sql } from "drizzle-orm";

async function createPasswordResetTable() {
  try {
    console.log("Creating password_reset_tokens table...");
    
    // Create the table directly without checking if it exists
    const createTableQuery = sql`
      CREATE TABLE IF NOT EXISTS password_reset_tokens (
        id SERIAL PRIMARY KEY,
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        token TEXT NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        used BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
    `;
    
    await db.execute(createTableQuery);
    console.log("Password reset tokens table created successfully");
  } catch (error) {
    console.error("Error creating password reset tokens table:", error);
  } finally {
    process.exit(0);
  }
}

createPasswordResetTable();