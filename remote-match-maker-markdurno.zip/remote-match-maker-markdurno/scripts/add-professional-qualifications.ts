/**
 * This script adds common professional qualifications to the database
 */
import { db } from "../server/db";
import { qualifications } from "../shared/schema";

async function addProfessionalQualifications() {
  // Define qualifications by category
  const qualificationsByCategory = {
    "Accounting & Finance": [
      "CPA (Certified Public Accountant)",
      "ACCA (Association of Chartered Certified Accountants)",
      "CFA (Chartered Financial Analyst)",
      "CIMA (Chartered Institute of Management Accountants)",
      "CMA (Certified Management Accountant)",
      "FRM (Financial Risk Manager)",
      "CIA (Certified Internal Auditor)",
      "EA (Enrolled Agent)",
      "CTA (Chartered Tax Adviser)"
    ],
    "Project Management": [
      "PMP (Project Management Professional)",
      "PRINCE2 (Projects IN Controlled Environments)",
      "CAPM (Certified Associate in Project Management)",
      "PRINCE2 Agile",
      "CSM (Certified Scrum Master)",
      "PSM (Professional Scrum Master)",
      "PMI-ACP (PMI Agile Certified Practitioner)",
      "ITIL (Information Technology Infrastructure Library)",
      "MSP (Managing Successful Programmes)"
    ],
    "Software Development": [
      "AWS Certified Solutions Architect",
      "Google Cloud Professional Cloud Architect",
      "Microsoft Certified: Azure Solutions Architect",
      "MCSD (Microsoft Certified Solutions Developer)",
      "Oracle Certified Professional",
      "CCNA (Cisco Certified Network Associate)",
      "CompTIA A+",
      "CompTIA Security+",
      "CISSP (Certified Information Systems Security Professional)",
      "CEH (Certified Ethical Hacker)",
      "CISM (Certified Information Security Manager)"
    ],
    "Legal": [
      "JD (Juris Doctor)",
      "LLM (Master of Laws)",
      "Bar Admission",
      "CIArb (Chartered Institute of Arbitrators)",
      "CIPP (Certified Information Privacy Professional)"
    ],
    "Human Resources": [
      "PHR (Professional in Human Resources)",
      "SPHR (Senior Professional in Human Resources)",
      "SHRM-CP (SHRM Certified Professional)",
      "SHRM-SCP (SHRM Senior Certified Professional)",
      "CIPD (Chartered Institute of Personnel and Development)"
    ],
    "Marketing": [
      "CIM (Chartered Institute of Marketing)",
      "Google Ads Certification",
      "Google Analytics Certification",
      "HubSpot Inbound Marketing Certification",
      "Facebook Blueprint Certification",
      "AMA (American Marketing Association) Professional Certified Marketer"
    ],
    "Healthcare": [
      "MD (Doctor of Medicine)",
      "RN (Registered Nurse)",
      "PA (Physician Assistant)",
      "NP (Nurse Practitioner)",
      "CNA (Certified Nursing Assistant)",
      "EMT (Emergency Medical Technician)",
      "CPhT (Certified Pharmacy Technician)",
      "CCRN (Critical Care Registered Nurse)"
    ],
    "Education": [
      "Teaching License/Certification",
      "National Board Certification",
      "TEFL (Teaching English as a Foreign Language)",
      "TESOL (Teaching English to Speakers of Other Languages)",
      "CELTA (Certificate in Teaching English to Speakers of Other Languages)"
    ],
    "Business Management": [
      "MBA (Master of Business Administration)",
      "Six Sigma (Green Belt, Black Belt)",
      "Lean Six Sigma",
      "CBAP (Certified Business Analysis Professional)",
      "CPM (Certified Product Manager)",
      "CSCP (Certified Supply Chain Professional)"
    ],
    "Design": [
      "Adobe Certified Expert",
      "Autodesk Certified Professional",
      "LEED (Leadership in Energy and Environmental Design)",
      "CID (Certified Interior Designer)"
    ],
    "Data Science": [
      "Microsoft Certified: Azure Data Scientist Associate",
      "Google Cloud Professional Data Engineer",
      "Cloudera Certified Associate (CCA) Data Analyst",
      "SAS Certified Data Scientist",
      "Tensorflow Developer Certificate"
    ]
  };

  console.log("Starting to add professional qualifications...");
  let addedCount = 0;
  let existingCount = 0;

  for (const [category, qualificationList] of Object.entries(qualificationsByCategory)) {
    console.log(`Processing ${category} qualifications...`);
    
    for (const name of qualificationList) {
      // Check if qualification already exists (case insensitive comparison in memory)
      const allQualifications = await db.select().from(qualifications);
      const existingQualification = allQualifications.filter(q => 
        q.name.toLowerCase() === name.toLowerCase());
      
      if (existingQualification.length === 0) {
        // Add the qualification (note: categories are managed in the code only, not in DB)
        await db.insert(qualifications)
          .values({
            name
          });
        addedCount++;
        console.log(`Added: ${name} (${category})`);
      } else {
        existingCount++;
        console.log(`Skipped existing: ${name}`);
      }
    }
  }

  console.log(`\nQualifications added: ${addedCount}`);
  console.log(`Existing qualifications skipped: ${existingCount}`);
  console.log("Professional qualifications script completed.");
}

// Run the function
addProfessionalQualifications()
  .then(() => {
    console.log("Script completed successfully");
    process.exit(0);
  })
  .catch(error => {
    console.error("Error running script:", error);
    process.exit(1);
  });