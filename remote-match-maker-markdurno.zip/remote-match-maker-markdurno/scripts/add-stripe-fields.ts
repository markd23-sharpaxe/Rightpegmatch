import pg from 'pg';
const { Pool } = pg;
import { drizzle } from 'drizzle-orm/node-postgres';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import fs from 'fs';
import path from 'path';

async function main() {
  console.log("Starting database migration to add Stripe subscription fields...");
  
  if (!process.env.DATABASE_URL) {
    throw new Error("DATABASE_URL environment variable must be set");
  }
  
  // Create the connection
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
  });
  
  // Run the SQL directly for this specific migration
  try {
    // Check if columns already exist
    const checkResult = await pool.query(`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'user_subscriptions' 
      AND column_name IN ('stripe_subscription_id', 'stripe_customer_id')
    `);
    
    if (checkResult.rows.length === 2) {
      console.log("Stripe subscription fields already exist, skipping migration");
    } else {
      // Add the columns if they don't exist
      await pool.query(`
        ALTER TABLE user_subscriptions 
        ADD COLUMN IF NOT EXISTS stripe_subscription_id TEXT,
        ADD COLUMN IF NOT EXISTS stripe_customer_id TEXT
      `);
      console.log("Added Stripe subscription and customer ID fields to user_subscriptions table");
    }
    
    console.log("Migration completed successfully!");
  } catch (error) {
    console.error("Migration failed:", error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main().catch(console.error);