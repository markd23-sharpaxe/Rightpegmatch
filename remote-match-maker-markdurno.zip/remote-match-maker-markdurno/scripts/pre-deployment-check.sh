#!/bin/bash

# This script performs pre-deployment checks to ensure the application is ready for production
# It verifies environment variables, database connection, and security settings

echo "=== RightPegMatch Pre-Deployment Check ==="
echo ""

# Color codes for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to check if an environment variable is set
check_env_var() {
  local var_name=$1
  local is_critical=$2
  
  if [[ -z "${!var_name}" ]]; then
    if [[ "$is_critical" == "critical" ]]; then
      echo -e "${RED}❌ Critical variable $var_name is not set${NC}"
      ((critical_missing++))
    else
      echo -e "${YELLOW}⚠️  Optional variable $var_name is not set${NC}"
      ((optional_missing++))
    fi
    return 1
  else
    echo -e "${GREEN}✓ $var_name is set${NC}"
    return 0
  fi
}

# Variables to track missing environment variables
critical_missing=0
optional_missing=0

echo "Checking critical environment variables..."
check_env_var "DATABASE_URL" "critical"
check_env_var "SESSION_SECRET" "critical"
check_env_var "STRIPE_SECRET_KEY" "critical"
check_env_var "VITE_STRIPE_PUBLIC_KEY" "critical"
check_env_var "ANTHROPIC_API_KEY" "critical"
check_env_var "SENDGRID_API_KEY" "critical"

echo ""
echo "Checking optional environment variables..."
check_env_var "STRIPE_WEBHOOK_SECRET" "optional"
check_env_var "NODE_ENV" "optional"

echo ""
echo "Checking database connection..."
# Use the check-db-connection script
npx tsx scripts/check-db-connection.ts
db_connection_status=$?

echo ""
echo "Checking for test data..."
# Count test users (usernames starting with "test")
if [[ -n "$DATABASE_URL" ]]; then
  export PGPASSWORD=$(echo $DATABASE_URL | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p')
  export PGUSER=$(echo $DATABASE_URL | sed -n 's/.*:\/\/\([^:]*\):.*/\1/p')
  export PGHOST=$(echo $DATABASE_URL | sed -n 's/.*@\([^:]*\):.*/\1/p')
  export PGPORT=$(echo $DATABASE_URL | sed -n 's/.*:\([0-9]*\)\/.*/\1/p')
  export PGDATABASE=$(echo $DATABASE_URL | sed -n 's/.*\/\(.*\)/\1/p')
  
  test_user_count=$(psql -t -c "SELECT COUNT(*) FROM users WHERE username LIKE 'test%';" | tr -d ' ')
  if [[ "$test_user_count" -gt 0 ]]; then
    echo -e "${YELLOW}⚠️  $test_user_count test users found in the database${NC}"
    echo "   Consider running scripts/clean-test-data.ts before production deployment"
  else
    echo -e "${GREEN}✓ No test users found in the database${NC}"
  fi
else
  echo -e "${YELLOW}⚠️  Skipping test data check as DATABASE_URL is not set${NC}"
fi

echo ""
echo "Checking for security vulnerabilities..."
npm audit --production

echo ""
echo "=== Pre-Deployment Check Summary ==="
if [[ $critical_missing -gt 0 ]]; then
  echo -e "${RED}❌ $critical_missing critical environment variables are missing${NC}"
  echo "   The application will not function properly without these variables"
else
  echo -e "${GREEN}✓ All critical environment variables are set${NC}"
fi

if [[ $optional_missing -gt 0 ]]; then
  echo -e "${YELLOW}⚠️  $optional_missing optional environment variables are missing${NC}"
  echo "   The application may have limited functionality without these variables"
else
  echo -e "${GREEN}✓ All optional environment variables are set${NC}"
fi

if [[ $db_connection_status -eq 0 ]]; then
  echo -e "${GREEN}✓ Database connection successful${NC}"
else
  echo -e "${RED}❌ Database connection failed${NC}"
  echo "   Please check your DATABASE_URL and ensure the database is accessible"
fi

echo ""
if [[ $critical_missing -eq 0 && $db_connection_status -eq 0 ]]; then
  echo -e "${GREEN}✅ The application is ready for deployment${NC}"
  exit 0
else
  echo -e "${RED}❌ The application is NOT ready for deployment${NC}"
  echo "   Please fix the issues above before deploying"
  exit 1
fi