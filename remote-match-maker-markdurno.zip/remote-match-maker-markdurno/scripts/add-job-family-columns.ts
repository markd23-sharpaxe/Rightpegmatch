/**
 * This script adds the jobFamily column to the job_roles and jobs tables
 */
import { pool } from "../server/db";
import { JobFamily } from "../shared/schema";

async function addJobFamilyColumns() {
  const client = await pool.connect();
  
  try {
    console.log("Starting migration to add job family columns...");
    
    // Start a transaction
    await client.query('BEGIN');
    
    // Check if jobFamily column exists in job_roles table
    const checkJobRolesColumn = await client.query(`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'job_roles' AND column_name = 'job_family'
    `);
    
    // Add column to job_roles if it doesn't exist
    if (checkJobRolesColumn.rows.length === 0) {
      console.log("Adding job_family column to job_roles table...");
      await client.query(`
        ALTER TABLE job_roles
        ADD COLUMN job_family TEXT DEFAULT '${JobFamily.Other}'
      `);
      console.log("Successfully added job_family column to job_roles table");
    } else {
      console.log("job_family column already exists in job_roles table");
    }
    
    // Check if jobFamily column exists in jobs table
    const checkJobsColumn = await client.query(`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'jobs' AND column_name = 'job_family'
    `);
    
    // Add column to jobs if it doesn't exist
    if (checkJobsColumn.rows.length === 0) {
      console.log("Adding job_family column to jobs table...");
      await client.query(`
        ALTER TABLE jobs
        ADD COLUMN job_family TEXT DEFAULT '${JobFamily.Other}'
      `);
      console.log("Successfully added job_family column to jobs table");
    } else {
      console.log("job_family column already exists in jobs table");
    }
    
    // Check if job_matches_cache table has the new columns
    const checkUserJobFamilyColumn = await client.query(`
      SELECT column_name
      FROM information_schema.columns
      WHERE table_name = 'job_matches_cache' AND column_name = 'user_job_family'
    `);
    
    if (checkUserJobFamilyColumn.rows.length === 0) {
      console.log("Adding job family match columns to job_matches_cache table...");
      await client.query(`
        ALTER TABLE job_matches_cache
        ADD COLUMN user_job_family TEXT DEFAULT '${JobFamily.Other}',
        ADD COLUMN job_job_family TEXT DEFAULT '${JobFamily.Other}',
        ADD COLUMN job_family_match BOOLEAN DEFAULT FALSE
      `);
      console.log("Successfully added job family match columns to job_matches_cache table");
    } else {
      console.log("Job family match columns already exist in job_matches_cache table");
    }
    
    // Commit the transaction
    await client.query('COMMIT');
    
    console.log("Migration completed successfully");
  } catch (error) {
    // Rollback the transaction in case of any error
    await client.query('ROLLBACK');
    console.error("Migration failed:", error);
    throw error;
  } finally {
    // Release the client back to the pool
    client.release();
  }
}

// Run the migration
addJobFamilyColumns()
  .then(() => {
    console.log("Database migration completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Migration failed:", error);
    process.exit(1);
  });