/**
 * This script adds job term columns to the jobs table
 */
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function addJobTermColumns() {
  try {
    console.log("Adding job term columns to jobs table...");
    
    // Check if columns already exist
    const checkResult = await db.execute(sql`
      SELECT column_name 
      FROM information_schema.columns 
      WHERE table_name = 'jobs' AND column_name = 'start_date'
    `);
    
    if (checkResult.rows.length > 0) {
      console.log("Job term columns already exist, skipping...");
      return;
    }

    // Add the new columns
    await db.execute(sql`
      ALTER TABLE jobs
      ADD COLUMN start_date TIMESTAMP,
      ADD COLUMN end_date TIMESTAMP,
      ADD COLUMN start_date_flexibility TEXT DEFAULT 'exact',
      ADD COLUMN is_permanent BOOLEAN DEFAULT false
    `);
    
    console.log("Job term columns added successfully!");
  } catch (error) {
    console.error("Error adding job term columns:", error);
    throw error;
  }
}

// Run the migration
addJobTermColumns()
  .then(() => {
    console.log("Migration completed successfully");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Migration failed:", error);
    process.exit(1);
  });