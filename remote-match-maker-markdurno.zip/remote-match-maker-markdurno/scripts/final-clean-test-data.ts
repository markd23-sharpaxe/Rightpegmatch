/**
 * This script removes test data from the database before production deployment
 * It deletes:
 * 1. Users with usernames starting with "test"
 * 2. Jobs created by test users
 * 3. Orphaned data (applications, matches, messages, etc.)
 * 
 * This script handles foreign key constraints by deleting data in the correct order.
 */

import { db } from "../server/db";
import { ilike, inArray, sql } from "drizzle-orm";
import { 
  users, jobs, jobApplications, jobMatchesCache, availabilitySlots,
  userSkills, userJobRoles, userSubscriptions, passwordResetTokens, messages,
  jobRequiredSkills, userQualifications
} from "../shared/schema";

async function cleanProductionData() {
  console.log("Starting test data cleanup for production...");
  
  try {
    // Step 1: Find all test users (usernames starting with "test" or "Testing")
    const testUsers = await db.select({ id: users.id, username: users.username })
      .from(users)
      .where(ilike(users.username, "test%"));
    
    if (testUsers.length === 0) {
      console.log("No test users found. Nothing to clean up.");
      return;
    }
    
    const testUserIds = testUsers.map(user => user.id);
    console.log(`Found ${testUsers.length} test users to remove: ${testUsers.map(u => u.username).join(', ')}`);
    
    // Step 2: Find jobs posted by test users
    const testJobs = await db.select({ id: jobs.id })
      .from(jobs)
      .where(inArray(jobs.employerId, testUserIds));
    
    const testJobIds = testJobs.map(job => job.id);
    console.log(`Found ${testJobs.length} jobs posted by test users to remove`);
    
    // Step 3: Find applications related to test users or jobs
    const jobApplicationsFromTestUsers = await db.select({ id: jobApplications.id })
      .from(jobApplications)
      .where(inArray(jobApplications.jobseekerId, testUserIds));
      
    const jobApplicationsForTestJobs = await db.select({ id: jobApplications.id })
      .from(jobApplications)
      .where(inArray(jobApplications.jobId, testJobIds));
      
    const allTestApplicationIds = [
      ...jobApplicationsFromTestUsers.map(app => app.id),
      ...jobApplicationsForTestJobs.map(app => app.id)
    ];
    
    console.log(`Found ${allTestApplicationIds.length} job applications related to test data`);
    
    // Begin transaction
    await db.transaction(async (tx) => {
      // Step 4: Delete in order of dependencies
      
      // 4.1: Delete messages related to test applications
      if (allTestApplicationIds.length > 0) {
        const deletedMessages = await tx.delete(messages)
          .where(inArray(messages.applicationId, allTestApplicationIds))
          .returning();
        console.log(`Deleted ${deletedMessages.length} application messages`);
      }
      
      // 4.2: Delete job applications
      if (allTestApplicationIds.length > 0) {
        const deletedApplications = await tx.delete(jobApplications)
          .where(inArray(jobApplications.id, allTestApplicationIds))
          .returning();
        console.log(`Deleted ${deletedApplications.length} job applications`);
      }
      
      // 4.3: Delete job matches for test users using raw SQL to avoid schema mismatch
      if (testUserIds.length > 0) {
        const { rowCount } = await tx.execute(
          sql`DELETE FROM job_matches_cache WHERE user_id IN (${sql.join(testUserIds, sql`, `)})`
        );
        console.log(`Deleted ${rowCount} job matches for test users`);
      }
      
      if (testJobIds.length > 0) {
        const { rowCount } = await tx.execute(
          sql`DELETE FROM job_matches_cache WHERE job_id IN (${sql.join(testJobIds, sql`, `)})`
        );
        console.log(`Deleted ${rowCount} job matches for test jobs`);
      }
      
      // 4.4: Delete job required skills for test jobs
      if (testJobIds.length > 0) {
        const deletedJobSkills = await tx.delete(jobRequiredSkills)
          .where(inArray(jobRequiredSkills.jobId, testJobIds))
          .returning();
        console.log(`Deleted ${deletedJobSkills.length} job required skills`);
      }
      
      // 4.5: Delete test jobs
      if (testJobIds.length > 0) {
        const deletedJobs = await tx.delete(jobs)
          .where(inArray(jobs.id, testJobIds))
          .returning();
        console.log(`Deleted ${deletedJobs.length} test jobs`);
      }
      
      // 4.6: Delete user related data
      if (testUserIds.length > 0) {
        // Delete user subscriptions
        const deletedSubscriptions = await tx.delete(userSubscriptions)
          .where(inArray(userSubscriptions.userId, testUserIds))
          .returning();
        console.log(`Deleted ${deletedSubscriptions.length} user subscriptions`);
        
        // Delete user qualifications
        const deletedQualifications = await tx.delete(userQualifications)
          .where(inArray(userQualifications.userId, testUserIds))
          .returning();
        console.log(`Deleted ${deletedQualifications.length} user qualifications`);
        
        // Delete user skills
        const deletedSkills = await tx.delete(userSkills)
          .where(inArray(userSkills.userId, testUserIds))
          .returning();
        console.log(`Deleted ${deletedSkills.length} user skills`);
        
        // Delete user job roles
        const deletedRoles = await tx.delete(userJobRoles)
          .where(inArray(userJobRoles.userId, testUserIds))
          .returning();
        console.log(`Deleted ${deletedRoles.length} user job roles`);
        
        // Delete availability slots
        const deletedSlots = await tx.delete(availabilitySlots)
          .where(inArray(availabilitySlots.userId, testUserIds))
          .returning();
        console.log(`Deleted ${deletedSlots.length} availability slots`);
        
        // Delete password reset tokens
        const deletedTokens = await tx.delete(passwordResetTokens)
          .where(inArray(passwordResetTokens.userId, testUserIds))
          .returning();
        console.log(`Deleted ${deletedTokens.length} password reset tokens`);
      }
      
      // 4.7: Finally, delete test users
      if (testUserIds.length > 0) {
        const deletedUsers = await tx.delete(users)
          .where(inArray(users.id, testUserIds))
          .returning();
        console.log(`Deleted ${deletedUsers.length} test users`);
      }
    });
    
    console.log("Test data cleanup completed successfully!");
  } catch (error) {
    console.error("Error cleaning test data:", error);
    throw error;
  }
}

// Run the script
cleanProductionData()
  .then(() => {
    console.log("Test data cleanup completed!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Error in test data cleanup:", error);
    process.exit(1);
  });