/**
 * This script updates job roles in the database with the new list provided
 */

import { pool } from "../server/db";
import { drizzle } from "drizzle-orm/node-postgres";
import { jobRoles, insertJobRoleSchema, type JobRole } from "../shared/schema";
import { eq } from "drizzle-orm";

// Define the job title type that matches our input structure
interface JobTitleEntry {
  name: string;
  category: string;
}

// Connect to database
const db = drizzle(pool);

// List from the provided document
const jobTitleList: JobTitleEntry[] = [
  { name: "Software Engineer", category: "Engineering" },
  { name: "Developer (Fullstack, Frontend, Backend)", category: "Engineering" },
  { name: "Data Analyst", category: "Data" },
  { name: "Data Scientist", category: "Data" },
  { name: "Cybersecurity Analyst", category: "Security" },
  { name: "Cybersecurity Engineer", category: "Security" },
  { name: "IT Architect", category: "Engineering" },
  { name: "Computer Support Specialist", category: "Support" },
  { name: "AI Prompt Engineer", category: "AI" },
  { name: "Open-Source Machine Learning Engineer", category: "AI" },
  { name: "DevOps Specialist", category: "DevOps" },
  { name: "Sales Representative", category: "Sales" },
  { name: "Sales Development Representative", category: "Sales" },
  { name: "Marketing Manager", category: "Marketing" },
  { name: "Product Marketing Manager", category: "Marketing" },
  { name: "Performance Marketing Executive", category: "Marketing" },
  { name: "Digital Marketer", category: "Marketing" },
  { name: "Social Media Manager", category: "Marketing" },
  { name: "Business Development Manager", category: "Business" },
  { name: "Business Development Representative", category: "Business" },
  { name: "Account Manager", category: "Sales" },
  { name: "Account Executive", category: "Sales" },
  { name: "Customer Service Operator", category: "Support" },
  { name: "Customer Service Representative", category: "Support" },
  { name: "Customer Service Specialist", category: "Support" },
  { name: "Virtual Assistant", category: "Administrative" },
  { name: "Content Writer", category: "Content" },
  { name: "Copywriter", category: "Content" },
  { name: "Freelance Writer", category: "Content" },
  { name: "Technical Writer", category: "Content" },
  { name: "Transcriptionist", category: "Content" },
  { name: "Editor (video and audio)", category: "Media" },
  { name: "Online Tutor", category: "Education" },
  { name: "Online Teacher", category: "Education" },
  { name: "Financial Analyst", category: "Finance" },
  { name: "Accountant", category: "Finance" },
  { name: "Global Therapist", category: "Healthcare" },
  { name: "Remote Nurse Assessor", category: "Healthcare" },
  { name: "Interim Chief Operating Officer (COO)", category: "Executive" },
  { name: "Senior Pentester", category: "Security" },
  { name: "Engineering Manager", category: "Management" },
  { name: "Regional Manager", category: "Management" },
  { name: "Account Manager - Digital Marketing", category: "Marketing" },
  { name: "Marketing Manager, Audience Retention", category: "Marketing" },
  { name: "Senior Territory Account Executive", category: "Sales" },
  { name: "Rural Qualified Accountant", category: "Finance" },
  { name: "PIP Assessment Nurse", category: "Healthcare" },
  { name: "Clinical Assessor – Nurse", category: "Healthcare" },
  { name: "Consultant Solicitor & Conveyancer", category: "Legal" },
  { name: "Civil Mechanical Engineering Manager", category: "Engineering" },
  { name: "Head of Regulatory Affairs - IGT-D", category: "Regulatory" },
  { name: "Embedded Products System Architect (Staff Engineer)", category: "Engineering" },
  { name: "Head of Technical Claims", category: "Insurance" },
  { name: "Retail Insight Manager", category: "Retail" },
  { name: "Web Developer", category: "Engineering" },
  { name: "UX/UI Designer", category: "Design" },
  { name: "HR Consultant", category: "HR" },
  { name: "Marketing Consultant", category: "Marketing" },
  { name: "Graphic Designer", category: "Design" },
  { name: "Mobile App Developer", category: "Engineering" },
  { name: "Translator", category: "Language" },
  { name: "Personal Coach", category: "Coaching" },
  { name: "Video Editor", category: "Media" },
  { name: "Audio Editor", category: "Media" },
  { name: "Online Advertising Specialist", category: "Marketing" },
  { name: "Project Manager", category: "Management" },
  { name: "Information Security Analyst", category: "Security" },
  { name: "Chief Financial Officer (CFO)", category: "Executive" },
  { name: "AI Trainer", category: "AI" },
  { name: "Call Centre Operator", category: "Support" },
  { name: "Inbound Sales Representative", category: "Sales" },
  { name: "Spinal Injury Specialist", category: "Healthcare" },
  { name: "Experienced Interpreter", category: "Language" },
  { name: "Freelance Remote Filipino Interpreter", category: "Language" },
  { name: "Supporter Care Administrator (Customer Service)", category: "Support" },
  { name: "Estimator", category: "Construction" },
  { name: "LEAD DRILLER - WINDOW SAMPLING", category: "Construction" },
  { name: "Entry Roles in Human Resources (HR)", category: "HR" },
  { name: "Self Employed Fitted Furniture Technical Surveyor", category: "Construction" },
  { name: "Finance Director", category: "Finance" },
  { name: "Senior Financial Controller", category: "Finance" },
  { name: "Assistant CFO", category: "Finance" },
  { name: "Computer Support Analyst", category: "Support" },
  { name: "IT Support Professional", category: "Support" },
  { name: "Security Network Engineer", category: "Security" },
  { name: "IT Auditor", category: "Security" },
  { name: "Security Architect", category: "Security" },
  { name: "UI Designer", category: "Design" },
  { name: "Interaction Designer", category: "Design" },
  { name: "Visual Designer", category: "Design" },
  { name: "AI Product Manager", category: "AI" },
  { name: "Automation Tester", category: "QA" },
  { name: "Prompt Engineer", category: "AI" },
  { name: "Private Personal Assistant", category: "Administrative" },
  { name: "Motion Graphics Designer", category: "Design" },
  { name: "Post-Production Specialist", category: "Media" },
  { name: "Technical Content Writer", category: "Content" },
  { name: "SEO Content Writer", category: "Content" },
  { name: "ESL Tutor", category: "Education" },
  { name: "Math and Science Tutor", category: "Education" },
  { name: "Coding/Programming Tutor", category: "Education" },
  { name: "Test Prep Tutor", category: "Education" },
  { name: "Language Tutor", category: "Education" },
  { name: "Head of Business Development", category: "Business" },
  { name: "Inbound Growth Engineer", category: "Marketing" },
  { name: "Junior Business Development Representative", category: "Business" },
  { name: "Licensed Marriage & Family Therapist (LMFT)", category: "Healthcare" },
  { name: "Expert/Tutor in STEM Subjects", category: "Education" },
  { name: "Chief Technology Officer (CTO)", category: "Executive" },
  { name: "Director of Investments & Asset Management", category: "Finance" },
  { name: "QA Engineer", category: "QA" },
  { name: "Remote Digital Specialist", category: "Marketing" },
  { name: "Senior Golang Developer", category: "Engineering" },
  { name: "Senior ERP Software Engineer", category: "Engineering" },
  { name: "Senior Magento Developer", category: "Engineering" },
  { name: "Senior Shopify Developer", category: "Engineering" },
  { name: "Senior React Native Developer", category: "Engineering" },
  { name: "Senior Laravel Developer", category: "Engineering" },
  { name: "Senior Enterprise Application Developer", category: "Engineering" },
  { name: "Senior Sharepoint Developer", category: "Engineering" },
  { name: "Senior Enterprise Systems Engineer", category: "Engineering" },
  { name: "Senior Microsoft PowerBI Developer", category: "Data" },
  { name: "Senior Customer Success Manager", category: "Support" },
  { name: "Languages teacher", category: "Education" },
  { name: "AI (LLM) Fullstack Engineer", category: "AI" },
  { name: "Forex / Cryptocurrency Trader", category: "Finance" },
  { name: "SQL Data Analyst", category: "Data" },
  { name: "Product Marketing Manager", category: "Marketing" },
  { name: "Backend Sales Manager", category: "Sales" },
  { name: "Senior Product Designer", category: "Design" },
  { name: "Performance Marketing Executive", category: "Marketing" },
  { name: "Equity/Option Trader", category: "Finance" },
  { name: "Senior Systems Engineer", category: "Engineering" },
  { name: "Enterprise Account Executive", category: "Sales" },
  { name: "Network Solutions Architect", category: "Engineering" },
  { name: "Senior Geospatial Machine Learning Engineer", category: "AI" },
  { name: "Manager, Migrations Engineering", category: "Engineering" },
  { name: "Senior Key Account Executive", category: "Sales" },
  { name: "Frontend Engineer", category: "Engineering" },
  { name: "Organized Link Building Specialist", category: "Marketing" },
  { name: "Cloud Engineer", category: "Engineering" },
  { name: "Azure Devops Engineer", category: "DevOps" },
  { name: "Solutions Architect", category: "Engineering" },
  { name: "Security Engineer", category: "Security" },
  { name: "Security Infrastructure Engineer", category: "Security" },
  { name: "Ubuntu Security Manager", category: "Security" },
  { name: "Financial Professional", category: "Finance" },
  { name: "Senior Full Stack Engineer", category: "Engineering" },
  { name: "Lifecycle Manager", category: "Management" },
  { name: "Technical Governance Researcher", category: "Research" },
  { name: "LV - HV Engineer", category: "Engineering" },
  { name: "Cable Puller", category: "Construction" },
  { name: "Director, Business Development", category: "Business" },
  { name: "Principal Rendering Engineer", category: "Engineering" },
  { name: "Database Administrator", category: "Data" },
  { name: "Coffee Equipment Engineer", category: "Specialist" },
  { name: "Engineering Manager, Reporting and Analytics", category: "Management" },
  { name: "Renewals & Retentions Phone Agent", category: "Sales" },
  { name: "Academic Mentor", category: "Education" },
  { name: "Administrator", category: "Administrative" },
  { name: "Commercial Finance Broker", category: "Finance" },
  { name: "Commercial Treasury Controller", category: "Finance" },
  { name: "Clinical Pharmacist", category: "Healthcare" },
  { name: "Appointment Maker", category: "Administrative" },
  { name: "Sales Consultant", category: "Sales" },
  { name: "Lead Generator", category: "Sales" },
  { name: "Lifts and Procurement Assistant", category: "Administrative" },
  { name: "Assistant Property Manager", category: "Real Estate" },
  { name: "Social Media Specialist", category: "Marketing" },
  { name: "Social Media Expert", category: "Marketing" },
  { name: "Social Media Intern", category: "Marketing" },
  { name: "Marketing Intern", category: "Marketing" },
  { name: "Junior Motion Designer", category: "Design" },
  { name: "Social Media Video Editor", category: "Media" },
  { name: "CV Writer", category: "Content" },
  { name: "Head of Product Development", category: "Product" },
  { name: "Area Sales Manager", category: "Sales" },
  { name: "Sales Assistant", category: "Sales" },
  { name: "Sales Executive", category: "Sales" },
  { name: "Online Maths Tutor", category: "Education" },
  { name: "Math Professor", category: "Education" },
  { name: "Mathematics Teacher", category: "Education" },
  { name: "Research Scientist (Biology)", category: "Research" },
  { name: "Academic Research Assistant", category: "Research" },
  { name: "Client Services Specialist", category: "Support" },
  { name: "Recruitment Consultant", category: "HR" },
  { name: "Audience Acquisition Executive", category: "Marketing" },
  { name: "Regional Account Manager", category: "Sales" },
  { name: "National Engineer Surveyor", category: "Engineering" },
  { name: "Social Media Posts Assistant", category: "Marketing" },
  { name: "Sales/Marketing Assistant", category: "Marketing" },
  { name: "Desk Based Sales Executive", category: "Sales" },
  { name: "High Ticket Appointment Setter", category: "Sales" },
  { name: "Lead Generation Executive", category: "Sales" },
  { name: "Sales Leader", category: "Sales" },
  { name: "Social Media Growth", category: "Marketing" },
  { name: "Dental Nurse", category: "Healthcare" },
  { name: "STRAP & Personnel Compliance Manager", category: "HR" },
  { name: "Appointment Coordinator", category: "Administrative" },
  { name: "Pharmacy Technician", category: "Healthcare" },
  { name: "Customer Service Agent", category: "Support" },
  { name: "Customer Care Associate", category: "Support" },
  { name: "Recovery Driver", category: "Transport" },
  { name: "European Road Freight Coordinator", category: "Logistics" },
  { name: "Executive Assistant", category: "Administrative" },
  { name: "Dentist", category: "Healthcare" },
  { name: "Writing Tutor", category: "Education" },
  { name: "Communications Manager", category: "Marketing" },
  { name: "Secondary Teacher", category: "Education" },
  { name: "AI Content Writer", category: "AI" },
  { name: "Biostatistician", category: "Data" },
  { name: "Actuary", category: "Finance" },
  { name: "Statistician", category: "Data" },
  { name: "Primary Teacher", category: "Education" },
  { name: "Professor", category: "Education" },
  { name: "Research and Development Mathematician", category: "Research" },
  { name: "Service Coordinator", category: "Administrative" },
  { name: "Referrals Administrator", category: "Administrative" },
  { name: "Autism Nurse", category: "Healthcare" },
  { name: "Clinical Lead ADHD Practitioner", category: "Healthcare" },
  { name: "ADHD Nurse Practitioner", category: "Healthcare" },
  { name: "Team Manager ADHD Practitioner", category: "Healthcare" },
  { name: "Credit Hire Pre-Litigation Recoveries Specialist", category: "Legal" },
  { name: "Frailty Practitioner", category: "Healthcare" },
  { name: "Senior Occupational Therapist", category: "Healthcare" },
  { name: "Painter", category: "Arts" }
];

// Function to insert or update job roles
async function updateJobRoles() {
  console.log("Starting job role update...");
  
  try {
    // Get existing roles
    const existingRoles = await db.select().from(jobRoles);
    
    // Create a map for exact matching (case insensitive)
    const existingRolesMap = new Map();
    existingRoles.forEach(role => {
      existingRolesMap.set(role.name.toLowerCase(), role);
    });
    
    console.log(`Found ${existingRoles.length} existing roles.`);
    
    // Track new roles to add
    const newRolesToAdd: JobTitleEntry[] = [];
    
    // Filter list for new roles
    for (const jobTitle of jobTitleList) {
      const lowerCaseName = jobTitle.name.toLowerCase();
      
      // Only add if not already exists (case insensitive)
      if (!existingRolesMap.has(lowerCaseName)) {
        newRolesToAdd.push(jobTitle);
      }
    }
    
    console.log(`Adding ${newRolesToAdd.length} new job roles.`);
    
    // Insert new roles one by one to handle any unexpected duplicates
    let successCount = 0;
    
    for (const newRole of newRolesToAdd) {
      try {
        console.log(`Adding role: ${newRole.name}`);
        const insertedRole = await db.insert(jobRoles).values(newRole).returning();
        if (insertedRole.length > 0) {
          successCount++;
        }
      } catch (insertError) {
        console.error(`Failed to add role "${newRole.name}":`, insertError.message);
      }
    }
    
    console.log(`Successfully added ${successCount} new job roles.`);
    console.log("Job role update completed successfully!");
  } catch (error) {
    console.error("Error updating job roles:", error);
  } finally {
    await pool.end();
  }
}

// Run the function
updateJobRoles();