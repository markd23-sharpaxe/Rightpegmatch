#!/bin/bash

# This script cleans the database for production deployment
# WARNING: This will delete ALL data in the database
# Use this script only for initial production setup

echo "=== RightPegMatch Database Cleanup ==="
echo ""

# Verify environment is not production
if [ "$NODE_ENV" == "production" ]; then
  echo "❌ This script should not be run in a production environment."
  echo "Please set NODE_ENV to something other than 'production' to proceed."
  exit 1
fi

# Check if the DATABASE_URL environment variable is set
if [ -z "$DATABASE_URL" ]; then
  echo "❌ DATABASE_URL environment variable is not set. Please set it before running this script."
  exit 1
fi

# Ask for confirmation
echo "⚠️  WARNING: This will DELETE ALL DATA in the database."
echo "This action is irreversible and should only be used for initial production setup."
read -p "Are you sure you want to proceed? (y/N): " confirmation
confirmation=${confirmation:-n}

if [ "$confirmation" != "y" ] && [ "$confirmation" != "Y" ]; then
  echo "Operation cancelled."
  exit 0
fi

# Double confirmation for safety
read -p "Type 'delete all data' to confirm: " confirm_text

if [ "$confirm_text" != "delete all data" ]; then
  echo "Confirmation text does not match. Operation cancelled."
  exit 0
fi

echo ""
echo "Cleaning database..."

# Connect to the database and drop all tables
export PGPASSWORD=$(echo $DATABASE_URL | sed -n 's/.*:\/\/[^:]*:\([^@]*\)@.*/\1/p')
export PGUSER=$(echo $DATABASE_URL | sed -n 's/.*:\/\/\([^:]*\):.*/\1/p')
export PGHOST=$(echo $DATABASE_URL | sed -n 's/.*@\([^:]*\):.*/\1/p')
export PGPORT=$(echo $DATABASE_URL | sed -n 's/.*:\([0-9]*\)\/.*/\1/p')
export PGDATABASE=$(echo $DATABASE_URL | sed -n 's/.*\/\(.*\)/\1/p')

# Get list of all tables except the session table
tables=$(psql -t -c "SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename != 'session';" | tr -d ' ')

# Drop all tables in a transaction
psql -c "BEGIN;
$(echo "$tables" | while read table; do echo "DROP TABLE IF EXISTS \"$table\" CASCADE;"; done)
COMMIT;"

echo ""
echo "✅ Database cleaned successfully."
echo ""
echo "Running migrations to recreate schema..."
bash scripts/run-migrations.sh

echo ""
echo "✅ Database preparation complete."