/**
 * This script updates existing job records with the appropriate job family based on their job role
 */
import { db } from "../server/db";
import { JobFamily, jobRoles, jobs } from "../shared/schema";
import { eq } from "drizzle-orm";

async function updateJobRecordFamilies() {
  try {
    console.log("Starting job record family update...");
    
    // Get all job roles with their job families
    const roles = await db.select().from(jobRoles);
    console.log(`Found ${roles.length} job roles with families`);
    
    // Create a mapping of job role IDs to job families
    const roleFamilyMap = new Map<number, string>();
    for (const role of roles) {
      roleFamilyMap.set(role.id, role.jobFamily || JobFamily.Other);
    }
    
    // Get all jobs
    const jobRecords = await db.select().from(jobs);
    console.log(`Found ${jobRecords.length} job records to process`);
    
    let updateCount = 0;
    
    // Process each job
    for (const job of jobRecords) {
      if (job.jobRoleId) {
        const jobFamily = roleFamilyMap.get(job.jobRoleId) || JobFamily.Other;
        
        // Update the job record
        await db.update(jobs)
          .set({ jobFamily })
          .where(eq(jobs.id, job.id));
        
        console.log(`Updated job: ${job.title} (ID: ${job.id}) -> ${jobFamily}`);
        updateCount++;
      } else {
        console.log(`Skipping job: ${job.title} (ID: ${job.id}) - No job role assigned`);
      }
    }
    
    console.log(`Successfully updated ${updateCount} jobs with job families`);
  } catch (error) {
    console.error("Error updating job families:", error);
  }
}

updateJobRecordFamilies()
  .then(() => {
    console.log("Job record family update completed");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Failed to update job record families:", error);
    process.exit(1);
  });