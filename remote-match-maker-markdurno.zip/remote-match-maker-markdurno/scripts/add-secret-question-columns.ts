/**
 * This script adds the secretQuestion and secretAnswer columns to the users table
 */
import { db } from "../server/db";
import { sql } from "drizzle-orm";

async function addSecretQuestionColumns() {
  try {
    console.log("Adding secret question columns to users table...");
    
    // Add secretQuestion column
    const addSecretQuestionQuery = sql`
      ALTER TABLE users 
      ADD COLUMN IF NOT EXISTS secret_question TEXT,
      ADD COLUMN IF NOT EXISTS secret_answer TEXT;
    `;
    
    await db.execute(addSecretQuestionQuery);
    console.log("Secret question columns added successfully");
  } catch (error) {
    console.error("Error adding secret question columns:", error);
  } finally {
    process.exit(0);
  }
}

addSecretQuestionColumns();