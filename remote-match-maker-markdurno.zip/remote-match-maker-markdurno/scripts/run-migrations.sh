#!/bin/bash

# This script runs all necessary database migrations and ensures tables are up-to-date

echo "=== RightPegMatch Database Migrations ==="
echo ""

# Check if the DATABASE_URL environment variable is set
if [ -z "$DATABASE_URL" ]; then
  echo "❌ DATABASE_URL environment variable is not set. Please set it before running migrations."
  exit 1
fi

# Create missing tables and update schema
echo "Running Drizzle migrations..."
npx drizzle-kit push:pg

# Create indexes for job matching
echo ""
echo "Setting up job matching indexes..."
npx tsx scripts/build-job-matching-indexes.ts

# Check if the database is properly configured
echo ""
echo "Verifying database connection..."
npx tsx scripts/check-db-connection.ts

echo ""
echo "Database migrations completed successfully."