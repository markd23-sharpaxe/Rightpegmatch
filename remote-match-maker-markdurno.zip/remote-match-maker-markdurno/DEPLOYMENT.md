# Deployment Guide for RightPegMatch

This guide outlines the steps to prepare and deploy the RightPegMatch application to production.

## Prerequisites

Before deploying, make sure you have:

1. A Stripe account with API keys
2. A SendGrid account for email functionality 
3. An Anthropic account for AI matching

## Pre-Deployment Checklist

- [ ] Set all required environment variables (see Environment Variables section)
- [ ] Run pre-deployment check script:
  ```bash
  bash scripts/pre-deployment-check.sh
  ```
- [ ] Run database migrations to update schema:
  ```bash
  bash scripts/run-migrations.sh
  ```
- [ ] Clean test data from database (optional):
  ```bash
  npx tsx scripts/clean-test-data.ts
  ```
- [ ] Update dependencies to latest secure versions:
  ```bash
  bash scripts/update-dependencies.sh
  ```
- [ ] Verify that Stripe webhook is properly configured with signature verification
- [ ] Verify that Anthropic API key is using the correct model version (claude-3-7-sonnet-20250219)
- [ ] Test all critical user flows using the checklist in POST_DEPLOYMENT_CHECKLIST.md

## Environment Variables

The following environment variables must be set for the application to function properly:

```
# Database
DATABASE_URL=postgresql://...

# Stripe (Payment Processing)
STRIPE_SECRET_KEY=sk_...             # Stripe Secret API Key
VITE_STRIPE_PUBLIC_KEY=pk_...        # Stripe Public API Key
STRIPE_WEBHOOK_SECRET=whsec_...      # Stripe Webhook Signing Secret

# SendGrid (Email)
SENDGRID_API_KEY=SG...

# Anthropic (AI)
ANTHROPIC_API_KEY=sk-ant-...

# Session Management
SESSION_SECRET=some-strong-random-string
```

## Running Database Migrations

To add the required Stripe fields to the user subscriptions table:

```bash
bash scripts/run-migrations.sh
```

## Cleaning Database

There are two options for database cleaning:

### Option 1: Remove test data only
To remove only test users and their related data:

```bash
npx tsx scripts/final-clean-test-data.ts
```

### Option 2: Complete database reset
To completely reset the database (CAUTION: This permanently removes ALL data):

```bash
bash scripts/clean-database.sh
```

This script will prompt for confirmation before deleting data and will recreate the schema afterward.

## Stripe Webhook Configuration

For subscription management, configure the following webhook endpoints in your Stripe Dashboard:

1. Go to the [Stripe Dashboard](https://dashboard.stripe.com/webhooks)
2. Click "Add endpoint"
3. Set the endpoint URL to `https://your-domain.com/api/stripe-webhook`
4. Select the following events:
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
5. After creating the webhook, copy the "Signing Secret" 
6. Add this secret to your environment variables as `STRIPE_WEBHOOK_SECRET`

For enhanced security in production, update the webhook handler in `server/routes.ts` to verify the webhook signature:

```typescript
app.post("/api/stripe-webhook", async (req, res) => {
  const signature = req.headers['stripe-signature'];
  
  try {
    // Verify the event came from Stripe
    const event = stripe.webhooks.constructEvent(
      req.body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
    
    // Process the event...
    
  } catch (error) {
    console.error('Webhook signature verification failed:', error);
    return res.status(400).send(`Webhook Error: ${error.message}`);
  }
})
```

## Custom Domain Setup

There are two methods to connect your domain to RightPegMatch:

### Method 1: Direct DNS Setup (Preferred but Optional)

This method directly connects your domain to Replit:

1. **Deploy your application on Replit**
   - Use Replit's deployment feature to get your application online
   - This will initially be available at remote-match-maker-markdurno.replit.app

2. **Configure your custom domain in Replit**
   - Go to your project's deployment settings
   - Add the custom domain: rightpegmatch.com
   - Replit will provide you with DNS records to configure

3. **Set up DNS records with your domain registrar**
   - Log in to your domain registrar account (e.g., GoDaddy)
   - Configure the following DNS records:
     - For the root domain (rightpegmatch.com):
       - Add an A record pointing to Replit's IP address
     - For the www subdomain:
       - Add a CNAME record pointing to remote-match-maker-markdurno.replit.app

4. **Wait for DNS propagation and SSL setup**
   - DNS changes can take up to 48 hours to propagate globally
   - Replit will automatically provision an SSL certificate

### Method 2: Domain Forwarding (Simple Alternative)

This method uses your domain registrar's forwarding feature:

1. **Log into your GoDaddy account**
   - Go to your domain management page
   - Find "Forwarding" or "Redirect" settings

2. **Set up forwarding for the root domain**
   - Forward rightpegmatch.com to https://remote-match-maker-markdurno.replit.app
   - Enable "Forward with masking" (important!)
   - This keeps rightpegmatch.com in the address bar

3. **Set up forwarding for the www subdomain**
   - Forward www.rightpegmatch.com to https://remote-match-maker-markdurno.replit.app
   - Enable "Forward with masking" here too

4. **Verify the forwarding**
   - Visit rightpegmatch.com in your browser
   - You should see your Replit app, but the URL should remain rightpegmatch.com

5. **Update Stripe webhook URL**
   - If using Method 1: Set it to https://rightpegmatch.com/api/stripe-webhook
   - If using Method 2: Set it to https://remote-match-maker-markdurno.replit.app/api/stripe-webhook

### Troubleshooting

- If forwarding doesn't work immediately, GoDaddy may take some time to set it up
- For SSL issues, check our expanded troubleshooting section below
- Test your site in incognito/private mode to avoid cached DNS information

## Post-Deployment Verification

After deployment, verify the following:
- User registration/login works
- Profile editing and saving works
- Job posting works
- Job matching works
- Subscription payments work
- Account recovery via secret questions works
- Custom domain loads securely with valid SSL

## Security Considerations

- Ensure that the `SESSION_SECRET` is a strong, randomly generated value
- All API routes are protected with authentication checks
- Password reset functionality uses secure secret questions
- Stripe webhook endpoints are secured with signature verification
- API keys are stored as environment variables and never exposed to clients
- Regular security updates should be applied using the provided script:
  ```bash
  bash scripts/update-dependencies.sh
  ```

## Monitoring and Alerts

For production deployment, consider setting up the following monitoring:

1. **Server Health**: Monitor CPU, memory, and disk usage
2. **API Endpoint Performance**: Track response times and error rates
3. **Database Performance**: Monitor query performance and connection pool
4. **Stripe Webhook Events**: Track failed payments and subscription cancellations
5. **Error Logs**: Set up alerts for critical errors

## Troubleshooting

If you encounter issues with:

1. **Database Connections**: Verify DATABASE_URL is correct and the database server is accessible.
2. **Payments**: Check Stripe webhook logs and ensure keys are correct.
3. **AI Matching**: Verify the ANTHROPIC_API_KEY is valid.
4. **Email**: Check SendGrid activity logs for delivery issues.
5. **Job Matching**: If matching is slow, verify index tables are properly populated.
6. **Custom Domain & SSL**:
   - If DNS doesn't resolve, verify DNS records are correctly set at your registrar
   - If SSL certificate isn't provisioning, make sure DNS is correctly pointing to Replit
   - If getting certificate errors, wait 24-48 hours for proper SSL provisioning
   - If some resources load over HTTP (mixed content), update any hardcoded URLs in the code
   - If Stripe webhook fails, update the webhook URL in Stripe dashboard to use your custom domain

### Fixing "Unsupported Protocol" Error in Chrome

If Chrome shows an "unsupported protocol" error when accessing rightpegmatch.com:

1. **Check SSL Certificate Status**
   - This error typically occurs when the SSL certificate is missing, invalid, or using an outdated protocol
   - Visit the SSL debug endpoint to get detailed information: https://rightpegmatch.replit.app/api/debug/ssl

2. **Force HTTPS Redirect**
   - We've added a middleware that automatically redirects HTTP requests to HTTPS
   - This should help resolve protocol-related issues

3. **Clear Browser Cache and Cookies**
   - Sometimes Chrome caches SSL errors. Try:
     - Clearing browser cache and cookies
     - Using incognito/private browsing mode
     - Trying another browser like Firefox to isolate the issue

4. **Check SSL Protocol Version**
   - Chrome requires TLS 1.2 or higher
   - Older protocol versions (TLS 1.0, TLS 1.1) are no longer supported by modern browsers
   - Replit automatically uses modern TLS versions, but this may need up to 48 hours to fully propagate

5. **Verify DNS Records**
   - Incorrect DNS configuration can cause SSL issues
   - Ensure your A records point to the correct Replit IP addresses: `104.18.11.39` and `104.18.10.39`
   - Ensure your CNAME record for `www` points to your `yourapp.replit.app` domain

6. **Monitor SSL Certificate Generation**
   - Replit automatically generates SSL certificates through Let's Encrypt
   - This process can take 24-48 hours to complete
   - You can check certificate status using online tools like [SSL Labs](https://www.ssllabs.com/ssltest/)