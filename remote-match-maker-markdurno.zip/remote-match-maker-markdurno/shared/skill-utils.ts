/**
 * Skill Utilities for Standardizing Skills and Matching
 * 
 * This module handles skill standardization and matching,
 * ensuring that jobs and candidates can be matched accurately based on skills.
 */

import { Skill, UserSkill } from "./schema";

export interface SkillMatch {
  skill: Skill;
  strength: number; // 0-100 match strength
}

// Calculate the overlap between job required skills and user skills
export function calculateSkillMatch(
  jobRequiredSkills: number[],
  userSkills: Skill[]
): { matchPercentage: number; matchedSkills: SkillMatch[] } {
  if (!jobRequiredSkills?.length || !userSkills?.length) {
    return { matchPercentage: 0, matchedSkills: [] };
  }

  const userSkillIds = userSkills.map(skill => skill.id);
  
  // Find matching skills
  const matchedSkillIds = jobRequiredSkills.filter(skillId => 
    userSkillIds.includes(skillId)
  );
  
  // Calculate match percentage
  const matchPercentage = Math.round(
    (matchedSkillIds.length / jobRequiredSkills.length) * 100
  );
  
  // Create detailed skill matches
  const matchedSkills: SkillMatch[] = matchedSkillIds.map(skillId => {
    const skill = userSkills.find(s => s.id === skillId)!;
    return {
      skill,
      strength: 100 // For now all matches are 100% strength
    };
  });
  
  return { matchPercentage, matchedSkills };
}

// Categorize skills by type to improve organization
export const skillCategories = [
  { id: 'programming', name: 'Programming & Development' },
  { id: 'design', name: 'Design & Creative' },
  { id: 'marketing', name: 'Marketing & Communications' },
  { id: 'business', name: 'Business & Management' },
  { id: 'data', name: 'Data Science & Analytics' },
  { id: 'engineering', name: 'Engineering & Architecture' },
  { id: 'writing', name: 'Writing & Content' },
  { id: 'admin', name: 'Administrative & Support' },
  { id: 'legal', name: 'Legal & Finance' },
  { id: 'other', name: 'Other Skills' }
];

// Get standardized skills based on category
export function getStandardizedSkills(): { categoryId: string; name: string; skills: string[] }[] {
  return [
    {
      categoryId: 'programming',
      name: 'Programming & Development',
      skills: [
        'JavaScript', 'TypeScript', 'Python', 'Java', 'C#', 'C++', 'PHP', 'Ruby', 'Swift',
        'React', 'Angular', 'Vue.js', 'Node.js', 'Django', 'Flask', 'Spring Boot',
        'ASP.NET', 'Express.js', 'Ruby on Rails', 'Android Development', 'iOS Development',
        'AWS', 'Azure', 'Google Cloud', 'Docker', 'Kubernetes', 'DevOps',
        'REST API', 'GraphQL', 'MongoDB', 'PostgreSQL', 'MySQL', 'SQL Server',
        'Git', 'Jenkins', 'CI/CD', 'Test Automation', 'TDD', 'Agile', 'Scrum'
      ]
    },
    {
      categoryId: 'design',
      name: 'Design & Creative',
      skills: [
        'UI Design', 'UX Design', 'Graphic Design', 'Web Design', 'Adobe Photoshop',
        'Adobe Illustrator', 'Adobe XD', 'Figma', 'Sketch', 'InDesign',
        'Animation', '3D Modeling', 'Video Editing', 'Motion Graphics',
        'Branding', 'Typography', 'Illustration', 'Logo Design', 'Product Design'
      ]
    },
    {
      categoryId: 'marketing',
      name: 'Marketing & Communications',
      skills: [
        'Digital Marketing', 'SEO', 'SEM', 'Social Media Marketing',
        'Content Marketing', 'Email Marketing', 'Marketing Automation',
        'Google Analytics', 'PPC', 'CRO', 'Growth Hacking',
        'Market Research', 'Brand Management', 'Public Relations',
        'Copywriting', 'Blogging', 'CRM', 'Community Management'
      ]
    },
    {
      categoryId: 'business',
      name: 'Business & Management',
      skills: [
        'Project Management', 'Product Management', 'Business Analysis',
        'Strategy', 'Leadership', 'Team Management', 'Operations Management',
        'Sales', 'Account Management', 'Client Relations', 'Negotiation',
        'Stakeholder Management', 'Process Improvement', 'Change Management',
        'Risk Management', 'Budgeting', 'Resource Planning'
      ]
    },
    {
      categoryId: 'data',
      name: 'Data Science & Analytics',
      skills: [
        'Data Analysis', 'Machine Learning', 'Deep Learning', 'Statistics',
        'R', 'Python for Data Science', 'SQL for Analysis', 'Power BI',
        'Tableau', 'Data Visualization', 'Big Data', 'Hadoop', 'Spark',
        'Natural Language Processing', 'Computer Vision', 'Predictive Modeling',
        'A/B Testing', 'Data Mining', 'Data Engineering'
      ]
    },
    {
      categoryId: 'writing',
      name: 'Writing & Content',
      skills: [
        'Content Writing', 'Technical Writing', 'Copywriting', 'Editing',
        'Proofreading', 'SEO Writing', 'Blog Writing', 'Article Writing',
        'Creative Writing', 'Research', 'Journalism', 'Storytelling',
        'Scriptwriting', 'Grant Writing', 'Documentation'
      ]
    },
    {
      categoryId: 'admin',
      name: 'Administrative & Support',
      skills: [
        'Virtual Assistance', 'Data Entry', 'Calendar Management',
        'Customer Support', 'Email Management', 'MS Office', 'Google Workspace',
        'Bookkeeping', 'Transcription', 'Scheduling', 'CRM Management',
        'File Organization', 'Phone Support', 'Office Administration'
      ]
    }
  ];
}

// Normalize skill names for matching
export function normalizeSkillName(name: string): string {
  return name.toLowerCase().trim();
}

// Find related skills for a given skill
export function findRelatedSkills(skillName: string): string[] {
  const normalizedName = normalizeSkillName(skillName);
  
  // Define related skills for common technologies
  const relatedSkillsMap: Record<string, string[]> = {
    'javascript': ['typescript', 'react', 'vue.js', 'angular', 'node.js'],
    'react': ['javascript', 'typescript', 'redux', 'react native'],
    'python': ['django', 'flask', 'data science', 'machine learning'],
    'ui design': ['ux design', 'figma', 'sketch', 'adobe xd'],
    'marketing': ['digital marketing', 'seo', 'content marketing', 'social media'],
    'project management': ['agile', 'scrum', 'jira', 'team management']
  };
  
  return relatedSkillsMap[normalizedName] || [];
}