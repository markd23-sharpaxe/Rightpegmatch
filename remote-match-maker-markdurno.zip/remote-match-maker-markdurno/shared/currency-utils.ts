/**
 * Utility functions for working with currencies in the application
 * These exchange rates are approximate and used for matching purposes only
 * Not intended for financial calculations requiring exact current rates
 */

// Common currency codes with their exchange rates to USD (approximate)
export const currencyExchangeRates: Record<string, number> = {
  USD: 1.0,      // US Dollar (base)
  EUR: 1.09,     // Euro
  GBP: 1.29,     // British Pound
  CAD: 0.73,     // Canadian Dollar
  AUD: 0.67,     // Australian Dollar
  JPY: 0.0066,   // Japanese Yen
  CHF: 1.13,     // Swiss Franc
  CNY: 0.14,     // Chinese Yuan
  INR: 0.012,    // Indian Rupee
  MXN: 0.059,    // Mexican Peso
  BRL: 0.18,     // Brazilian Real
  SGD: 0.75,     // Singapore Dollar
  HKD: 0.13,     // Hong Kong Dollar
  SEK: 0.095,    // Swedish Krona
  NOK: 0.093,    // Norwegian Krone
  DKK: 0.146,    // Danish Krone
  NZD: 0.61,     // New Zealand Dollar
  ZAR: 0.054,    // South African Rand
  RUB: 0.011,    // Russian Ruble
  TRY: 0.031,    // Turkish Lira
};

// Currency symbols for display
export const currencySymbols: Record<string, string> = {
  USD: '$',
  EUR: '€',
  GBP: '£',
  CAD: 'C$',
  AUD: 'A$',
  JPY: '¥',
  CHF: 'Fr',
  CNY: '¥',
  INR: '₹',
  MXN: 'Mex$',
  BRL: 'R$',
  SGD: 'S$',
  HKD: 'HK$',
  SEK: 'kr',
  NOK: 'kr',
  DKK: 'kr',
  NZD: 'NZ$',
  ZAR: 'R',
  RUB: '₽',
  TRY: '₺',
};

// List of currency options for dropdowns
export const currencies = Object.keys(currencyExchangeRates).map(code => ({
  value: code,
  label: `${code} (${currencySymbols[code] || code})`,
  name: code, // For compatibility with AutocompleteOption interface
}));

/**
 * Convert an amount from one currency to another
 * @param amount The amount to convert
 * @param fromCurrency The currency code to convert from
 * @param toCurrency The currency code to convert to
 * @returns The converted amount
 */
export function convertCurrency(
  amount: number,
  fromCurrency: string,
  toCurrency: string
): number {
  // If currencies are the same, no conversion needed
  if (fromCurrency === toCurrency) {
    return amount;
  }

  // Get exchange rates
  const fromRate = currencyExchangeRates[fromCurrency];
  const toRate = currencyExchangeRates[toCurrency];

  // Check if we have rates for both currencies
  if (!fromRate || !toRate) {
    console.warn(`Missing exchange rate for ${fromCurrency} or ${toCurrency}`);
    return amount; // Return original amount if we can't convert
  }

  // Convert to USD then to target currency
  const amountInUsd = amount * fromRate;
  const convertedAmount = amountInUsd / toRate;

  return parseFloat(convertedAmount.toFixed(2));
}

/**
 * Check if two salary amounts with different currencies are within a given percentage range
 * This helps with matching jobs across different currencies
 * @param amount1 First amount
 * @param currency1 Currency code for first amount
 * @param amount2 Second amount
 * @param currency2 Currency code for second amount
 * @param tolerance Percentage tolerance (15 = within 15%)
 * @returns true if the amounts are within the tolerance range
 */
export function areSalariesCompatible(
  amount1: number,
  currency1: string,
  amount2: number,
  currency2: string,
  tolerance = 15
): boolean {
  // Convert both to USD for comparison
  const amount1Usd = convertCurrency(amount1, currency1, 'USD');
  const amount2Usd = convertCurrency(amount2, currency2, 'USD');
  
  // Calculate percentage difference
  const maxAmount = Math.max(amount1Usd, amount2Usd);
  const minAmount = Math.min(amount1Usd, amount2Usd);
  const percentageDiff = ((maxAmount - minAmount) / maxAmount) * 100;
  
  // Return true if within tolerance
  return percentageDiff <= tolerance;
}

/**
 * Format a currency amount with its symbol
 * @param amount The amount to format
 * @param currencyCode The currency code
 * @returns Formatted currency string
 */
export function formatCurrency(amount: number, currencyCode: string): string {
  const symbol = currencySymbols[currencyCode] || currencyCode;
  return `${symbol}${amount.toFixed(2)}`;
}