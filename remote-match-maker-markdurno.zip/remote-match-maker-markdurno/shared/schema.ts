import { pgTable, text, serial, integer, boolean, timestamp, jsonb, decimal, primaryKey, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Job families enum type definition
export enum JobFamily {
  ProjectManagement = "Project Management",
  SoftwareDevelopment = "Software Development",
  Design = "Design",
  Sales = "Sales",
  Marketing = "Marketing",
  CustomerSupport = "Customer Support",
  Finance = "Finance",
  HumanResources = "Human Resources",
  Executive = "Executive",
  Operations = "Operations",
  DataAnalysis = "Data Analysis",
  Other = "Other"
}

// Job roles table - these are standardized roles users can select from
export const jobRoles = pgTable("job_roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  category: text("category"),
  jobFamily: text("job_family").default(JobFamily.Other), // Which broader job family this role belongs to
});

export const insertJobRoleSchema = createInsertSchema(jobRoles).omit({ id: true });

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  location: text("location"),
  timeZone: text("time_zone"),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  languages: text("languages"),
  linkedInProfile: text("linkedin_profile"),
  // Secret question for account recovery
  secretQuestion: text("secret_question"),
  secretAnswer: text("secret_answer"),
  // Availability preferences
  preferredHoursPerWeek: integer("preferred_hours_per_week"),
  // Salary requirements
  minSalaryRequirement: decimal("min_salary_requirement", { precision: 10, scale: 2 }),
  maxSalaryRequirement: decimal("max_salary_requirement", { precision: 10, scale: 2 }),
  salaryCurrency: text("salary_currency").default("USD"),
  preferredSalaryType: text("preferred_salary_type").default("hourly"), // hourly, monthly, annual
  // jobRoleId field is deprecated in favor of userJobRoles table for many-to-many relationship
  jobRoleId: integer("job_role_id").references(() => jobRoles.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true });

// User type with additional runtime properties
export type User = typeof users.$inferSelect & {
  matchScore?: JobMatchScore; // Add matchScore property for runtime matching
};

// Skills table
export const skills = pgTable("skills", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const insertSkillSchema = createInsertSchema(skills).omit({ id: true });

// Qualifications table
export const qualifications = pgTable("qualifications", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
});

export const insertQualificationSchema = createInsertSchema(qualifications).omit({ id: true });

// User skills join table
export const userSkills = pgTable("user_skills", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  skillId: integer("skill_id").notNull().references(() => skills.id),
});

export const insertUserSkillSchema = createInsertSchema(userSkills).omit({ id: true });

// User qualifications join table
export const userQualifications = pgTable("user_qualifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  qualificationId: integer("qualification_id").notNull().references(() => qualifications.id),
});

export const insertUserQualificationSchema = createInsertSchema(userQualifications).omit({ id: true });

// Experience level enum
export enum ExperienceLevel {
  LessThanOneYear = "Less than 1 year",
  TwoToFiveYears = "2-5 years",
  FiveToTenYears = "5-10 years",
  TenPlusYears = "10+ years"
}

// User job roles - many-to-many relationship between users and job roles
export const userJobRoles = pgTable("user_job_roles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  jobRoleId: integer("job_role_id").notNull().references(() => jobRoles.id),
  isPrimary: boolean("is_primary").default(false).notNull(), // Indicates if this is user's primary role
  experienceLevel: text("experience_level"), // New field for experience level
});

export const insertUserJobRoleSchema = createInsertSchema(userJobRoles).omit({ id: true });

// Availability slots
export const availabilitySlots = pgTable("availability_slots", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  dayOfWeek: integer("day_of_week").notNull(), // 0-6 for Sunday-Saturday
  startHour: integer("start_hour").notNull(), // 0-23
  endHour: integer("end_hour").notNull(), // 0-23
  timeZone: text("time_zone"),
});

export const insertAvailabilitySlotSchema = createInsertSchema(availabilitySlots).omit({ id: true });

// Jobs table
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  employerId: integer("employer_id").notNull().references(() => users.id),
  companyName: text("company_name").notNull(),
  jobRoleId: integer("job_role_id").references(() => jobRoles.id),
  hoursPerWeek: integer("hours_per_week"),
  hourlyRate: text("hourly_rate"), // This will always be calculated and stored for matching
  salaryAmount: text("salary_amount"), // The amount entered by the user
  salaryType: text("salary_type").default("hourly"), // hourly, weekly, monthly, yearly
  currency: text("currency").default("USD"),
  requiredLanguages: text("required_languages"),
  // Specific time requirements - days and hours when availability is required
  requiredAvailability: jsonb("required_availability").$type<{
    dayOfWeek: number;
    startHour: number;
    endHour: number;
    timeZone: string;
  }[]>().default([]),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  requiredSkills: jsonb("required_skills").$type<number[]>().default([]),
  // New fields for qualifications
  requiredQualifications: jsonb("required_qualifications").$type<number[]>().default([]),
  optionalQualifications: jsonb("optional_qualifications").$type<number[]>().default([]),
  jobFamily: text("job_family").default(JobFamily.Other), // Job family for better categorization
  
  // Job term details
  startDate: timestamp("start_date"), // When the job starts
  endDate: timestamp("end_date"), // When the job ends (if applicable)
  startDateFlexibility: text("start_date_flexibility").default("exact"), // exact, month, immediate
  isPermanent: boolean("is_permanent").default(false), // Whether the job has no end date
  
  // Salary information
  minSalary: decimal("min_salary", { precision: 10, scale: 2 }),
  maxSalary: decimal("max_salary", { precision: 10, scale: 2 }),
  
  // Legacy fields - keeping for backward compatibility
  description: text("description").default(""),
  minHoursPerWeek: integer("min_hours_per_week"),
  maxHoursPerWeek: integer("max_hours_per_week"),
  timeZoneRequirements: text("time_zone_requirements"),
  timeZoneOverlap: text("time_zone_overlap"),
  salary: text("salary"),
  jobType: text("job_type").default("full-time"),
  location: text("location").default("Remote"),
});

export const insertJobSchema = createInsertSchema(jobs).omit({ id: true, createdAt: true, status: true });

// Job applications table
export const jobApplications = pgTable("job_applications", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull().references(() => jobs.id),
  jobseekerId: integer("jobseeker_id").notNull().references(() => users.id),
  status: text("status").notNull().default("pending"), // pending, accepted, rejected
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertJobApplicationSchema = createInsertSchema(jobApplications).omit({ id: true, createdAt: true, status: true });

// Subscription plans table
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // We'll use name to identify subscription types - "Single Job", "All Jobs", "Premium"
  description: text("description").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  maxSearches: integer("max_searches").notNull(),
  maxApplicantViews: integer("max_applicant_views").notNull(),
  isUnlimited: boolean("is_unlimited").default(false).notNull(),
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({ id: true });

// User subscriptions table
export const userSubscriptions = pgTable("user_subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  planId: integer("plan_id").notNull().references(() => subscriptionPlans.id),
  startDate: timestamp("start_date").defaultNow().notNull(),
  endDate: timestamp("end_date").notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  searchesUsed: integer("searches_used").default(0).notNull(),
  applicantViewsUsed: integer("applicant_views_used").default(0).notNull(),
  // Added field to track which job a single-job subscription applies to
  jobId: integer("job_id").references(() => jobs.id),
  // Stripe subscription ID for recurring subscriptions
  stripeSubscriptionId: text("stripe_subscription_id"),
  // Stripe customer ID for the subscriber
  stripeCustomerId: text("stripe_customer_id"),
});

export const insertUserSubscriptionSchema = createInsertSchema(userSubscriptions).omit({ id: true });

// Export types
export type JobRole = typeof jobRoles.$inferSelect;
export type InsertJobRole = z.infer<typeof insertJobRoleSchema>;

export type InsertUser = z.infer<typeof insertUserSchema>;

export type Skill = typeof skills.$inferSelect;
export type InsertSkill = z.infer<typeof insertSkillSchema>;

export type UserSkill = typeof userSkills.$inferSelect;
export type InsertUserSkill = z.infer<typeof insertUserSkillSchema>;

export type Qualification = typeof qualifications.$inferSelect;
export type InsertQualification = z.infer<typeof insertQualificationSchema>;

export type UserQualification = typeof userQualifications.$inferSelect;
export type InsertUserQualification = z.infer<typeof insertUserQualificationSchema>;

export type UserJobRole = typeof userJobRoles.$inferSelect;
export type InsertUserJobRole = z.infer<typeof insertUserJobRoleSchema>;

export type AvailabilitySlot = typeof availabilitySlots.$inferSelect;
export type InsertAvailabilitySlot = z.infer<typeof insertAvailabilitySlotSchema>;

export type Job = typeof jobs.$inferSelect & {
  matchScore?: JobMatchScore; // Add a property to store match information
};
export type InsertJob = z.infer<typeof insertJobSchema>;

// Type for the requiredAvailability field in the jobs table
export type JobAvailabilityRequirement = {
  dayOfWeek: number;
  startHour: number;
  endHour: number;
  timeZone: string;
};

export type JobApplication = typeof jobApplications.$inferSelect;
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;

export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;

export type UserSubscription = typeof userSubscriptions.$inferSelect;
export type InsertUserSubscription = z.infer<typeof insertUserSubscriptionSchema>;

// Job matching - score model for detailed match information
export interface MatchDetails {
  // Additional detailed matching information
  matchedRoleId?: number;
  matchedSkillIds?: number[];
  requiredSkillsCount?: number;
  matchedSkillsCount?: number;
  
  // Qualification matching details
  matchedRequiredQualificationIds?: number[];
  requiredQualificationsCount?: number;
  matchedRequiredQualificationsCount?: number;
  missingRequiredQualifications?: Qualification[];
  
  matchedOptionalQualificationIds?: number[];
  optionalQualificationsCount?: number;
  matchedOptionalQualificationsCount?: number;
  
  availabilityMatchPercentage?: number;
  matchedSlots?: number;
  totalSlots?: number;
  
  // Job family matching
  userJobFamily?: string;
  jobJobFamily?: string;
  jobFamilyMatch?: boolean;
  
  // AI-specific match details
  aiMatchExplanation?: string;
  aiStrengths?: string[];
  aiGaps?: string[];
  aiLanguageMatch?: number;
  aiCompensationMatch?: number;
  
  [key: string]: any; // Allow for additional match details
}

export interface JobMatchScore {
  overallScore: number;  // 0-100
  roleScore: number;     // Previously 0-50, now 0-100 for AI scoring
  availabilityScore: number; // Previously 0-30, now 0-100 for AI scoring
  skillsScore: number;   // Previously 0-20, now 0-100 for AI scoring
  skillsMatchPercentage: number; // 0-100 (percentage of matching skills)
  
  // New qualification scores
  qualificationsScore: number; // 0-100 for qualification scoring
  requiredQualificationsMatchPercentage: number; // 0-100 (percentage of matching required qualifications)
  optionalQualificationsMatchPercentage: number; // 0-100 (percentage of matching optional qualifications)
  matchDetails?: MatchDetails;
  lastUpdated?: Date;    // When the match was last calculated
}

// Job role similarity data structure
export interface RelatedJobRole {
  roleId: number;
  similarRoleIds: number[];
}

// Messages table for communication between job posters and applicants
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  applicationId: integer("application_id").notNull().references(() => jobApplications.id),
  senderId: integer("sender_id").notNull().references(() => users.id),
  recipientId: integer("recipient_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Job required skills - many-to-many relationship between jobs and skills
export const jobRequiredSkills = pgTable("job_required_skills", {
  jobId: integer("job_id").notNull().references(() => jobs.id),
  skillId: integer("skill_id").notNull().references(() => skills.id)
}, (table) => {
  return {
    pk: primaryKey({ columns: [table.jobId, table.skillId] }) // Composite primary key
  };
});

export const insertMessageSchema = createInsertSchema(messages).omit({ id: true, createdAt: true, isRead: true });

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;

// Job matches cache table for storing AI match results
export const jobMatchesCache = pgTable("job_matches_cache", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  jobId: integer("job_id").notNull().references(() => jobs.id),
  matchScore: integer("match_score").notNull(), // Overall match score 0-100
  roleScore: integer("role_score").notNull(),   // Role match score 0-100
  skillsScore: integer("skills_score").notNull(), // Skills match score 0-100
  availabilityScore: integer("availability_score").notNull(), // Availability match score 0-100
  languageMatch: integer("language_match").notNull(), // Language match score 0-100
  compensationMatch: integer("compensation_match").notNull(), // Compensation match score 0-100
  
  // Qualification match scores
  qualificationsScore: integer("qualifications_score").default(0), // Qualifications match score 0-100
  requiredQualificationsMatchPercentage: integer("required_qualifications_match_percentage").default(0), // Required qualifications match 0-100%
  optionalQualificationsMatchPercentage: integer("optional_qualifications_match_percentage").default(0), // Optional qualifications match 0-100%
  
  userJobFamily: text("user_job_family").default(JobFamily.Other), // User's job family
  jobJobFamily: text("job_job_family").default(JobFamily.Other), // Job's job family
  jobFamilyMatch: boolean("job_family_match").default(false), // Whether job families match
  matchExplanation: text("match_explanation").notNull(), // AI explanation of the match
  strengths: text("strengths").notNull(), // Serialized array of match strengths
  gaps: text("gaps").notNull(), // Serialized array of match gaps
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertJobMatchCacheSchema = createInsertSchema(jobMatchesCache).omit({ id: true });

export type JobMatchCache = typeof jobMatchesCache.$inferSelect;
export type InsertJobMatchCache = z.infer<typeof insertJobMatchCacheSchema>;

// Direct messages table for communication not tied to job applications
export const directMessages = pgTable("direct_messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").notNull().references(() => users.id),
  recipientId: integer("recipient_id").notNull().references(() => users.id),
  content: text("content").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertDirectMessageSchema = createInsertSchema(directMessages).omit({ id: true, createdAt: true, isRead: true });

export type DirectMessage = typeof directMessages.$inferSelect;
export type InsertDirectMessage = z.infer<typeof insertDirectMessageSchema>;

// Job language index table for faster matching on language requirements
export const jobLanguageIndex = pgTable("job_language_index", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id")
    .notNull()
    .references(() => jobs.id, { onDelete: "cascade" }),
  language: text("language").notNull(),
});

export const insertJobLanguageIndexSchema = createInsertSchema(jobLanguageIndex).omit({ id: true });
export type JobLanguageIndex = typeof jobLanguageIndex.$inferSelect;
export type InsertJobLanguageIndex = z.infer<typeof insertJobLanguageIndexSchema>;

// Job family index table for faster matching on job family
export const jobFamilyIndex = pgTable("job_family_index", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id")
    .notNull()
    .references(() => jobs.id, { onDelete: "cascade" }),
  jobFamily: text("job_family").notNull(),
});

export const insertJobFamilyIndexSchema = createInsertSchema(jobFamilyIndex).omit({ id: true });
export type JobFamilyIndex = typeof jobFamilyIndex.$inferSelect;
export type InsertJobFamilyIndex = z.infer<typeof insertJobFamilyIndexSchema>;

// Password reset tokens table
export const passwordResetTokens = pgTable("password_reset_tokens", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  token: text("token").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  used: boolean("used").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPasswordResetTokenSchema = createInsertSchema(passwordResetTokens).omit({ id: true, createdAt: true });
export type PasswordResetToken = typeof passwordResetTokens.$inferSelect;
export type InsertPasswordResetToken = z.infer<typeof insertPasswordResetTokenSchema>;

// User language index table for faster matching
export const userLanguageIndex = pgTable("user_language_index", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  language: text("language").notNull(),
});

export const insertUserLanguageIndexSchema = createInsertSchema(userLanguageIndex).omit({ id: true });
export type UserLanguageIndex = typeof userLanguageIndex.$inferSelect;
export type InsertUserLanguageIndex = z.infer<typeof insertUserLanguageIndexSchema>;

// User job family index table for faster matching
export const userJobFamilyIndex = pgTable("user_job_family_index", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  jobFamily: text("job_family").notNull(),
});

export const insertUserJobFamilyIndexSchema = createInsertSchema(userJobFamilyIndex).omit({ id: true });
export type UserJobFamilyIndex = typeof userJobFamilyIndex.$inferSelect;
export type InsertUserJobFamilyIndex = z.infer<typeof insertUserJobFamilyIndexSchema>;

// Salary types for use with the SalaryInput component
export type SalaryType = 'hourly' | 'weekly' | 'monthly' | 'yearly';

// Start date flexibility options for job terms
export type StartDateFlexibilityType = 'exact' | 'month' | 'immediate';
