import { RelatedJobRole, JobRole } from "./schema";

/**
 * Job role similarity utility
 * 
 * This file contains functions for determining similarity between job roles
 * to facilitate more accurate matching between jobs and candidates.
 */

// Job role similarity data - maps roles to similar/related roles
export const relatedJobRoles: RelatedJobRole[] = [
  // Management roles
  {
    roleId: 1, // Project Manager
    similarRoleIds: [2, 3, 4] // Product Manager, Program Manager, Project Management Office
  },
  {
    roleId: 2, // Product Manager
    similarRoleIds: [1, 3] // Project Manager, Program Manager
  },
  {
    roleId: 3, // Program Manager
    similarRoleIds: [1, 2, 4] // Project Manager, Product Manager, Project Management Office
  },
  {
    roleId: 4, // Project Management Office
    similarRoleIds: [1, 3] // Project Manager, Program Manager
  },
  
  // Development roles
  {
    roleId: 5, // Frontend Developer
    similarRoleIds: [6, 9] // Backend Developer, Full Stack Developer
  },
  {
    roleId: 6, // Backend Developer
    similarRoleIds: [5, 9] // Frontend Developer, Full Stack Developer
  },
  {
    roleId: 7, // Mobile Developer
    similarRoleIds: [9] // Full Stack Developer
  },
  {
    roleId: 8, // DevOps Engineer
    similarRoleIds: [10, 14] // System Administrator, Site Reliability Engineer
  },
  {
    roleId: 9, // Full Stack Developer
    similarRoleIds: [5, 6, 7] // Frontend Developer, Backend Developer, Mobile Developer
  },
  
  // IT Operations
  {
    roleId: 10, // System Administrator
    similarRoleIds: [8, 14] // DevOps Engineer, Site Reliability Engineer
  },
  
  // Design roles
  {
    roleId: 11, // UX Designer
    similarRoleIds: [12, 13] // UI Designer, Product Designer
  },
  {
    roleId: 12, // UI Designer
    similarRoleIds: [11, 13] // UX Designer, Product Designer
  },
  {
    roleId: 13, // Product Designer
    similarRoleIds: [11, 12] // UX Designer, UI Designer
  },
  
  // Engineering roles
  {
    roleId: 14, // Site Reliability Engineer
    similarRoleIds: [8, 10] // DevOps Engineer, System Administrator
  },
];

/**
 * Checks if two job roles are similar based on the similarity mapping
 * @param roleId1 First job role ID
 * @param roleId2 Second job role ID
 * @returns Boolean indicating if roles are similar
 */
export function areJobRolesSimilar(roleId1: number, roleId2: number): boolean {
  if (roleId1 === roleId2) return true;
  
  const role1 = relatedJobRoles.find(r => r.roleId === roleId1);
  if (!role1) return false;
  
  return role1.similarRoleIds.includes(roleId2);
}

/**
 * Calculate role match score (0-50) based on exact or similar role match
 * @param userRoleId User's job role ID
 * @param jobRoleId Job's required role ID
 * @returns Score from 0-50 (50 for exact match, 40 for similar match, 0 for no match)
 */
export function calculateRoleMatchScore(userRoleId: number | null | undefined, jobRoleId: number | null | undefined): number {
  if (!userRoleId || !jobRoleId) return 0;
  
  if (userRoleId === jobRoleId) {
    return 50; // Exact match gets full points
  }
  
  if (areJobRolesSimilar(userRoleId, jobRoleId)) {
    return 40; // Similar roles get 80% of points
  }
  
  return 0; // No match
}

/**
 * Gets similar job roles for a given role ID
 * @param roleId Job role ID
 * @returns Array of similar job role IDs including the input role ID
 */
export function getSimilarJobRoles(roleId: number): number[] {
  const role = relatedJobRoles.find(r => r.roleId === roleId);
  if (!role) return [roleId];
  
  return [roleId, ...role.similarRoleIds];
}