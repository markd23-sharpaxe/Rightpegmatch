// Import schema and types
import { 
  users, skills, userSkills, availabilitySlots, jobs, jobApplications,
  subscriptionPlans, userSubscriptions, jobRoles, messages, userJobRoles,
  jobMatchesCache, directMessages, qualifications, userQualifications,
  passwordResetTokens
} from "@shared/schema";
import type { 
  User, InsertUser, 
  Skill, InsertSkill, 
  UserSkill, InsertUserSkill, 
  AvailabilitySlot, InsertAvailabilitySlot,
  Job, InsertJob, JobAvailabilityRequirement,
  JobApplication, InsertJobApplication,
  SubscriptionPlan, InsertSubscriptionPlan,
  UserSubscription, InsertUserSubscription,
  JobRole, InsertJobRole,
  UserJobRole, InsertUserJobRole,
  JobMatchScore,
  Message, InsertMessage,
  DirectMessage, InsertDirectMessage,
  JobMatchCache, InsertJobMatchCache,
  Qualification, InsertQualification,
  UserQualification, InsertUserQualification,
  PasswordResetToken, InsertPasswordResetToken
} from "@shared/schema";

// Import anthropic service types
import type { AIJobMatchResult } from "./services/anthropic";

// Import PostgreSQL-related modules 
import pg from "pg";
import pgConnect from "connect-pg-simple";
import session from "express-session";

// Import Drizzle ORM
import { drizzle } from "drizzle-orm/node-postgres";
import { eq, and, ilike, or, desc, asc, sql, SQL, gt } from "drizzle-orm";
import { IStorage } from "./storage";

// Setup DB connection
const { Pool } = pg;
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

// Initialize Drizzle with the PostgreSQL pool
export const db = drizzle(pool);

// Setup session store
const PostgresSessionStore = pgConnect(session);

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    console.log("Using PostgreSQL for session storage");
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // Job Role management
  async getJobRole(id: number): Promise<JobRole | undefined> {
    const [role] = await db.select().from(jobRoles).where(eq(jobRoles.id, id));
    return role;
  }

  async getJobRoleByName(name: string): Promise<JobRole | undefined> {
    console.log(`Searching for job role with name: "${name}"`);
    
    // First try with exact match (case-sensitive)
    const [exactMatch] = await db.select().from(jobRoles).where(eq(jobRoles.name, name));
    if (exactMatch) {
      console.log(`Found exact match for job role: ${JSON.stringify(exactMatch)}`);
      return exactMatch;
    }
    
    // If no exact match, try with case-insensitive comparison
    const [caseInsensitiveMatch] = await db
      .select()
      .from(jobRoles)
      .where(sql`LOWER(${jobRoles.name}) = LOWER(${name})`);
    
    console.log(`Case-insensitive match result: ${JSON.stringify(caseInsensitiveMatch || 'No match found')}`);
    return caseInsensitiveMatch;
  }

  async getAllJobRoles(): Promise<JobRole[]> {
    return db.select().from(jobRoles);
  }

  async createJobRole(role: InsertJobRole): Promise<JobRole> {
    const [newRole] = await db.insert(jobRoles).values(role).returning();
    return newRole;
  }

  async getUsersByJobRole(jobRoleId: number): Promise<User[]> {
    const usersList = await db.select()
      .from(users)
      .where(eq(users.jobRoleId, jobRoleId));
    
    const userRoles = await db.select()
      .from(userJobRoles)
      .where(eq(userJobRoles.jobRoleId, jobRoleId));
    
    // Get users with this role in userJobRoles
    const additionalUsers = [];
    for (const userRole of userRoles) {
      const [user] = await db.select()
        .from(users)
        .where(eq(users.id, userRole.userId));
      if (user) {
        additionalUsers.push(user);
      }
    }
    
    // Combine and deduplicate users
    const allUsers = [...usersList, ...additionalUsers];
    return [...new Map(allUsers.map(user => [user.id, user])).values()];
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async updateUserPassword(userId: number, hashedPassword: string): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set({ password: hashedPassword })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }

  async getAllUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async createUser(userData: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Skills management
  async getSkill(id: number): Promise<Skill | undefined> {
    const [skill] = await db.select().from(skills).where(eq(skills.id, id));
    return skill;
  }

  async getSkillByName(name: string): Promise<Skill | undefined> {
    const [skill] = await db.select().from(skills).where(eq(skills.name, name));
    return skill;
  }

  async getAllSkills(): Promise<Skill[]> {
    return db.select().from(skills);
  }

  async createSkill(skillData: InsertSkill): Promise<Skill> {
    const [skill] = await db.insert(skills).values(skillData).returning();
    return skill;
  }

  // Qualifications management
  async getQualification(id: number): Promise<Qualification | undefined> {
    const [qualification] = await db.select().from(qualifications).where(eq(qualifications.id, id));
    return qualification;
  }

  async getQualificationByName(name: string): Promise<Qualification | undefined> {
    const [qualification] = await db.select().from(qualifications).where(eq(qualifications.name, name));
    return qualification;
  }

  async getAllQualifications(): Promise<Qualification[]> {
    return db.select().from(qualifications);
  }

  async createQualification(qualificationData: InsertQualification): Promise<Qualification> {
    const [qualification] = await db.insert(qualifications).values(qualificationData).returning();
    return qualification;
  }

  // User qualifications
  async getUserQualifications(userId: number): Promise<Qualification[]> {
    console.log("[DEBUG] DB: Getting qualifications for user:", userId);
    const userQualsList = await db
      .select()
      .from(userQualifications)
      .where(eq(userQualifications.userId, userId));
    
    console.log("[DEBUG] DB: User qualification links:", userQualsList);

    const userQualsWithDetails: Qualification[] = [];
    for (const userQual of userQualsList) {
      console.log("[DEBUG] DB: Looking up qualification ID:", userQual.qualificationId);
      const [qual] = await db
        .select()
        .from(qualifications)
        .where(eq(qualifications.id, userQual.qualificationId));
      
      console.log("[DEBUG] DB: Found qualification details:", qual);
      if (qual) {
        userQualsWithDetails.push(qual);
      }
    }
    
    console.log("[DEBUG] DB: Final qualifications with details:", userQualsWithDetails);
    return userQualsWithDetails;
  }

  async addUserQualification(userQualificationData: InsertUserQualification): Promise<UserQualification> {
    const [userQualification] = await db
      .insert(userQualifications)
      .values(userQualificationData)
      .returning();
    return userQualification;
  }

  async removeUserQualification(userId: number, qualificationId: number): Promise<void> {
    await db
      .delete(userQualifications)
      .where(and(
        eq(userQualifications.userId, userId),
        eq(userQualifications.qualificationId, qualificationId)
      ));
  }

  // User skills
  async getUserSkills(userId: number): Promise<Skill[]> {
    const userSkillList = await db
      .select()
      .from(userSkills)
      .where(eq(userSkills.userId, userId));

    const userSkillsWithDetails: Skill[] = [];
    for (const userSkill of userSkillList) {
      const [skill] = await db
        .select()
        .from(skills)
        .where(eq(skills.id, userSkill.skillId));
      if (skill) {
        userSkillsWithDetails.push(skill);
      }
    }

    return userSkillsWithDetails;
  }

  async addUserSkill(userSkillData: InsertUserSkill): Promise<UserSkill> {
    const [userSkill] = await db
      .insert(userSkills)
      .values(userSkillData)
      .returning();
    return userSkill;
  }

  async removeUserSkill(userId: number, skillId: number): Promise<void> {
    await db
      .delete(userSkills)
      .where(and(
        eq(userSkills.userId, userId),
        eq(userSkills.skillId, skillId)
      ));
  }

  // User job roles
  async getUserJobRoles(userId: number): Promise<(UserJobRole & { role: JobRole })[]> {
    const userRolesList = await db
      .select()
      .from(userJobRoles)
      .where(eq(userJobRoles.userId, userId));

    const result: (UserJobRole & { role: JobRole })[] = [];
    for (const userRole of userRolesList) {
      const [role] = await db
        .select()
        .from(jobRoles)
        .where(eq(jobRoles.id, userRole.jobRoleId));
      
      if (role) {
        result.push({ ...userRole, role });
      }
    }

    return result;
  }

  async addUserJobRole(userJobRoleData: InsertUserJobRole): Promise<UserJobRole> {
    // If setting this as primary, first set all existing roles to non-primary
    if (userJobRoleData.isPrimary) {
      await db
        .update(userJobRoles)
        .set({ isPrimary: false })
        .where(and(
          eq(userJobRoles.userId, userJobRoleData.userId),
          eq(userJobRoles.isPrimary, true)
        ));
    }
    
    const [userJobRole] = await db
      .insert(userJobRoles)
      .values(userJobRoleData)
      .returning();
    
    return userJobRole;
  }

  async removeUserJobRole(userId: number, jobRoleId: number): Promise<void> {
    // First check if the role being removed is primary
    const [roleToRemove] = await db
      .select()
      .from(userJobRoles)
      .where(and(
        eq(userJobRoles.userId, userId),
        eq(userJobRoles.jobRoleId, jobRoleId)
      ));
    
    // Delete the role
    await db
      .delete(userJobRoles)
      .where(and(
        eq(userJobRoles.userId, userId),
        eq(userJobRoles.jobRoleId, jobRoleId)
      ));
    
    // If removed role was primary, set another role as primary if available
    if (roleToRemove?.isPrimary) {
      const [anotherRole] = await db
        .select()
        .from(userJobRoles)
        .where(eq(userJobRoles.userId, userId));
      
      if (anotherRole) {
        await db
          .update(userJobRoles)
          .set({ isPrimary: true })
          .where(eq(userJobRoles.id, anotherRole.id));
      }
    }
  }

  async setPrimaryUserJobRole(userId: number, jobRoleId: number, experienceLevel?: string | null): Promise<UserJobRole | undefined> {
    // First check if the role exists
    const [roleToMakePrimary] = await db
      .select()
      .from(userJobRoles)
      .where(and(
        eq(userJobRoles.userId, userId),
        eq(userJobRoles.jobRoleId, jobRoleId)
      ));
    
    if (!roleToMakePrimary) return undefined;
    
    // Set all roles for this user to non-primary
    await db
      .update(userJobRoles)
      .set({ isPrimary: false })
      .where(and(
        eq(userJobRoles.userId, userId),
        eq(userJobRoles.isPrimary, true)
      ));
    
    // Prepare update data
    const updateData: { isPrimary: boolean; experienceLevel?: string | null } = { 
      isPrimary: true 
    };
    
    // Only include experienceLevel if provided
    if (experienceLevel !== undefined) {
      updateData.experienceLevel = experienceLevel;
    }
    
    // Set the target role as primary and update experience level if provided
    const [updatedRole] = await db
      .update(userJobRoles)
      .set(updateData)
      .where(eq(userJobRoles.id, roleToMakePrimary.id))
      .returning();
    
    return updatedRole;
  }
  
  async updateUserJobRoleExperience(userId: number, jobRoleId: number, experienceLevel: string | null): Promise<UserJobRole | undefined> {
    // First check if the role exists
    const [userJobRole] = await db
      .select()
      .from(userJobRoles)
      .where(and(
        eq(userJobRoles.userId, userId),
        eq(userJobRoles.jobRoleId, jobRoleId)
      ));
    
    if (!userJobRole) return undefined;
    
    // Update the experience level
    const [updatedRole] = await db
      .update(userJobRoles)
      .set({ experienceLevel })
      .where(eq(userJobRoles.id, userJobRole.id))
      .returning();
    
    return updatedRole;
  }

  // Availability management
  async getUserAvailability(userId: number): Promise<AvailabilitySlot[]> {
    return db
      .select()
      .from(availabilitySlots)
      .where(eq(availabilitySlots.userId, userId));
  }

  async addAvailabilitySlot(slotData: InsertAvailabilitySlot): Promise<AvailabilitySlot> {
    const [slot] = await db
      .insert(availabilitySlots)
      .values(slotData)
      .returning();
    return slot;
  }

  async removeAvailabilitySlot(id: number): Promise<void> {
    await db
      .delete(availabilitySlots)
      .where(eq(availabilitySlots.id, id));
  }

  // Job management
  async getJob(id: number): Promise<Job | undefined> {
    const [job] = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, id));
    return job;
  }

  async getAllJobs(): Promise<Job[]> {
    return db
      .select()
      .from(jobs)
      .where(eq(jobs.status, 'active'));
  }

  async getJobsByEmployer(employerId: number): Promise<Job[]> {
    return db
      .select()
      .from(jobs)
      .where(eq(jobs.employerId, employerId));
  }

  async searchJobs(query: string, filters: any = {}): Promise<Job[]> {
    let jobQuery = db
      .select()
      .from(jobs)
      .where(eq(jobs.status, 'active'));
    
    if (query) {
      const pattern = `%${query}%`;
      jobQuery = db
        .select()
        .from(jobs)
        .where(and(
          eq(jobs.status, 'active'),
          or(
            ilike(jobs.title, pattern),
            ilike(jobs.description || '', pattern)
          )
        ));
    }

    const allJobs = await jobQuery;
    
    // Apply filters in JS since some fields are JSON
    let filteredJobs = allJobs;
    
    if (filters.jobType) {
      filteredJobs = filteredJobs.filter(job => job.jobType === filters.jobType);
    }
    
    if (filters.minHours) {
      filteredJobs = filteredJobs.filter(job => 
        (job.minHoursPerWeek && job.minHoursPerWeek >= filters.minHours) ||
        (job.hoursPerWeek && job.hoursPerWeek >= filters.minHours)
      );
    }
    
    if (filters.maxHours) {
      filteredJobs = filteredJobs.filter(job => 
        (job.maxHoursPerWeek && job.maxHoursPerWeek <= filters.maxHours) ||
        (job.hoursPerWeek && job.hoursPerWeek <= filters.maxHours)
      );
    }
    
    if (filters.timeZoneOverlap) {
      filteredJobs = filteredJobs.filter(job => 
        job.timeZoneOverlap && job.timeZoneOverlap.includes(filters.timeZoneOverlap)
      );
    }
    
    return filteredJobs;
  }

  async createJob(jobData: InsertJob): Promise<Job> {
    // The status field is not part of InsertJob, add it separately
    const dataToInsert = {
      ...jobData,
      status: 'active' // Set default status
    };
    
    // Ensure availabilitySlots is properly formatted if provided
    if (dataToInsert.availabilitySlots && !Array.isArray(dataToInsert.availabilitySlots)) {
      dataToInsert.availabilitySlots = JSON.parse(JSON.stringify(dataToInsert.availabilitySlots));
    }
    
    const [job] = await db
      .insert(jobs)
      .values([dataToInsert])
      .returning();
    
    return job;
  }

  async updateJob(id: number, jobData: Partial<Job>): Promise<Job | undefined> {
    const [updatedJob] = await db
      .update(jobs)
      .set(jobData)
      .where(eq(jobs.id, id))
      .returning();
    return updatedJob;
  }

  // Job applications
  async getJobApplication(id: number): Promise<JobApplication | undefined> {
    const [application] = await db
      .select()
      .from(jobApplications)
      .where(eq(jobApplications.id, id));
    return application;
  }

  async getJobApplicationsForJob(jobId: number): Promise<JobApplication[]> {
    return db
      .select()
      .from(jobApplications)
      .where(eq(jobApplications.jobId, jobId));
  }

  async getUserJobApplications(userId: number): Promise<JobApplication[]> {
    return db
      .select()
      .from(jobApplications)
      .where(eq(jobApplications.jobseekerId, userId));
  }

  async createJobApplication(applicationData: InsertJobApplication): Promise<JobApplication> {
    const [application] = await db
      .insert(jobApplications)
      .values([{
        ...applicationData,
        status: 'pending' // Set default status for job application
      }])
      .returning();
    return application;
  }

  async updateJobApplicationStatus(id: number, status: string): Promise<JobApplication | undefined> {
    const [updatedApplication] = await db
      .update(jobApplications)
      .set({ status })
      .where(eq(jobApplications.id, id))
      .returning();
    return updatedApplication;
  }

  async getJobApplicationWithDetails(id: number): Promise<(JobApplication & { job: Job; jobseeker: User }) | undefined> {
    const [application] = await db
      .select()
      .from(jobApplications)
      .where(eq(jobApplications.id, id));
    
    if (!application) return undefined;
    
    const [job] = await db
      .select()
      .from(jobs)
      .where(eq(jobs.id, application.jobId));
    
    const [jobseeker] = await db
      .select()
      .from(users)
      .where(eq(users.id, application.jobseekerId));
    
    if (!job || !jobseeker) return undefined;
    
    return {
      ...application,
      job,
      jobseeker
    };
  }

  // Messages
  async getMessages(applicationId: number): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(eq(messages.applicationId, applicationId))
      .orderBy(asc(messages.createdAt));
  }

  async getMessagesByUser(userId: number): Promise<Message[]> {
    return db
      .select()
      .from(messages)
      .where(or(
        eq(messages.senderId, userId),
        eq(messages.recipientId, userId)
      ))
      .orderBy(desc(messages.createdAt));
  }

  async getUnreadMessageCount(userId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(messages)
      .where(and(
        eq(messages.recipientId, userId),
        eq(messages.isRead, false)
      ));
    
    return result[0]?.count || 0;
  }

  async sendMessage(messageData: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values([{
        ...messageData,
        isRead: false
      }])
      .returning();
    
    return message;
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const [updatedMessage] = await db
      .update(messages)
      .set({ isRead: true })
      .where(eq(messages.id, id))
      .returning();
    
    return updatedMessage;
  }
  
  // Direct Messages (not tied to job applications)
  async getDirectMessages(userId1: number, userId2: number): Promise<DirectMessage[]> {
    return db
      .select()
      .from(directMessages)
      .where(
        or(
          and(
            eq(directMessages.senderId, userId1),
            eq(directMessages.recipientId, userId2)
          ),
          and(
            eq(directMessages.senderId, userId2),
            eq(directMessages.recipientId, userId1)
          )
        )
      )
      .orderBy(asc(directMessages.createdAt));
  }
  
  async getDirectMessagesByUser(userId: number): Promise<DirectMessage[]> {
    return db
      .select()
      .from(directMessages)
      .where(
        or(
          eq(directMessages.senderId, userId),
          eq(directMessages.recipientId, userId)
        )
      )
      .orderBy(desc(directMessages.createdAt));
  }
  
  async getUnreadDirectMessageCount(userId: number): Promise<number> {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(directMessages)
      .where(
        and(
          eq(directMessages.recipientId, userId),
          eq(directMessages.isRead, false)
        )
      );
    
    return result[0]?.count || 0;
  }
  
  async sendDirectMessage(messageData: InsertDirectMessage): Promise<DirectMessage> {
    const [message] = await db
      .insert(directMessages)
      .values({
        ...messageData,
        isRead: false
      })
      .returning();
    
    return message;
  }
  
  async markDirectMessageAsRead(id: number): Promise<DirectMessage | undefined> {
    const [updatedMessage] = await db
      .update(directMessages)
      .set({ isRead: true })
      .where(eq(directMessages.id, id))
      .returning();
    
    return updatedMessage;
  }

  // Search and matching
  async findMatchingJobsForUser(userId: number, forceRefresh = false): Promise<Job[]> {
    console.time('findMatchingJobsForUser');
    
    // If forceRefresh is false, try to get cached matches first
    if (!forceRefresh) {
      try {
        const cachedMatches = await this.getAllCachedMatchesForUser(userId);
        if (cachedMatches.length > 0) {
          console.log(`Using ${cachedMatches.length} cached job matches for user ${userId}`);
          
          // Get the actual jobs from the database
          const jobs: Job[] = [];
          for (const cachedMatch of cachedMatches) {
            const job = await this.getJob(cachedMatch.jobId);
            if (job) {
              // Reconstruct match score from cache
              const matchScore: JobMatchScore = {
                overallScore: cachedMatch.matchScore,
                roleScore: cachedMatch.roleScore, 
                availabilityScore: cachedMatch.availabilityScore,
                skillsScore: cachedMatch.skillsScore,
                skillsMatchPercentage: cachedMatch.skillsScore,
                matchDetails: {
                  aiMatchExplanation: cachedMatch.matchExplanation,
                  aiStrengths: JSON.parse(cachedMatch.strengths),
                  aiGaps: JSON.parse(cachedMatch.gaps),
                  aiLanguageMatch: cachedMatch.languageMatch,
                  aiCompensationMatch: cachedMatch.compensationMatch,
                  lastUpdated: cachedMatch.lastUpdated
                }
              };
              
              // Add match score to job
              job.matchScore = matchScore;
              jobs.push(job);
            }
          }
          
          // Sort by score and return
          console.timeEnd('findMatchingJobsForUser');
          return jobs.sort((a, b) => 
            (b.matchScore?.overallScore || 0) - (a.matchScore?.overallScore || 0)
          );
        }
      } catch (error) {
        console.error('Error fetching cached matches:', error);
        // Continue with regular matching if cache fails
      }
    } else {
      // If forcing refresh, clear existing cache first
      await this.clearMatchCache(userId);
    }
    const user = await this.getUser(userId);
    if (!user) return [];
    
    // Get user skills, availability, and job roles
    const userSkills = await this.getUserSkills(userId);
    const userAvailability = await this.getUserAvailability(userId);
    const userJobRoles = await this.getUserJobRoles(userId);
    
    // Get the actual job role names for better AI matching
    const userJobRoleNames: string[] = [];
    for (const userRole of userJobRoles) {
      const roleName = userRole.role?.name;
      if (roleName) {
        userJobRoleNames.push(roleName);
      }
    }
    
    // For backward compatibility, still check the legacy single job role field
    const legacyUserJobRoleId = user.jobRoleId;
    
    // Extract job role IDs and identify primary role
    const userJobRoleIds = userJobRoles.map(userRole => userRole.jobRoleId);
    const primaryRole = userJobRoles.find(role => role.isPrimary);
    
    // Primary role has priority. If no roles are marked as primary, use legacy or first role
    let primaryRoleId: number | null = null;
    let userPrimaryJobRole: JobRole | undefined = undefined;
    
    if (primaryRole) {
      primaryRoleId = primaryRole.jobRoleId;
      userPrimaryJobRole = primaryRole.role;
    } else if (legacyUserJobRoleId) {
      primaryRoleId = legacyUserJobRoleId;
      userPrimaryJobRole = await this.getJobRole(legacyUserJobRoleId);
    } else if (userJobRoleIds.length > 0) {
      primaryRoleId = userJobRoleIds[0];
      userPrimaryJobRole = userJobRoles[0].role;
    }
    
    // If legacy job role exists and isn't in the new system, add it too
    if (legacyUserJobRoleId && !userJobRoleIds.includes(legacyUserJobRoleId)) {
      userJobRoleIds.push(legacyUserJobRoleId);
    }
    
    const userSkillIds = userSkills.map(skill => skill.id);
    const jobs = await this.getAllJobs();
    
    // Import the Anthropic service for AI-powered matching
    const { calculateAIJobMatchScore } = await import('./services/anthropic');
    
    // Array to hold job matches with their match scores
    const jobMatches: { job: Job; score: number }[] = [];
    
    // Get user skills as string array for AI matching
    const userSkillNames = userSkills.map(skill => skill.name);
    
    // Extract user languages (assume stored in a field like preferredLanguages or in profile)
    const userLanguages = user.languages ? user.languages.split(',').map(lang => lang.trim()) : [];
    
    // Process each job for matching using AI
    for (const job of jobs) {
      try {
        // Get additional job details for AI matching
        let jobRoleName = '';
        if (job.jobRoleId) {
          const jobRole = await this.getJobRole(job.jobRoleId);
          if (jobRole) {
            jobRoleName = jobRole.name;
          }
        }
        
        // Get job skills as string array for AI matching
        const jobSkillIds = job.requiredSkills || [];
        const jobSkills: string[] = [];
        
        if (jobSkillIds.length > 0) {
          for (const skillId of jobSkillIds) {
            const skill = await this.getSkill(skillId);
            if (skill) {
              jobSkills.push(skill.name);
            }
          }
        }
        
        // Parse required languages into array
        const jobLanguages = job.requiredLanguages ? job.requiredLanguages.split(',').map(lang => lang.trim()) : [];
        
        // Prepare availability data
        const jobAvailability = job.requiredAvailability || [];
        
        // Convert to user-friendly format that Claude can understand
        const jobAvailabilitySummary = jobAvailability.map(slot => {
          const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
          return `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 ${slot.timeZone}`;
        }).join(', ');
        
        const userAvailabilitySummary = userAvailability.map(slot => {
          const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
          return `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 ${slot.timeZone || 'UTC'}`;
        }).join(', ');
        
        // Use AI to calculate match score
        const aiMatch = await calculateAIJobMatchScore({
          // Job details
          jobTitle: job.title,
          jobDescription: job.description || '',
          jobSkills,
          jobHourlyRate: job.hourlyRate || '',
          jobCurrency: job.currency || 'USD',
          jobRequiredLanguages: jobLanguages,
          jobRoleName,
          jobAvailability: jobAvailabilitySummary,
          jobHoursPerWeek: job.hoursPerWeek || 0,
          jobFamily: job.jobFamily || "Other",
          jobMinSalary: job.minSalary,
          jobMaxSalary: job.maxSalary,
          jobSalaryType: job.salaryType || 'hourly',
          
          // User details
          userJobRoles: userJobRoleNames,
          userSkills: userSkillNames,
          userLanguages,
          userTimeZone: user.timeZone || 'UTC',
          userAvailability: userAvailabilitySummary,
          userPreferredHours: user.preferredHoursPerWeek || 0,
          userJobFamily: userPrimaryJobRole?.jobFamily as string || "Other",
          userMinSalary: user.minSalaryRequirement,
          userMaxSalary: user.maxSalaryRequirement,
          userSalaryType: user.preferredSalaryType || 'hourly'
        });
        
        // Get job family
        let jobFamily = "Other";
        if (job.jobRoleId) {
          const jobRole = await this.getJobRole(job.jobRoleId);
          if (jobRole?.jobFamily) {
            jobFamily = jobRole.jobFamily as string;
          }
        }
        
        // MATCH ACROSS ALL USER JOB ROLES - Check if any of the user's job roles match the job family
        // Extract job families from all user roles
        const userJobFamilies = userJobRoles
          .filter(userRole => userRole.role?.jobFamily) // Only consider roles that have job families
          .map(userRole => userRole.role?.jobFamily as string);
          
        // Add primary role family if it exists and isn't already included
        if (userPrimaryJobRole?.jobFamily && !userJobFamilies.includes(userPrimaryJobRole.jobFamily as string)) {
          userJobFamilies.push(userPrimaryJobRole.jobFamily as string);
        }
        
        // If no job families found for user, allow the match to proceed
        if (userJobFamilies.length > 0) {
          // Skip if none of the user's job families match the job's family
          if (!userJobFamilies.includes(jobFamily)) {
            const primaryRoleFamily = userPrimaryJobRole?.jobFamily || "Unknown";
            console.log(`Job ${job.id} (${job.title}) skipped due to job family mismatch: User has [${userJobFamilies.join(', ')}] but job is "${jobFamily}". Primary role is "${primaryRoleFamily}"`);
            continue;
          }
        }
        
        // Create match score from AI result (only for jobs in the same family)
        const matchScore: JobMatchScore = {
          overallScore: aiMatch.matchScore,
          roleScore: aiMatch.keyFactors.roleMatch,
          skillsScore: aiMatch.keyFactors.skillsMatch,
          availabilityScore: aiMatch.keyFactors.availabilityMatch,
          skillsMatchPercentage: aiMatch.keyFactors.skillsMatch, // Use skill match score as percentage
          matchDetails: {
            // Traditional match details (can be empty for AI matching)
            matchedRoleId: 0,
            matchedSkillIds: [],
            requiredSkillsCount: jobSkills.length,
            matchedSkillsCount: 0, // Will be calculated differently by AI
            
            // AI-specific match details
            aiMatchExplanation: aiMatch.matchExplanation,
            aiStrengths: aiMatch.strengths,
            aiGaps: aiMatch.gaps,
            aiLanguageMatch: aiMatch.keyFactors.languageMatch,
            jobFamilyMatch: (aiMatch.keyFactors.jobFamilyMatch || 0) > 0,
            aiCompensationMatch: aiMatch.keyFactors.compensationMatch
          }
        };
        
        // Check if language match is mandatory requirement is met
        if (aiMatch.keyFactors.languageMatch === 0) {
          // If language requirement fails, we skip this job completely
          console.log(`Job ${job.id} skipped due to language mismatch (mandatory requirement)`);
          continue;
        }

        // Enhanced minimum threshold criteria
        // 1. Check for poor role compatibility AND poor skills match
        const lowRoleScore = matchScore.roleScore < 40; // Role score below 40 is very low
        const lowSkillsScore = matchScore.skillsMatchPercentage < 30; // Skills match below 30% is very low
        
        // If both role and skills matches are poor, filter out the job entirely
        if (lowRoleScore && lowSkillsScore) {
          console.log(`Job ${job.id} (${job.title}) skipped due to both low role score (${matchScore.roleScore}) and low skills match (${matchScore.skillsMatchPercentage}%)`);
          continue;
        }
        
        // For jobs that pass both language requirement and role/skills minimums
        // We still check overall score as a final filter
        if (matchScore.overallScore > 30) { // Increased from 20 to 30 for better quality matches
          // Add the match score details to the job
          job.matchScore = matchScore;
          jobMatches.push({ job, score: matchScore.overallScore });
        }
      } catch (error) {
        console.error(`Error calculating AI match for job ${job.id}:`, error);
        // If AI matching fails, skip this job
        continue;
      }
    }
    
    // Sort by score (highest first) and return just the jobs
    return jobMatches.sort((a, b) => b.score - a.score).map(match => match.job);
  }

  async findMatchingWorkersForJob(jobId: number): Promise<User[]> {
    const job = await this.getJob(jobId);
    if (!job) return [];
    
    // Get all users
    const allUsers = await this.getAllUsers();
    
    // Import the Anthropic service for AI-powered matching
    const { calculateAIJobMatchScore } = await import('./services/anthropic');
    
    // Array to store matches with scores
    const userMatches: { user: User; score: number }[] = [];
    
    // Get job details
    let jobRoleName = '';
    if (job.jobRoleId) {
      const jobRole = await this.getJobRole(job.jobRoleId);
      if (jobRole) {
        jobRoleName = jobRole.name;
      }
    }
    
    // Get job skills as string array for AI matching
    const jobSkillIds = job.requiredSkills || [];
    const jobSkills: string[] = [];
    
    if (jobSkillIds.length > 0) {
      for (const skillId of jobSkillIds) {
        const skill = await this.getSkill(skillId);
        if (skill) {
          jobSkills.push(skill.name);
        }
      }
    }
    
    // Parse required languages into array
    const jobLanguages = job.requiredLanguages ? job.requiredLanguages.split(',').map(lang => lang.trim()) : [];
    
    // Prepare availability data
    const jobAvailability = job.requiredAvailability || [];
    
    // Convert to user-friendly format that Claude can understand
    const jobAvailabilitySummary = jobAvailability.map(slot => {
      const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      return `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 ${slot.timeZone}`;
    }).join(', ');

    for (const user of allUsers) {
      try {
        // Get user skills, availability, and job roles
        const userSkills = await this.getUserSkills(user.id);
        const userAvailability = await this.getUserAvailability(user.id);
        const userJobRoles = await this.getUserJobRoles(user.id);
        
        // Get user skills as string array for AI matching
        const userSkillNames = userSkills.map(skill => skill.name);
        
        // Get the actual job role names for better AI matching
        const userJobRoleNames: string[] = [];
        // Get primary job role for job family matching
        const userPrimaryJobRole = userJobRoles.find(role => role.isPrimary)?.role || userJobRoles[0]?.role;
        for (const userRole of userJobRoles) {
          const roleName = userRole.role?.name;
          if (roleName) {
            userJobRoleNames.push(roleName);
          }
        }
        
        // Extract user languages
        const userLanguages = user.languages ? user.languages.split(',').map(lang => lang.trim()) : [];
        
        // Convert user availability to user-friendly format
        const userAvailabilitySummary = userAvailability.map(slot => {
          const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
          return `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 ${slot.timeZone || 'UTC'}`;
        }).join(', ');
        
        // Use AI to calculate match score
        const aiMatch = await calculateAIJobMatchScore({
          // Job details
          jobTitle: job.title,
          jobDescription: job.description || '',
          jobSkills,
          jobHourlyRate: job.hourlyRate || '',
          jobCurrency: job.currency || 'USD',
          jobRequiredLanguages: jobLanguages,
          jobRoleName,
          jobAvailability: jobAvailabilitySummary,
          jobHoursPerWeek: job.hoursPerWeek || 0,
          jobFamily: job.jobFamily || "Other",
          jobMinSalary: job.minSalary,
          jobMaxSalary: job.maxSalary,
          jobSalaryType: job.salaryType || 'hourly',
          
          // User details
          userJobRoles: userJobRoleNames,
          userSkills: userSkillNames,
          userLanguages,
          userTimeZone: user.timeZone || 'UTC',
          userAvailability: userAvailabilitySummary,
          userPreferredHours: user.preferredHoursPerWeek || 0,
          userJobFamily: userPrimaryJobRole?.jobFamily as string || "Other",
          userMinSalary: user.minSalaryRequirement,
          userMaxSalary: user.maxSalaryRequirement,
          userSalaryType: user.preferredSalaryType || 'hourly'
        });
        
        // Get job family from job role
        let jobFamily = "Other";
        if (job.jobRoleId) {
          const jobRole = await this.getJobRole(job.jobRoleId);
          if (jobRole?.jobFamily) {
            jobFamily = jobRole.jobFamily as string;
          }
        }
        
        // MATCH ACROSS ALL USER JOB ROLES - Check if any of the user's job roles match the job family
        // Extract job families from all user roles
        const userJobFamilies = userJobRoles
          .filter(userRole => userRole.role?.jobFamily) // Only consider roles that have job families
          .map(userRole => userRole.role?.jobFamily as string);
          
        // Add primary role family if it exists and isn't already included
        if (userPrimaryJobRole?.jobFamily && !userJobFamilies.includes(userPrimaryJobRole.jobFamily as string)) {
          userJobFamilies.push(userPrimaryJobRole.jobFamily as string);
        }
        
        // If no job families found for user, allow the match to proceed
        if (userJobFamilies.length > 0) {
          // Skip if none of the user's job families match the job's family
          if (!userJobFamilies.includes(jobFamily)) {
            const primaryRoleFamily = userPrimaryJobRole?.jobFamily || "Unknown";
            console.log(`User ${user.id} skipped due to job family mismatch: User has [${userJobFamilies.join(', ')}] but job is "${jobFamily}". Primary role is "${primaryRoleFamily}"`);
            continue;
          }
        }
        
        // Create match score from AI result (only for users in the same job family)
        const matchScore: JobMatchScore = {
          overallScore: aiMatch.matchScore,
          roleScore: aiMatch.keyFactors.roleMatch,
          skillsScore: aiMatch.keyFactors.skillsMatch,
          availabilityScore: aiMatch.keyFactors.availabilityMatch,
          skillsMatchPercentage: aiMatch.keyFactors.skillsMatch, // Use skill match score as percentage
          matchDetails: {
            // Traditional match details (can be empty for AI matching)
            matchedRoleId: 0,
            matchedSkillIds: [],
            requiredSkillsCount: jobSkills.length,
            matchedSkillsCount: 0, // Will be calculated differently by AI
            
            // AI-specific match details
            aiMatchExplanation: aiMatch.matchExplanation,
            aiStrengths: aiMatch.strengths,
            aiGaps: aiMatch.gaps,
            aiLanguageMatch: aiMatch.keyFactors.languageMatch,
            jobFamilyMatch: (aiMatch.keyFactors.jobFamilyMatch || 0) > 0,
            aiCompensationMatch: aiMatch.keyFactors.compensationMatch
          }
        };
        
        // Check if language match requirement is met
        if (aiMatch.keyFactors.languageMatch === 0) {
          // If language requirement fails, we skip this user completely
          console.log(`User ${user.id} skipped due to language mismatch (mandatory requirement)`);
          continue;
        }

        // Enhanced minimum threshold criteria
        // 1. Check for poor role compatibility AND poor skills match
        const lowRoleScore = matchScore.roleScore < 40; // Role score below 40 is very low
        const lowSkillsScore = matchScore.skillsMatchPercentage < 30; // Skills match below 30% is very low
        
        // If both role and skills matches are poor, filter out the user entirely
        if (lowRoleScore && lowSkillsScore) {
          console.log(`User ${user.id} skipped due to both low role score (${matchScore.roleScore}) and low skills match (${matchScore.skillsMatchPercentage}%)`);
          continue;
        }
        
        // For users that pass both language requirement and role/skills minimums
        // We still check overall score as a final filter
        if (matchScore.overallScore > 30) { // Increased from 20 to 30 for better quality matches
          // Set match score on user for UI display if needed
          user.matchScore = matchScore;
          userMatches.push({ user, score: matchScore.overallScore });
        }
      } catch (error) {
        console.error(`Error calculating AI match for user ${user.id}:`, error);
        // If AI matching fails, skip this user
        continue;
      }
    }
    
    // Sort by score (highest first) and return just the users
    return userMatches.sort((a, b) => b.score - a.score).map(match => match.user);
  }

  // Subscription plans
  async getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined> {
    const [plan] = await db
      .select()
      .from(subscriptionPlans)
      .where(eq(subscriptionPlans.id, id));
    return plan;
  }

  async getAllSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return db.select().from(subscriptionPlans);
  }

  async createSubscriptionPlan(planData: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    const [plan] = await db
      .insert(subscriptionPlans)
      .values(planData)
      .returning();
    return plan;
  }

  // User subscriptions
  async getUserSubscription(userId: number): Promise<UserSubscription | undefined> {
    const [subscription] = await db
      .select()
      .from(userSubscriptions)
      .where(and(
        eq(userSubscriptions.userId, userId),
        eq(userSubscriptions.isActive, true)
      ));
    return subscription;
  }
  
  async getUserSubscriptionByStripeId(stripeSubscriptionId: string): Promise<UserSubscription | undefined> {
    const [subscription] = await db
      .select()
      .from(userSubscriptions)
      .where(eq(userSubscriptions.stripeSubscriptionId, stripeSubscriptionId));
    return subscription;
  }

  async createUserSubscription(subscriptionData: InsertUserSubscription): Promise<UserSubscription> {
    const [subscription] = await db
      .insert(userSubscriptions)
      .values(subscriptionData)
      .returning();
    return subscription;
  }

  async updateUserSubscription(id: number, data: Partial<UserSubscription>): Promise<UserSubscription | undefined> {
    const [updatedSubscription] = await db
      .update(userSubscriptions)
      .set(data)
      .where(eq(userSubscriptions.id, id))
      .returning();
    return updatedSubscription;
  }

  async incrementSearchCount(userId: number): Promise<UserSubscription | undefined> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return undefined;
    
    const [updatedSubscription] = await db
      .update(userSubscriptions)
      .set({ 
        searchesUsed: subscription.searchesUsed + 1 
      })
      .where(eq(userSubscriptions.id, subscription.id))
      .returning();
    
    return updatedSubscription;
  }

  async incrementApplicantViewCount(userId: number): Promise<UserSubscription | undefined> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return undefined;
    
    const [updatedSubscription] = await db
      .update(userSubscriptions)
      .set({ 
        applicantViewsUsed: subscription.applicantViewsUsed + 1 
      })
      .where(eq(userSubscriptions.id, subscription.id))
      .returning();
    
    return updatedSubscription;
  }
  
  // Job match caching system
  
  async getCachedMatch(userId: number, jobId: number): Promise<JobMatchCache | undefined> {
    try {
      const [match] = await db
        .select()
        .from(jobMatchesCache)
        .where(and(
          eq(jobMatchesCache.userId, userId),
          eq(jobMatchesCache.jobId, jobId)
        ));
      
      return match;
    } catch (error) {
      console.error("Error getting cached match:", error);
      return undefined;
    }
  }
  
  async saveMatchToCache(userId: number, jobId: number, match: AIJobMatchResult): Promise<JobMatchCache | undefined> {
    try {
      // Check if there's an existing cache entry
      const existingMatch = await this.getCachedMatch(userId, jobId);
      
      if (existingMatch) {
        // Update existing record
        const [updated] = await db
          .update(jobMatchesCache)
          .set({
            matchScore: match.matchScore,
            roleScore: match.keyFactors.roleMatch,
            skillsScore: match.keyFactors.skillsMatch,
            availabilityScore: match.keyFactors.availabilityMatch,
            languageMatch: match.keyFactors.languageMatch,
            compensationMatch: match.keyFactors.compensationMatch,
            matchExplanation: match.matchExplanation,
            strengths: JSON.stringify(match.strengths),
            gaps: JSON.stringify(match.gaps),
            lastUpdated: new Date()
          })
          .where(eq(jobMatchesCache.id, existingMatch.id))
          .returning();
          
        return updated;
      } else {
        // Create new record
        const [newCache] = await db
          .insert(jobMatchesCache)
          .values({
            userId,
            jobId,
            matchScore: match.matchScore,
            roleScore: match.keyFactors.roleMatch,
            skillsScore: match.keyFactors.skillsMatch,
            availabilityScore: match.keyFactors.availabilityMatch,
            languageMatch: match.keyFactors.languageMatch,
            compensationMatch: match.keyFactors.compensationMatch,
            matchExplanation: match.matchExplanation,
            strengths: JSON.stringify(match.strengths),
            gaps: JSON.stringify(match.gaps),
            lastUpdated: new Date()
          })
          .returning();
          
        return newCache;
      }
    } catch (error) {
      console.error("Error saving match to cache:", error);
      return undefined;
    }
  }
  
  async clearMatchCache(userId: number, jobId?: number): Promise<void> {
    try {
      if (jobId) {
        // Clear specific match
        await db
          .delete(jobMatchesCache)
          .where(and(
            eq(jobMatchesCache.userId, userId),
            eq(jobMatchesCache.jobId, jobId)
          ));
      } else {
        // Clear all matches for user
        await db
          .delete(jobMatchesCache)
          .where(eq(jobMatchesCache.userId, userId));
      }
    } catch (error) {
      console.error("Error clearing match cache:", error);
    }
  }
  
  async getAllCachedMatchesForUser(userId: number): Promise<JobMatchCache[]> {
    try {
      return await db
        .select()
        .from(jobMatchesCache)
        .where(eq(jobMatchesCache.userId, userId));
    } catch (error) {
      console.error("Error getting all cached matches for user:", error);
      return [];
    }
  }

  async checkSubscriptionForApplicantView(userId: number, jobId?: number): Promise<boolean> {
    console.log(`Checking subscription for user ${userId} to view jobId ${jobId}`);
    
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) {
      console.log(`No subscription found for user ${userId}`);
      return false;
    }
    
    const plan = await this.getSubscriptionPlan(subscription.planId);
    if (!plan) {
      console.log(`No plan found for subscription ${subscription.id}`);
      return false;
    }
    
    console.log(`User has ${plan.name} subscription. isActive: ${subscription.isActive}`);
    
    // Check if subscription is active
    if (!subscription.isActive) {
      console.log(`Subscription is not active`);
      return false;
    }
    
    // Simple check for total number of uses
    const basicCheck = plan.isUnlimited || subscription.applicantViewsUsed < plan.maxApplicantViews;
    if (!basicCheck) {
      console.log(`Exceeded max applicant views`);
      return false;
    }
    
    // For Basic subscriptions (ID 1), check if the jobId matches
    if (plan.id === 1 && jobId) {
      // For Basic (Single Job) plan, check if the subscription is for this specific job
      if (subscription.jobId) {
        const hasAccessToJob = subscription.jobId === jobId;
        console.log(`Basic plan check: hasAccessToJob = ${hasAccessToJob}, subscription.jobId = ${subscription.jobId}, requested jobId = ${jobId}`);
        return hasAccessToJob;
      } else {
        console.log(`Basic plan with no specific job ID set. Cannot view applications.`);
        return false;
      }
    }
    
    // For Standard (ID 2) and Premium (ID 3) plans, the basic check is enough
    console.log(`Standard or Premium plan, access granted`);
    return true;
  }

  async checkSubscriptionForSearch(userId: number): Promise<boolean> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return false;
    
    const plan = await this.getSubscriptionPlan(subscription.planId);
    if (!plan) return false;
    
    // Only Premium plan allows searching
    if (plan.name !== "Premium") return false;
    
    return plan.isUnlimited || subscription.searchesUsed < plan.maxSearches;
  }

  // Password reset token methods
  async createPasswordResetToken(data: InsertPasswordResetToken): Promise<PasswordResetToken> {
    const [token] = await db
      .insert(passwordResetTokens)
      .values(data)
      .returning();
    return token;
  }

  async getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined> {
    const [resetToken] = await db
      .select()
      .from(passwordResetTokens)
      .where(
        and(
          eq(passwordResetTokens.token, token),
          eq(passwordResetTokens.used, false),
          gt(passwordResetTokens.expiresAt, new Date())
        )
      );
    return resetToken;
  }

  async markTokenAsUsed(token: string): Promise<PasswordResetToken | undefined> {
    const [updatedToken] = await db
      .update(passwordResetTokens)
      .set({ used: true })
      .where(eq(passwordResetTokens.token, token))
      .returning();
    return updatedToken;
  }
}