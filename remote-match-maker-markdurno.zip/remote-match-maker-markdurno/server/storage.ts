// Import schema and types
import { 
  users, skills, userSkills, availabilitySlots, jobs, jobApplications,
  subscriptionPlans, userSubscriptions, jobRoles, messages, userJobRoles,
  directMessages, qualifications, userQualifications, passwordResetTokens
} from "@shared/schema";
import type { 
  User, InsertUser, 
  Skill, InsertSkill, 
  UserSkill, InsertUserSkill, 
  AvailabilitySlot, InsertAvailabilitySlot,
  Job, InsertJob, JobAvailabilityRequirement,
  JobApplication, InsertJobApplication,
  SubscriptionPlan, InsertSubscriptionPlan,
  UserSubscription, InsertUserSubscription,
  JobRole, InsertJobRole,
  UserJobRole, InsertUserJobRole,
  JobMatchScore,
  Message, InsertMessage,
  DirectMessage, InsertDirectMessage,
  Qualification, InsertQualification,
  UserQualification, InsertUserQualification,
  PasswordResetToken, InsertPasswordResetToken
} from "@shared/schema";

// Import session-related modules
import session from "express-session";
import createMemoryStore from "memorystore";

// Setup MemoryStore
const MemoryStore = createMemoryStore(session);

// Import DatabaseStorage from db-storage.ts
import { DatabaseStorage } from "./db-storage";

export interface IStorage {
  // Job Role management
  getJobRole(id: number): Promise<JobRole | undefined>;
  getJobRoleByName(name: string): Promise<JobRole | undefined>;
  getAllJobRoles(): Promise<JobRole[]>;
  createJobRole(role: InsertJobRole): Promise<JobRole>;
  
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPassword(userId: number, hashedPassword: string): Promise<User | undefined>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  getUsersByJobRole(jobRoleId: number): Promise<User[]>;
  
  // Skills management
  getSkill(id: number): Promise<Skill | undefined>;
  getSkillByName(name: string): Promise<Skill | undefined>;
  getAllSkills(): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  
  // User skills
  getUserSkills(userId: number): Promise<Skill[]>;
  addUserSkill(userSkill: InsertUserSkill): Promise<UserSkill>;
  removeUserSkill(userId: number, skillId: number): Promise<void>;
  
  // Qualifications
  getQualification(id: number): Promise<Qualification | undefined>;
  getQualificationByName(name: string): Promise<Qualification | undefined>;
  getAllQualifications(): Promise<Qualification[]>;
  createQualification(qualification: InsertQualification): Promise<Qualification>;
  
  // User qualifications
  getUserQualifications(userId: number): Promise<Qualification[]>;
  addUserQualification(userQualification: InsertUserQualification): Promise<UserQualification>;
  removeUserQualification(userId: number, qualificationId: number): Promise<void>;
  
  // User job roles
  getUserJobRoles(userId: number): Promise<(UserJobRole & { role: JobRole })[]>;
  addUserJobRole(userJobRole: InsertUserJobRole): Promise<UserJobRole>;
  removeUserJobRole(userId: number, jobRoleId: number): Promise<void>;
  setPrimaryUserJobRole(userId: number, jobRoleId: number, experienceLevel?: string | null): Promise<UserJobRole | undefined>;
  updateUserJobRoleExperience(userId: number, jobRoleId: number, experienceLevel: string | null): Promise<UserJobRole | undefined>;
  
  // Availability management
  getUserAvailability(userId: number): Promise<AvailabilitySlot[]>;
  addAvailabilitySlot(slot: InsertAvailabilitySlot): Promise<AvailabilitySlot>;
  removeAvailabilitySlot(id: number): Promise<void>;
  
  // Job management
  getJob(id: number): Promise<Job | undefined>;
  getAllJobs(): Promise<Job[]>;
  getJobsByEmployer(employerId: number): Promise<Job[]>;
  searchJobs(query: string, filters?: object): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, job: Partial<Job>): Promise<Job | undefined>;
  
  // Job applications
  getJobApplication(id: number): Promise<JobApplication | undefined>;
  getJobApplicationsForJob(jobId: number): Promise<JobApplication[]>;
  getUserJobApplications(userId: number): Promise<JobApplication[]>;
  createJobApplication(application: InsertJobApplication): Promise<JobApplication>;
  updateJobApplicationStatus(id: number, status: string): Promise<JobApplication | undefined>;
  getJobApplicationWithDetails(id: number): Promise<(JobApplication & { job: Job; jobseeker: User }) | undefined>;
  
  // Messages
  getMessages(applicationId: number): Promise<Message[]>;
  getMessagesByUser(userId: number): Promise<Message[]>;
  getUnreadMessageCount(userId: number): Promise<number>;
  sendMessage(message: InsertMessage): Promise<Message>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
  
  // Direct Messages (not tied to job applications)
  getDirectMessages(userId1: number, userId2: number): Promise<DirectMessage[]>;
  getDirectMessagesByUser(userId: number): Promise<DirectMessage[]>;
  getUnreadDirectMessageCount(userId: number): Promise<number>;
  sendDirectMessage(message: InsertDirectMessage): Promise<DirectMessage>;
  markDirectMessageAsRead(id: number): Promise<DirectMessage | undefined>;
  
  // Search and matching
  findMatchingJobsForUser(userId: number): Promise<Job[]>;
  findMatchingWorkersForJob(jobId: number): Promise<User[]>;
  
  // Subscription plans
  getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined>;
  getAllSubscriptionPlans(): Promise<SubscriptionPlan[]>;
  createSubscriptionPlan(plan: InsertSubscriptionPlan): Promise<SubscriptionPlan>;
  
  // User subscriptions
  getUserSubscription(userId: number): Promise<UserSubscription | undefined>;
  getUserSubscriptionByStripeId(stripeSubscriptionId: string): Promise<UserSubscription | undefined>;
  createUserSubscription(subscription: InsertUserSubscription): Promise<UserSubscription>;
  updateUserSubscription(id: number, subscription: Partial<UserSubscription>): Promise<UserSubscription | undefined>;
  incrementSearchCount(userId: number): Promise<UserSubscription | undefined>;
  incrementApplicantViewCount(userId: number): Promise<UserSubscription | undefined>;
  checkSubscriptionForApplicantView(userId: number, jobId?: number): Promise<boolean>;
  checkSubscriptionForSearch(userId: number): Promise<boolean>;
  
  // Password reset tokens
  createPasswordResetToken(data: InsertPasswordResetToken): Promise<PasswordResetToken>;
  getPasswordResetToken(token: string): Promise<PasswordResetToken | undefined>;
  markTokenAsUsed(token: string): Promise<PasswordResetToken | undefined>;
  
  // Session store for authentication
  sessionStore: any; // Using 'any' as the Express session store type
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private skills: Map<number, Skill>;
  private userSkills: Map<number, UserSkill>;
  private userJobRoles: Map<number, UserJobRole>;
  private availabilitySlots: Map<number, AvailabilitySlot>;
  private jobs: Map<number, Job>;
  private jobApplications: Map<number, JobApplication>;
  private subscriptionPlans: Map<number, SubscriptionPlan>;
  private userSubscriptions: Map<number, UserSubscription>;
  private jobRoles: Map<number, JobRole>;
  private messages: Map<number, Message>;
  private directMessages: Map<number, DirectMessage>;
  private qualifications: Map<number, Qualification>;
  private userQualifications: Map<number, UserQualification>;
  private passwordResetTokens: Map<number, PasswordResetToken>;
  sessionStore: any; // Using 'any' as the Express session store type
  
  private userId: number = 1;
  private skillId: number = 1;
  private userSkillId: number = 1;
  private userJobRoleId: number = 1;
  private availabilitySlotId: number = 1;
  private jobId: number = 1;
  private jobApplicationId: number = 1;
  private subscriptionPlanId: number = 1;
  private userSubscriptionId: number = 1;
  private jobRoleId: number = 1;
  private messageId: number = 1;
  private directMessageId: number = 1;
  private qualificationId: number = 1;
  private userQualificationId: number = 1;
  private passwordResetTokenId: number = 1;

  constructor() {
    this.users = new Map();
    this.skills = new Map();
    this.userSkills = new Map();
    this.userJobRoles = new Map();
    this.availabilitySlots = new Map();
    this.jobs = new Map();
    this.jobApplications = new Map();
    this.subscriptionPlans = new Map();
    this.userSubscriptions = new Map();
    this.jobRoles = new Map();
    this.messages = new Map();
    this.directMessages = new Map();
    this.qualifications = new Map();
    this.userQualifications = new Map();
    this.passwordResetTokens = new Map();
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
    
    // Add some initial test jobs
    this.initializeMockData();
  }
  
  // Job Role management
  async getJobRole(id: number): Promise<JobRole | undefined> {
    return this.jobRoles.get(id);
  }
  
  async getJobRoleByName(name: string): Promise<JobRole | undefined> {
    return Array.from(this.jobRoles.values()).find(
      (role) => role.name.toLowerCase() === name.toLowerCase(),
    );
  }
  
  async getAllJobRoles(): Promise<JobRole[]> {
    return Array.from(this.jobRoles.values());
  }
  
  async createJobRole(roleData: InsertJobRole): Promise<JobRole> {
    const id = this.jobRoleId++;
    const role: JobRole = { 
      ...roleData, 
      id,
      category: roleData.category || null 
    };
    this.jobRoles.set(id, role);
    return role;
  }
  
  async getUsersByJobRole(jobRoleId: number): Promise<User[]> {
    return Array.from(this.users.values()).filter(
      (user) => user.jobRoleId === jobRoleId
    );
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.userId++;
    const createdAt = new Date();
    const user: User = { 
      ...userData, 
      id, 
      createdAt,
      location: userData.location || null,
      timeZone: userData.timeZone || null,
      bio: userData.bio || null,
      avatarUrl: userData.avatarUrl || null,
      jobRoleId: userData.jobRoleId || null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Skills management
  async getSkill(id: number): Promise<Skill | undefined> {
    return this.skills.get(id);
  }

  async getSkillByName(name: string): Promise<Skill | undefined> {
    return Array.from(this.skills.values()).find(
      (skill) => skill.name.toLowerCase() === name.toLowerCase(),
    );
  }

  async getAllSkills(): Promise<Skill[]> {
    return Array.from(this.skills.values());
  }

  async createSkill(skillData: InsertSkill): Promise<Skill> {
    const id = this.skillId++;
    const skill: Skill = { ...skillData, id };
    this.skills.set(id, skill);
    return skill;
  }

  // User skills
  async getUserSkills(userId: number): Promise<Skill[]> {
    const userSkillEntries = Array.from(this.userSkills.values()).filter(
      (userSkill) => userSkill.userId === userId
    );
    
    return Promise.all(
      userSkillEntries.map(async (entry) => {
        const skill = await this.getSkill(entry.skillId);
        return skill!;
      })
    );
  }

  async addUserSkill(userSkillData: InsertUserSkill): Promise<UserSkill> {
    const id = this.userSkillId++;
    const userSkill: UserSkill = { ...userSkillData, id };
    this.userSkills.set(id, userSkill);
    return userSkill;
  }

  async removeUserSkill(userId: number, skillId: number): Promise<void> {
    const userSkillEntry = Array.from(this.userSkills.values()).find(
      (entry) => entry.userId === userId && entry.skillId === skillId
    );
    
    if (userSkillEntry) {
      this.userSkills.delete(userSkillEntry.id);
    }
  }

  // User job roles
  async getUserJobRoles(userId: number): Promise<(UserJobRole & { role: JobRole })[]> {
    const userJobRoleEntries = Array.from(this.userJobRoles.values()).filter(
      (userJobRole) => userJobRole.userId === userId
    );
    
    return Promise.all(
      userJobRoleEntries.map(async (entry) => {
        const role = await this.getJobRole(entry.jobRoleId);
        return { ...entry, role: role! };
      })
    );
  }

  async addUserJobRole(userJobRoleData: InsertUserJobRole): Promise<UserJobRole> {
    // If setting this as primary, first set all existing roles to non-primary
    if (userJobRoleData.isPrimary) {
      for (const [id, userJobRole] of this.userJobRoles) {
        if (userJobRole.userId === userJobRoleData.userId && userJobRole.isPrimary) {
          this.userJobRoles.set(id, { ...userJobRole, isPrimary: false });
        }
      }
    }
    
    const id = this.userJobRoleId++;
    const userJobRole: UserJobRole = { 
      ...userJobRoleData, 
      id,
      isPrimary: userJobRoleData.isPrimary || false 
    };
    this.userJobRoles.set(id, userJobRole);
    return userJobRole;
  }

  async removeUserJobRole(userId: number, jobRoleId: number): Promise<void> {
    const userJobRoleEntry = Array.from(this.userJobRoles.values()).find(
      (entry) => entry.userId === userId && entry.jobRoleId === jobRoleId
    );
    
    if (userJobRoleEntry) {
      this.userJobRoles.delete(userJobRoleEntry.id);
      
      // If the removed role was primary, set another role as primary if available
      if (userJobRoleEntry.isPrimary) {
        const remainingUserRoles = Array.from(this.userJobRoles.values()).filter(
          (entry) => entry.userId === userId
        );
        
        if (remainingUserRoles.length > 0) {
          const firstRoleId = remainingUserRoles[0].id;
          this.userJobRoles.set(firstRoleId, { ...remainingUserRoles[0], isPrimary: true });
        }
      }
    }
  }

  async setPrimaryUserJobRole(userId: number, jobRoleId: number, experienceLevel?: string | null): Promise<UserJobRole | undefined> {
    // Find the role to set as primary
    const roleToMakePrimary = Array.from(this.userJobRoles.values()).find(
      (entry) => entry.userId === userId && entry.jobRoleId === jobRoleId
    );
    
    if (!roleToMakePrimary) return undefined;
    
    // Set all other roles for this user to non-primary
    for (const [id, userJobRole] of this.userJobRoles) {
      if (userJobRole.userId === userId && userJobRole.isPrimary) {
        this.userJobRoles.set(id, { ...userJobRole, isPrimary: false });
      }
    }
    
    // Set the target role as primary and update experience level if provided
    const updatedRole = { 
      ...roleToMakePrimary, 
      isPrimary: true,
      // Only update experience level if it's provided
      ...(experienceLevel !== undefined && { experienceLevel })
    };
    
    this.userJobRoles.set(roleToMakePrimary.id, updatedRole);
    return updatedRole;
  }

  async updateUserJobRoleExperience(userId: number, jobRoleId: number, experienceLevel: string | null): Promise<UserJobRole | undefined> {
    // Find the role to update
    const userJobRole = Array.from(this.userJobRoles.values()).find(
      (entry) => entry.userId === userId && entry.jobRoleId === jobRoleId
    );
    
    if (!userJobRole) return undefined;
    
    // Update the experience level
    const updatedRole = { ...userJobRole, experienceLevel };
    
    this.userJobRoles.set(userJobRole.id, updatedRole);
    return updatedRole;
  }

  // Availability management
  async getUserAvailability(userId: number): Promise<AvailabilitySlot[]> {
    return Array.from(this.availabilitySlots.values()).filter(
      (slot) => slot.userId === userId
    );
  }

  async addAvailabilitySlot(slotData: InsertAvailabilitySlot): Promise<AvailabilitySlot> {
    const id = this.availabilitySlotId++;
    const slot: AvailabilitySlot = { 
      ...slotData, 
      id,
      timeZone: slotData.timeZone || null 
    };
    this.availabilitySlots.set(id, slot);
    return slot;
  }

  async removeAvailabilitySlot(id: number): Promise<void> {
    this.availabilitySlots.delete(id);
  }

  // Job management
  async getJob(id: number): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async getAllJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter(job => job.status === 'active');
  }

  async getJobsByEmployer(employerId: number): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter(
      (job) => job.employerId === employerId
    );
  }

  async searchJobs(query: string, filters: any = {}): Promise<Job[]> {
    let jobs = Array.from(this.jobs.values()).filter(job => job.status === 'active');
    
    if (query) {
      const lowerQuery = query.toLowerCase();
      jobs = jobs.filter(job => 
        job.title.toLowerCase().includes(lowerQuery) || 
        (job.description && job.description.toLowerCase().includes(lowerQuery))
      );
    }
    
    // Apply filters
    if (filters.jobType) {
      jobs = jobs.filter(job => job.jobType === filters.jobType);
    }
    
    if (filters.minHours) {
      jobs = jobs.filter(job => 
        (job.minHoursPerWeek && job.minHoursPerWeek >= filters.minHours) ||
        (job.hoursPerWeek && job.hoursPerWeek >= filters.minHours)
      );
    }
    
    if (filters.maxHours) {
      jobs = jobs.filter(job => 
        (job.maxHoursPerWeek && job.maxHoursPerWeek <= filters.maxHours) ||
        (job.hoursPerWeek && job.hoursPerWeek <= filters.maxHours)
      );
    }
    
    if (filters.timeZoneOverlap) {
      jobs = jobs.filter(job => 
        job.timeZoneOverlap && job.timeZoneOverlap.includes(filters.timeZoneOverlap)
      );
    }
    
    return jobs;
  }

  async createJob(jobData: InsertJob): Promise<Job> {
    const id = this.jobId++;
    const createdAt = new Date();
    const status = "active";
    const job: Job = { 
      ...jobData, 
      id, 
      createdAt, 
      status,
      location: jobData.location || null,
      jobRoleId: jobData.jobRoleId || null,
      hoursPerWeek: jobData.hoursPerWeek || null,
      minHoursPerWeek: jobData.minHoursPerWeek || null,
      maxHoursPerWeek: jobData.maxHoursPerWeek || null,
      salary: jobData.salary || null,
      description: jobData.description || null,
      requiredSkills: jobData.requiredSkills || [],
      requiredAvailability: jobData.requiredAvailability || [],
      timeZoneOverlap: jobData.timeZoneOverlap || [],
      jobType: jobData.jobType || null
    };
    this.jobs.set(id, job);
    return job;
  }

  async updateJob(id: number, jobData: Partial<Job>): Promise<Job | undefined> {
    const job = await this.getJob(id);
    if (!job) return undefined;
    
    const updatedJob = { ...job, ...jobData };
    this.jobs.set(id, updatedJob);
    return updatedJob;
  }

  // Job applications
  async getJobApplication(id: number): Promise<JobApplication | undefined> {
    return this.jobApplications.get(id);
  }

  async getJobApplicationsForJob(jobId: number): Promise<JobApplication[]> {
    return Array.from(this.jobApplications.values()).filter(
      (application) => application.jobId === jobId
    );
  }

  async getUserJobApplications(userId: number): Promise<JobApplication[]> {
    return Array.from(this.jobApplications.values()).filter(
      (application) => application.jobseekerId === userId
    );
  }

  async createJobApplication(applicationData: InsertJobApplication): Promise<JobApplication> {
    const id = this.jobApplicationId++;
    const createdAt = new Date();
    const status = "pending";
    const application: JobApplication = { 
      ...applicationData, 
      id, 
      createdAt, 
      status,
      message: applicationData.message || null 
    };
    this.jobApplications.set(id, application);
    return application;
  }

  async updateJobApplicationStatus(id: number, status: string): Promise<JobApplication | undefined> {
    const application = await this.getJobApplication(id);
    if (!application) return undefined;
    
    const updatedApplication = { ...application, status };
    this.jobApplications.set(id, updatedApplication);
    return updatedApplication;
  }
  
  async getJobApplicationWithDetails(id: number): Promise<(JobApplication & { job: Job; jobseeker: User }) | undefined> {
    const application = await this.getJobApplication(id);
    if (!application) return undefined;
    
    const job = await this.getJob(application.jobId);
    const jobseeker = await this.getUser(application.jobseekerId);
    
    if (!job || !jobseeker) return undefined;
    
    return {
      ...application,
      job,
      jobseeker
    };
  }

  // Messages
  async getMessages(applicationId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.applicationId === applicationId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }

  async getMessagesByUser(userId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.senderId === userId || message.recipientId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getUnreadMessageCount(userId: number): Promise<number> {
    return Array.from(this.messages.values())
      .filter(message => message.recipientId === userId && !message.isRead)
      .length;
  }

  async sendMessage(messageData: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const createdAt = new Date();
    const isRead = false;
    const message: Message = { ...messageData, id, createdAt, isRead };
    this.messages.set(id, message);
    return message;
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = await this.messages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, isRead: true };
    this.messages.set(id, updatedMessage);
    return updatedMessage;
  }
  
  // Direct Messages (not tied to job applications)
  async getDirectMessages(userId1: number, userId2: number): Promise<DirectMessage[]> {
    return Array.from(this.directMessages.values()).filter(message => 
      (message.senderId === userId1 && message.recipientId === userId2) ||
      (message.senderId === userId2 && message.recipientId === userId1)
    ).sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  }
  
  async getDirectMessagesByUser(userId: number): Promise<DirectMessage[]> {
    return Array.from(this.directMessages.values()).filter(message => 
      message.senderId === userId || message.recipientId === userId
    ).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async getUnreadDirectMessageCount(userId: number): Promise<number> {
    return Array.from(this.directMessages.values()).filter(message => 
      message.recipientId === userId && !message.isRead
    ).length;
  }
  
  async sendDirectMessage(messageData: InsertDirectMessage): Promise<DirectMessage> {
    const id = this.directMessageId++;
    const createdAt = new Date();
    const message: DirectMessage = {
      ...messageData,
      id,
      createdAt,
      isRead: false
    };
    this.directMessages.set(id, message);
    return message;
  }
  
  async markDirectMessageAsRead(id: number): Promise<DirectMessage | undefined> {
    const message = this.directMessages.get(id);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, isRead: true };
    this.directMessages.set(id, updatedMessage);
    return updatedMessage;
  }

  async findMatchingJobsForUser(userId: number): Promise<Job[]> {
    const user = await this.getUser(userId);
    if (!user) return [];
    
    // Get user skills, availability, and job roles (now multiple)
    const userSkills = await this.getUserSkills(userId);
    const userAvailability = await this.getUserAvailability(userId);
    const userJobRoles = await this.getUserJobRoles(userId); // Get all user job roles
    
    // For backward compatibility, still check the legacy single job role field
    const legacyUserJobRoleId = user.jobRoleId;
    
    // Extract job role IDs from user's job roles
    const userJobRoleIds = userJobRoles.map(userRole => userRole.jobRoleId);
    
    // If legacy job role exists and isn't in the new system, add it too
    if (legacyUserJobRoleId && !userJobRoleIds.includes(legacyUserJobRoleId)) {
      userJobRoleIds.push(legacyUserJobRoleId);
    }
    
    const userSkillIds = userSkills.map(skill => skill.id);
    
    // Get all jobs EXCEPT those created by the current user
    const allJobs = await this.getAllJobs();
    const jobs = allJobs.filter(job => job.employerId !== userId);
    
    // Import job role similarity function
    const { calculateRoleMatchScore } = await import('../shared/job-role-utils');
    
    // Array to hold job matches with their match scores
    const jobMatches: { job: Job; score: number }[] = [];
    
    for (const job of jobs) {
      // Initialize match details
      const matchDetails: JobMatchScore = {
        overallScore: 0,
        roleScore: 0,
        availabilityScore: 0,
        skillsScore: 0,
        skillsMatchPercentage: 0
      };
      
      let isEligible = true;
      
      // 1. Job Role is the primary matching criterion (50%)
      if (job.jobRoleId && userJobRoleIds.length > 0) {
        // Find the best role match score from all user roles
        let bestRoleScore = 0;
        
        for (const userRoleId of userJobRoleIds) {
          const currentRoleScore = calculateRoleMatchScore(userRoleId, job.jobRoleId);
          if (currentRoleScore > bestRoleScore) {
            bestRoleScore = currentRoleScore;
          }
        }
        
        matchDetails.roleScore = bestRoleScore;
        
        // If no roles match or aren't similar, this is not a match
        if (matchDetails.roleScore === 0) {
          isEligible = false;
        }
      }
      
      // 2. Check time availability (30%) - if job has required availability
      if (isEligible && job.requiredAvailability && job.requiredAvailability.length > 0) {
        if (userAvailability.length === 0) {
          // User hasn't specified availability, but job requires it
          isEligible = false;
        } else {
          // Check if any user availability overlaps with job required availability
          const hasTimeMatch = job.requiredAvailability.some(jobSlot => {
            return userAvailability.some(userSlot => {
              // Check if days match
              if (userSlot.dayOfWeek !== jobSlot.dayOfWeek) return false;
              
              // Check overlap in hours
              const userStart = userSlot.startHour;
              const userEnd = userSlot.endHour;
              const jobStart = jobSlot.startHour;
              const jobEnd = jobSlot.endHour;
              
              // Hours overlap if user's start time is before job's end time 
              // AND user's end time is after job's start time
              return userStart < jobEnd && userEnd > jobStart;
            });
          });
          
          if (hasTimeMatch) {
            matchDetails.availabilityScore = 30; // 30% of the score is time availability match
          } else {
            // Availability is required and doesn't match - this is not a match
            isEligible = false;
          }
        }
      }
      
      // 3. Skill matching as the third criterion (20%) - calculate percentage of matching skills
      if (isEligible && job.requiredSkills && job.requiredSkills.length > 0) {
        if (userSkills.length === 0) {
          // User has no skills, but job requires skills
          matchDetails.skillsScore = 0;
          matchDetails.skillsMatchPercentage = 0;
        } else {
          const matchingSkillsCount = job.requiredSkills.filter(skillId => 
            userSkillIds.includes(skillId)
          ).length;
          
          // Calculate the raw percentage of skills that match
          matchDetails.skillsMatchPercentage = (matchingSkillsCount / job.requiredSkills.length) * 100;
          
          // Calculate skill match score (max 20% of total score)
          matchDetails.skillsScore = (matchingSkillsCount / job.requiredSkills.length) * 20;
        }
      }
      
      // Calculate overall score
      matchDetails.overallScore = matchDetails.roleScore + matchDetails.availabilityScore + matchDetails.skillsScore;
      
      // Only include jobs that are eligible matches
      if (isEligible && matchDetails.overallScore > 0) {
        // Add the match score details to the job
        job.matchScore = matchDetails;
        jobMatches.push({ job, score: matchDetails.overallScore });
      }
    }
    
    // Sort by score (highest first) and return just the jobs
    return jobMatches.sort((a, b) => b.score - a.score).map(match => match.job);
  }

  async findMatchingWorkersForJob(jobId: number): Promise<User[]> {
    const job = await this.getJob(jobId);
    if (!job) return [];
    
    // Get all users except the job creator
    const allUsers = await this.getAllUsers();
    const filteredUsers = allUsers.filter(user => user.id !== job.employerId);
    
    // Import job role similarity function
    const { calculateRoleMatchScore } = await import('../shared/job-role-utils');
    
    // Array to store matches with scores
    const userMatches: { user: User; score: number }[] = [];
    
    // Only match with users who aren't the job creator
    for (const user of filteredUsers) {
      // Get user skills, availability, and job roles
      const userSkills = await this.getUserSkills(user.id);
      const userAvailability = await this.getUserAvailability(user.id);
      const userJobRoles = await this.getUserJobRoles(user.id);
      
      // Extract job role IDs from user's job roles
      const userJobRoleIds = userJobRoles.map(userRole => userRole.jobRoleId);
      
      // For backward compatibility, also check the legacy job role field
      if (user.jobRoleId && !userJobRoleIds.includes(user.jobRoleId)) {
        userJobRoleIds.push(user.jobRoleId);
      }
      
      const userSkillIds = userSkills.map(skill => skill.id);
      
      // Initialize match details
      const matchDetails: JobMatchScore = {
        overallScore: 0,
        roleScore: 0,
        availabilityScore: 0,
        skillsScore: 0,
        skillsMatchPercentage: 0
      };
      
      let isEligible = true;
      
      // 1. Job Role is the primary matching criterion (50%)
      if (job.jobRoleId && userJobRoleIds.length > 0) {
        // Find the best role match score from all user roles
        let bestRoleScore = 0;
        
        for (const userRoleId of userJobRoleIds) {
          const currentRoleScore = calculateRoleMatchScore(job.jobRoleId, userRoleId);
          if (currentRoleScore > bestRoleScore) {
            bestRoleScore = currentRoleScore;
          }
        }
        
        matchDetails.roleScore = bestRoleScore;
        
        // If no roles match or aren't similar, this is not a match
        if (matchDetails.roleScore === 0) {
          isEligible = false;
        }
      }
      
      // 2. Check time availability (30%) - if job has required availability
      if (isEligible && job.requiredAvailability && job.requiredAvailability.length > 0) {
        if (userAvailability.length === 0) {
          // User hasn't specified availability, but job requires it
          isEligible = false;
        } else {
          // Check if any user availability overlaps with job required availability
          const hasTimeMatch = job.requiredAvailability.some(jobSlot => {
            return userAvailability.some(userSlot => {
              // Check if days match
              if (userSlot.dayOfWeek !== jobSlot.dayOfWeek) return false;
              
              // Check overlap in hours
              const userStart = userSlot.startHour;
              const userEnd = userSlot.endHour;
              const jobStart = jobSlot.startHour;
              const jobEnd = jobSlot.endHour;
              
              // Hours overlap if user's start time is before job's end time 
              // AND user's end time is after job's start time
              return userStart < jobEnd && userEnd > jobStart;
            });
          });
          
          if (hasTimeMatch) {
            matchDetails.availabilityScore = 30; // 30% of the score is time availability match
          } else {
            // Availability is required and doesn't match - this is not a match
            isEligible = false;
          }
        }
      }
      
      // 3. Skill matching as the third criterion (20%) - calculate percentage of matching skills
      if (isEligible && job.requiredSkills && job.requiredSkills.length > 0) {
        if (userSkills.length === 0) {
          // User has no skills, but job requires skills
          matchDetails.skillsScore = 0;
          matchDetails.skillsMatchPercentage = 0;
        } else {
          const matchingSkillsCount = job.requiredSkills.filter(skillId => 
            userSkillIds.includes(skillId)
          ).length;
          
          // Calculate the raw percentage of skills that match
          matchDetails.skillsMatchPercentage = (matchingSkillsCount / job.requiredSkills.length) * 100;
          
          // Calculate skill match score (max 20% of total score)
          matchDetails.skillsScore = (matchingSkillsCount / job.requiredSkills.length) * 20;
        }
      }
      
      // Calculate overall score
      matchDetails.overallScore = matchDetails.roleScore + matchDetails.availabilityScore + matchDetails.skillsScore;
      
      // Only include users that are eligible matches
      if (isEligible && matchDetails.overallScore > 0) {
        userMatches.push({ user, score: matchDetails.overallScore });
      }
    }
    
    // Sort by score (highest first) and return just the users
    return userMatches.sort((a, b) => b.score - a.score).map(match => match.user);
  }

  // Subscription plans
  async getSubscriptionPlan(id: number): Promise<SubscriptionPlan | undefined> {
    return this.subscriptionPlans.get(id);
  }

  async getAllSubscriptionPlans(): Promise<SubscriptionPlan[]> {
    return Array.from(this.subscriptionPlans.values());
  }

  async createSubscriptionPlan(planData: InsertSubscriptionPlan): Promise<SubscriptionPlan> {
    const id = this.subscriptionPlanId++;
    const plan: SubscriptionPlan = { 
      ...planData, 
      id,
      isUnlimited: planData.isUnlimited || false 
    };
    this.subscriptionPlans.set(id, plan);
    return plan;
  }

  // User subscriptions
  async getUserSubscription(userId: number): Promise<UserSubscription | undefined> {
    return Array.from(this.userSubscriptions.values()).find(
      (subscription) => subscription.userId === userId && subscription.isActive
    );
  }

  async createUserSubscription(subscriptionData: InsertUserSubscription): Promise<UserSubscription> {
    const id = this.userSubscriptionId++;
    const subscription: UserSubscription = { 
      ...subscriptionData, 
      id,
      startDate: subscriptionData.startDate || new Date(),
      isActive: subscriptionData.isActive !== undefined ? subscriptionData.isActive : true,
      searchesUsed: subscriptionData.searchesUsed || 0,
      applicantViewsUsed: subscriptionData.applicantViewsUsed || 0
    };
    this.userSubscriptions.set(id, subscription);
    return subscription;
  }

  async updateUserSubscription(id: number, data: Partial<UserSubscription>): Promise<UserSubscription | undefined> {
    const subscription = this.userSubscriptions.get(id);
    if (!subscription) return undefined;
    
    const updatedSubscription = { ...subscription, ...data };
    this.userSubscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }

  async incrementSearchCount(userId: number): Promise<UserSubscription | undefined> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return undefined;
    
    const updatedSubscription = { ...subscription, searchesUsed: subscription.searchesUsed + 1 };
    this.userSubscriptions.set(subscription.id, updatedSubscription);
    return updatedSubscription;
  }

  async incrementApplicantViewCount(userId: number): Promise<UserSubscription | undefined> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return undefined;
    
    const updatedSubscription = { ...subscription, applicantViewsUsed: subscription.applicantViewsUsed + 1 };
    this.userSubscriptions.set(subscription.id, updatedSubscription);
    return updatedSubscription;
  }

  async checkSubscriptionForApplicantView(userId: number, jobId?: number): Promise<boolean> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return false;
    
    const plan = await this.getSubscriptionPlan(subscription.planId);
    if (!plan) return false;
    
    // Simple check for total number of uses
    const basicCheck = plan.isUnlimited || subscription.applicantViewsUsed < plan.maxApplicantViews;
    if (!basicCheck) return false;
    
    // For single job subscriptions, check if this is the specific job
    if (subscription.jobId !== null && subscription.jobId !== undefined) {
      // If this is a single-job subscription, verify it's for this job
      return jobId !== undefined && subscription.jobId === jobId;
    }
    
    // For regular subscriptions, the basic check is enough
    return true;
  }

  async checkSubscriptionForSearch(userId: number): Promise<boolean> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return false;
    
    const plan = await this.getSubscriptionPlan(subscription.planId);
    if (!plan) return false;
    
    // Only Recruiter plan allows searching
    if (plan.name !== "Recruiter") return false;
    
    return plan.isUnlimited || subscription.searchesUsed < plan.maxSearches;
  }

  // Mock data initialization
  private async initializeMockData() {
    // Create sample job roles
    for (let i = 1; i <= 20; i++) {
      const category = i <= 10 ? "Development" : "Design";
      await this.createJobRole({
        name: `Job Role ${i}`,
        category
      });
    }
    
    // Create sample skills
    for (let i = 1; i <= 40; i++) {
      await this.createSkill({
        name: `Skill ${i}`,
        category: i <= 20 ? "Technical" : "Soft"
      });
    }
  }
}

// Export the DatabaseStorage class and storage instance
export const storage = new DatabaseStorage();