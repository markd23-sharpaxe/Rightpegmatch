import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { ZodError, z } from "zod";
import Stripe from "stripe";
import { db } from "./db";
import { users, messages } from "@shared/schema";
import * as anthropicService from "./services/anthropic";
import { eq, or, desc, and } from "drizzle-orm";
import multer from "multer";
import path from "path";
import fs from "fs";
import crypto from "crypto";

import { 
  insertJobSchema, 
  insertUserSkillSchema, 
  insertAvailabilitySlotSchema,
  insertJobApplicationSchema,
  insertMessageSchema
} from "@shared/schema";

// Initialize Stripe
if (!process.env.STRIPE_SECRET_KEY) {
  console.warn("STRIPE_SECRET_KEY not set. Stripe payments will not work.");
}

// Check for Anthropic API key
if (!process.env.ANTHROPIC_API_KEY) {
  console.warn("ANTHROPIC_API_KEY not set. AI features will not work.");
}

// Configure Stripe with the production API key in live mode
const stripe = process.env.STRIPE_SECRET_KEY 
  ? new Stripe(process.env.STRIPE_SECRET_KEY, {
      // In production mode (not test mode)
      appInfo: {
        name: 'RightPegMatch',
        version: '1.0.0',
      }
    })
  : null;

// Format Zod validation errors
function formatError(error: ZodError) {
  const formatted = error.format();
  const issues = error.issues.map(issue => {
    return {
      path: issue.path.join('.'),
      message: issue.message
    };
  });
  
  return {
    message: issues.map(i => `${i.path}: ${i.message}`).join(', '),
    errors: issues
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Enhanced HTTPS redirect middleware for production with improved forwarding support
  app.use((req, res, next) => {
    // Get the original hostname if it's being forwarded (for GoDaddy forwarding)
    const originalHost = req.get('x-forwarded-host') || req.hostname;
    const forwardedProto = req.get('x-forwarded-proto');
    
    // Debug logging for troubleshooting all requests
    console.log(`Request: ${originalHost}, protocol: ${forwardedProto || req.protocol}, secure: ${req.secure}`);
    
    // Check for domain names we care about
    const isDomainOfInterest = originalHost === 'rightpegmatch.com' || 
                                originalHost === 'www.rightpegmatch.com';
    
    // Only redirect if we're not already on HTTPS
    // Improved condition: check both req.secure and forwardedProto
    const isInsecureRequest = !req.secure && forwardedProto !== 'https';
    
    if (isDomainOfInterest && isInsecureRequest) {
      console.log(`Redirecting ${originalHost} from ${forwardedProto || 'http'} to HTTPS`);
      // Use 301 (permanent) redirect to ensure browsers cache the redirect
      return res.redirect(301, 'https://' + originalHost + req.url);
    }
    
    next();
  });
  
  // Setup authentication routes
  setupAuth(app);
  
  // Configure upload directory for multer
  const uploadDir = path.join(process.cwd(), 'public/uploads/images');
  
  // Create the upload directory if it doesn't exist
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
  
  // Configure multer for file uploads
  const uploadStorage = multer.diskStorage({
    destination: (req, file, cb) => {
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      // Generate a unique filename with original extension
      const uniquePrefix = crypto.randomBytes(8).toString('hex');
      const fileExt = path.extname(file.originalname);
      cb(null, `${uniquePrefix}-${Date.now()}${fileExt}`);
    }
  });
  
  // File filter to only allow image files
  const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(null, false);
    }
  };
  
  const upload = multer({ 
    storage: uploadStorage,
    fileFilter,
    limits: {
      fileSize: 5 * 1024 * 1024, // 5MB limit
    }
  });
  
  // Image upload endpoint
  app.post('/api/upload-image', upload.single('image'), (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: 'Unauthorized' });
    }
    
    if (!req.file) {
      return res.status(400).json({ message: 'No image file provided' });
    }
    
    try {
      // Generate the URL for the uploaded image
      const baseUrl = `${req.protocol}://${req.get('host')}`;
      const imageUrl = `${baseUrl}/uploads/images/${req.file.filename}`;
      
      // Return the URL to the client
      return res.json({ imageUrl });
    } catch (error) {
      console.error('Error processing uploaded image:', error);
      return res.status(500).json({ message: 'Failed to process uploaded image' });
    }
  });
  
  // Serve static files from public directory
  app.use('/uploads', express.static(path.join(process.cwd(), 'public/uploads')));
  
  // Serve assets like logo from public directory
  app.use('/assets', express.static(path.join(process.cwd(), 'public/assets')));
  
  // Add PATCH endpoint for updating user profile
  app.patch("/api/user", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const userId = req.user!.id;
      const updatedUser = await storage.updateUser(userId, req.body);
      
      // Update session user data
      if (req.user) {
        req.user = { ...req.user, ...updatedUser };
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // Create subscription plans if none exist
  const initializeSubscriptionPlans = async () => {
    try {
      const existingPlans = await storage.getAllSubscriptionPlans();
      
      if (existingPlans.length === 0) {
        console.log("Creating default subscription plans...");
        
        // Single job plan - Level 1
        await storage.createSubscriptionPlan({
          name: "Single Job", 
          description: "Access applications for one specific job posting (one-time fee)",
          price: "9.99",
          maxSearches: 0,
          maxApplicantViews: 1000, // Unlimited for that specific job
          isUnlimited: false
        });
        
        // All jobs plan - Level 2
        await storage.createSubscriptionPlan({
          name: "All Jobs", 
          description: "Access applications for all your job postings (monthly fee)",
          price: "29.99",
          maxSearches: 0,
          maxApplicantViews: 1000, // Unlimited for all jobs
          isUnlimited: false
        });
        
        // Recruiter plan - Level 3
        await storage.createSubscriptionPlan({
          name: "Recruiter",
          description: "Full access to search for candidates proactively (monthly fee)",
          price: "199.00",
          maxSearches: 1000, // Essentially unlimited
          maxApplicantViews: 1000, // Unlimited
          isUnlimited: true
        });
        
        console.log("Default subscription plans created successfully");
      } else {
        console.log(`${existingPlans.length} subscription plan(s) already exist`);
      }
    } catch (error) {
      console.error("Failed to initialize subscription plans:", error);
    }
  };
  
  // Initialize subscription plans
  await initializeSubscriptionPlans();
  
  // Debug route to check our storage
  app.get("/api/debug/jobs", async (req, res) => {
    try {
      const allJobs = await storage.getAllJobs();
      res.json({ 
        totalJobs: allJobs.length,
        activeJobs: allJobs.length,
        sample: allJobs.slice(0, 2)
      });
    } catch (error) {
      console.error("Debug error:", error);
      res.status(500).json({ message: "Error in debug route", error: String(error) });
    }
  });
  
  // Enhanced SSL check route to help troubleshoot SSL issues
  app.get("/api/debug/ssl", (req, res) => {
    // Send detailed protocol and security information
    res.json({
      secure: req.secure,
      protocol: req.protocol,
      hostname: req.hostname,
      originalUrl: req.originalUrl,
      isForwarded: !!req.headers['x-forwarded-host'],
      headers: {
        host: req.headers.host,
        forwardedProto: req.headers['x-forwarded-proto'],
        forwardedHost: req.headers['x-forwarded-host'],
        forwardedFor: req.headers['x-forwarded-for'],
        userAgent: req.headers['user-agent'],
        referrer: req.headers['referer'],
        cookie: !!req.headers['cookie'] // Just show if cookies exist, not the actual values
      },
      isGoDaddyForwarding: (
        req.headers['user-agent']?.includes('GoDaddy') || 
        req.headers['referer']?.includes('godaddy.com')
      ),
      // Added information about connection
      connectionInfo: {
        socketSecure: req.socket?.encrypted || false,
        remoteAddress: req.socket?.remoteAddress || 'unknown',
        localAddress: req.socket?.localAddress || 'unknown',
        tls: req.socket?.getPeerCertificate ? 'supported' : 'not available'
      },
      // Added diagnostic message based on request details
      diagnostic: getConnectionDiagnostic(req)
    });
  });
  
  // Helper function to generate diagnostic messages for SSL issues
  function getConnectionDiagnostic(req: express.Request): string {
    if (req.secure) {
      return "Connection is secure with HTTPS.";
    }
    
    if (req.headers['x-forwarded-proto'] === 'https') {
      return "Connection appears to be secure via proxy (x-forwarded-proto: https).";
    }
    
    const host = req.headers.host || req.hostname;
    if (host?.includes('rightpegmatch.com')) {
      return "WARNING: Accessing rightpegmatch.com over insecure HTTP connection. SSL certificate may be missing or invalid.";
    }
    
    if (host?.includes('replit.app')) {
      return "Accessing via Replit's domain. This should be secure by default. Check browser for certificate warnings.";
    }
    
    return "Connection is not secure. For production use, please ensure SSL is properly configured.";
  }
  
  // All routes should be prefixed with /api
  
  // Languages data and search endpoints
  app.get("/api/languages", (req, res) => {
    // Common languages with ISO codes
    const languages = [
      { code: "en", name: "English" },
      { code: "es", name: "Spanish" },
      { code: "fr", name: "French" },
      { code: "de", name: "German" },
      { code: "it", name: "Italian" },
      { code: "pt", name: "Portuguese" },
      { code: "ru", name: "Russian" },
      { code: "zh", name: "Chinese" },
      { code: "ja", name: "Japanese" },
      { code: "ar", name: "Arabic" },
      { code: "hi", name: "Hindi" },
      { code: "bn", name: "Bengali" },
      { code: "ko", name: "Korean" },
      { code: "tr", name: "Turkish" },
      { code: "nl", name: "Dutch" },
      { code: "sv", name: "Swedish" },
      { code: "pl", name: "Polish" },
      { code: "vi", name: "Vietnamese" },
      { code: "th", name: "Thai" },
      { code: "el", name: "Greek" },
    ];
    res.json(languages);
  });
  
  // Search languages endpoint - for autocomplete
  app.get("/api/search/languages", (req, res) => {
    console.time('search-languages');
    const query = (req.query.q as string || "").toLowerCase().trim();
    
    // Common languages with ISO codes
    const languages = [
      { code: "en", name: "English" },
      { code: "es", name: "Spanish" },
      { code: "fr", name: "French" },
      { code: "de", name: "German" },
      { code: "it", name: "Italian" },
      { code: "pt", name: "Portuguese" },
      { code: "ru", name: "Russian" },
      { code: "zh", name: "Chinese" },
      { code: "ja", name: "Japanese" },
      { code: "ar", name: "Arabic" },
      { code: "hi", name: "Hindi" },
      { code: "bn", name: "Bengali" },
      { code: "ko", name: "Korean" },
      { code: "tr", name: "Turkish" },
      { code: "nl", name: "Dutch" },
      { code: "sv", name: "Swedish" },
      { code: "pl", name: "Polish" },
      { code: "vi", name: "Vietnamese" },
      { code: "th", name: "Thai" },
      { code: "el", name: "Greek" },
    ];
    
    // If no query, return all languages 
    if (!query) {
      console.timeEnd('search-languages');
      return res.json(languages);
    }
    
    // Filter languages that match the query
    const filtered = languages.filter(lang => 
      lang.name.toLowerCase().includes(query)
    );
    
    console.timeEnd('search-languages');
    res.json(filtered);
  });
  
  // Job Roles routes
  app.get("/api/job-roles", async (req, res) => {
    try {
      const jobRoles = await storage.getAllJobRoles();
      res.json(jobRoles);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job roles" });
    }
  });
  
  // Search job roles endpoint - for autocomplete
  app.get("/api/search/job-roles", async (req, res) => {
    console.time('search-job-roles');
    try {
      const query = (req.query.q as string || "").toLowerCase().trim();
      
      // If no query, return all job roles (limit to 20)
      if (!query) {
        const allRoles = await storage.getAllJobRoles();
        console.timeEnd('search-job-roles');
        return res.json(allRoles.slice(0, 20));
      }
      
      // Get all roles and filter in memory (faster than DB query for small datasets)
      const allRoles = await storage.getAllJobRoles();
      const filtered = allRoles.filter(role => 
        role.name.toLowerCase().includes(query)
      );
      
      console.timeEnd('search-job-roles');
      res.json(filtered.slice(0, 10)); // Limit to 10 results for better UI
    } catch (error) {
      console.error("Error searching job roles:", error);
      console.timeEnd('search-job-roles');
      res.status(500).json({ error: "Failed to search job roles" });
    }
  });
  
  // Skills routes
  app.get("/api/skills", async (req, res) => {
    try {
      const skills = await storage.getAllSkills();
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch skills" });
    }
  });
  
  // Create a new skill (used for on-the-fly creation during job posting)
  app.post("/api/skills", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { name } = req.body;
      if (!name) {
        return res.status(400).json({ message: "Skill name is required" });
      }
      
      // Check if skill already exists
      const existingSkill = await storage.getSkillByName(name);
      if (existingSkill) {
        return res.json(existingSkill);
      }
      
      const newSkill = await storage.createSkill({
        name,
        category: "Other"
      });
      
      res.status(201).json(newSkill);
    } catch (error) {
      console.error('Error creating skill:', error);
      res.status(500).json({ message: "Failed to create skill" });
    }
  });
  
  // Search skills endpoint - for autocomplete
  app.get("/api/search/skills", async (req, res) => {
    console.time('search-skills');
    try {
      const query = (req.query.q as string || "").toLowerCase().trim();
      
      // If no query, return all skills (limit to 20)
      if (!query) {
        const allSkills = await storage.getAllSkills();
        console.timeEnd('search-skills');
        return res.json(allSkills.slice(0, 20));
      }
      
      // Get all skills and filter in memory (faster than DB query for small datasets)
      const allSkills = await storage.getAllSkills();
      const filtered = allSkills.filter(skill => 
        skill.name.toLowerCase().includes(query)
      ).sort((a, b) => {
        // Sort by exact match first, then by name
        const aExact = a.name.toLowerCase() === query.toLowerCase();
        const bExact = b.name.toLowerCase() === query.toLowerCase();
        
        if (aExact && !bExact) return -1;
        if (!aExact && bExact) return 1;
        
        // Then prioritize matches at the start of the string
        const aStartsWith = a.name.toLowerCase().startsWith(query.toLowerCase());
        const bStartsWith = b.name.toLowerCase().startsWith(query.toLowerCase());
        
        if (aStartsWith && !bStartsWith) return -1;
        if (!aStartsWith && bStartsWith) return 1;
        
        // Then sort alphabetically
        return a.name.localeCompare(b.name);
      });
      
      // Limit to first 10 results for better UI
      const results = filtered.slice(0, 10);
      
      console.timeEnd('search-skills');
      res.json(results);
    } catch (error) {
      console.error("Error searching skills:", error);
      console.timeEnd('search-skills');
      res.status(500).json({ error: "Failed to search skills" });
    }
  });
  
  // Get user qualifications
  app.get("/api/user/qualifications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      console.log("[DEBUG] Fetching qualifications for user:", req.user!.id);
      const qualifications = await storage.getUserQualifications(req.user!.id);
      console.log("[DEBUG] User qualifications found:", qualifications);
      res.json(qualifications);
    } catch (error) {
      console.error("Error fetching user qualifications:", error);
      res.status(500).json({ error: "Failed to fetch user qualifications" });
    }
  });
  
  // Delete user qualification
  app.delete("/api/user/qualifications/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const qualificationId = parseInt(req.params.id);
      await storage.removeUserQualification(req.user!.id, qualificationId);
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing user qualification:", error);
      res.status(500).json({ error: "Failed to remove user qualification" });
    }
  });
  
  // Add a qualification to user profile
  app.post("/api/user/qualifications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      console.log("[DEBUG] POST to /api/user/qualifications with body:", req.body);
      const { qualificationId } = req.body;
      
      if (!qualificationId) {
        console.log("[DEBUG] Missing qualificationId in request");
        return res.status(400).json({ message: "Qualification ID is required" });
      }
      
      // Check if qualification exists
      console.log("[DEBUG] Looking up qualification with ID:", qualificationId);
      const qualification = await storage.getQualification(qualificationId);
      console.log("[DEBUG] Found qualification:", qualification);
      
      if (!qualification) {
        console.log("[DEBUG] Qualification not found with ID:", qualificationId);
        return res.status(404).json({ message: "Qualification not found" });
      }
      
      // Check if user already has this qualification
      console.log("[DEBUG] Checking if user already has this qualification");
      const userQualifications = await storage.getUserQualifications(req.user!.id);
      const hasQualification = userQualifications.some(q => q.id === qualificationId);
      console.log("[DEBUG] User has qualification already:", hasQualification);
      
      // Add qualification to user profile if not already added
      if (!hasQualification) {
        console.log("[DEBUG] Adding qualification to user profile");
        await storage.addUserQualification({
          userId: req.user!.id,
          qualificationId
        });
        console.log("[DEBUG] Successfully added qualification to user profile");
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error adding qualification to user:", error);
      res.status(500).json({ error: "Failed to add qualification to user" });
    }
  });
  
  // Update user qualifications
  app.patch("/api/user/qualifications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { qualifications } = req.body;
      
      if (!Array.isArray(qualifications)) {
        return res.status(400).json({ message: "Qualifications must be an array" });
      }
      
      // Process each qualification
      for (const qualificationName of qualifications) {
        let qualification = await storage.getQualificationByName(qualificationName);
        
        // Create qualification if it doesn't exist
        if (!qualification) {
          qualification = await storage.createQualification({ name: qualificationName });
        }
        
        // Check if user already has this qualification
        const userQualifications = await storage.getUserQualifications(req.user!.id);
        const hasQualification = userQualifications.some(q => q.id === qualification.id);
        
        // Add qualification to user profile if not already added
        if (!hasQualification) {
          await storage.addUserQualification({
            userId: req.user!.id,
            qualificationId: qualification.id
          });
        }
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating user qualifications:", error);
      res.status(500).json({ error: "Failed to update user qualifications" });
    }
  });
  
  // Search qualifications endpoint - for autocomplete
  app.get("/api/search/qualifications", async (req, res) => {
    console.time('search-qualifications');
    try {
      const query = (req.query.q as string || "").toLowerCase().trim();
      
      // If no query, return all qualifications (limit to 20)
      if (!query) {
        const allQualifications = await storage.getAllQualifications();
        console.timeEnd('search-qualifications');
        return res.json(allQualifications.slice(0, 20));
      }
      
      // Get all qualifications and filter in memory (faster than DB query for small datasets)
      const allQualifications = await storage.getAllQualifications();
      const filtered = allQualifications.filter(qualification => 
        qualification.name.toLowerCase().includes(query)
      ).sort((a, b) => {
        // Sort by exact match first, then by name
        const aExact = a.name.toLowerCase() === query.toLowerCase();
        const bExact = b.name.toLowerCase() === query.toLowerCase();
        
        if (aExact && !bExact) return -1;
        if (!aExact && bExact) return 1;
        
        // Then prioritize matches at the start of the string
        const aStartsWith = a.name.toLowerCase().startsWith(query.toLowerCase());
        const bStartsWith = b.name.toLowerCase().startsWith(query.toLowerCase());
        
        if (aStartsWith && !bStartsWith) return -1;
        if (!aStartsWith && bStartsWith) return 1;
        
        // Then sort alphabetically
        return a.name.localeCompare(b.name);
      });
      
      // Limit to first 10 results for better UI
      const results = filtered.slice(0, 10);
      
      // Check if an exact match exists
      const exactMatch = filtered.some(q => 
        q.name.toLowerCase() === query.toLowerCase()
      );
      
      // If no exact match and query is not empty, add option to create new
      if (!exactMatch && query.trim()) {
        results.push({
          id: -1,
          name: `Create new: ${query}`,
          isNew: true,
          newValue: query
        } as any);
      }
      
      console.timeEnd('search-qualifications');
      res.json(results);
    } catch (error) {
      console.error("Error searching qualifications:", error);
      console.timeEnd('search-qualifications');
      res.status(500).json({ error: "Failed to search qualifications" });
    }
  });
  
  // Create a new qualification and optionally add it to user profile
  app.post("/api/qualifications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { name, addToProfile } = req.body;
      
      if (!name) {
        return res.status(400).json({ message: "Qualification name is required" });
      }
      
      // Check if qualification already exists
      const existingQualification = await storage.getQualificationByName(name);
      
      // If qualification exists, we can still add it to the user's profile
      if (existingQualification) {
        if (addToProfile) {
          // Check if user already has this qualification
          const userQualifications = await storage.getUserQualifications(req.user!.id);
          const hasQualification = userQualifications.some(q => q.id === existingQualification.id);
          
          if (!hasQualification) {
            await storage.addUserQualification({
              userId: req.user!.id,
              qualificationId: existingQualification.id
            });
          }
        }
        return res.json(existingQualification);
      }
      
      // Create new qualification
      const newQualification = await storage.createQualification({ name });
      
      // Add to user's profile if requested
      if (addToProfile) {
        await storage.addUserQualification({
          userId: req.user!.id,
          qualificationId: newQualification.id
        });
      }
      
      res.status(201).json(newQualification);
    } catch (error) {
      console.error("Error creating qualification:", error);
      res.status(500).json({ message: "Failed to create qualification" });
    }
  });
  
  // Create a new skill and optionally add it to user profile
  app.post("/api/skills", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const { name, addToProfile } = req.body;
      
      if (!name) {
        return res.status(400).json({ message: "Skill name is required" });
      }
      
      // Check if skill already exists
      const existingSkill = await storage.getSkillByName(name);
      
      // If skill exists, we can still add it to the user's profile
      if (existingSkill) {
        if (addToProfile) {
          // Check if user already has this skill
          const userSkills = await storage.getUserSkills(req.user!.id);
          const hasSkill = userSkills.some(skill => skill.id === existingSkill.id);
          
          if (!hasSkill) {
            await storage.addUserSkill({
              userId: req.user!.id,
              skillId: existingSkill.id
            });
          }
        }
        
        return res.json(existingSkill);
      }
      
      // Create the new skill
      const newSkill = await storage.createSkill({ name });
      
      // Add to user profile if requested
      if (addToProfile) {
        await storage.addUserSkill({
          userId: req.user!.id,
          skillId: newSkill.id
        });
      }
      
      res.status(201).json(newSkill);
    } catch (error) {
      console.error("Error creating skill:", error);
      res.status(500).json({ message: "Failed to create skill" });
    }
  });
  
  // Endpoint to get skill levels for radar chart
  app.get("/api/user/skill-levels", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Get the user's skills
      const userSkills = await storage.getUserSkills(req.user!.id);
      
      // For visualization purposes, generate a random proficiency value between 65-95
      // In a real app, this would come from a database field or assessment
      const skillLevels = userSkills.map(skill => ({
        ...skill,
        proficiency: Math.floor(65 + Math.random() * 30) // Random value from 65-95
      }));
      
      res.json(skillLevels);
    } catch (error) {
      console.error("Error fetching skill levels:", error);
      res.status(500).json({ message: "Failed to fetch skill levels" });
    }
  });
  
  // Get user skills endpoint
  app.get("/api/user/skills", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const skills = await storage.getUserSkills(req.user!.id);
      res.json(skills);
    } catch (error) {
      console.error("Error fetching user skills:", error);
      res.status(500).json({ message: "Failed to fetch user skills" });
    }
  });
  
  // Get user job roles endpoint
  app.get("/api/user/job-roles", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const jobRoles = await storage.getUserJobRoles(req.user!.id);
      res.json(jobRoles);
    } catch (error) {
      console.error("Error fetching user job roles:", error);
      res.status(500).json({ message: "Failed to fetch user job roles" });
    }
  });
  
  // Add user job role endpoint
  app.post("/api/profile/job-roles", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { jobRoleId, isPrimary = false, experienceLevel = null } = req.body;
      
      if (!jobRoleId) {
        return res.status(400).json({ message: "Job role ID is required" });
      }
      
      // Check if job role exists
      const jobRole = await storage.getJobRole(jobRoleId);
      if (!jobRole) {
        return res.status(404).json({ message: "Job role not found" });
      }
      
      // Check if this role is already added
      const userJobRoles = await storage.getUserJobRoles(req.user!.id);
      const alreadyAdded = userJobRoles.some(role => role.jobRoleId === jobRoleId);
      
      if (alreadyAdded) {
        return res.status(400).json({ message: "This job role is already added to your profile" });
      }
      
      // Add the job role
      const userJobRole = await storage.addUserJobRole({
        userId: req.user!.id,
        jobRoleId,
        isPrimary,
        experienceLevel
      });
      
      // If this is set as primary, also update the user's primary job role ID
      if (isPrimary) {
        await storage.updateUser(req.user!.id, { jobRoleId });
      }
      
      res.status(201).json(userJobRole);
    } catch (error) {
      console.error("Error adding job role:", error);
      res.status(500).json({ message: "Failed to add job role" });
    }
  });
  
  // Remove user job role endpoint
  app.delete("/api/profile/job-roles/:jobRoleId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const jobRoleId = parseInt(req.params.jobRoleId);
      
      if (isNaN(jobRoleId)) {
        return res.status(400).json({ message: "Invalid job role ID" });
      }
      
      // Check if this is the primary role
      const user = req.user!;
      if (user.jobRoleId === jobRoleId) {
        return res.status(400).json({ 
          message: "Cannot remove primary job role. Please set another role as primary first." 
        });
      }
      
      await storage.removeUserJobRole(user.id, jobRoleId);
      res.status(200).json({ success: true });
    } catch (error) {
      console.error("Error removing job role:", error);
      res.status(500).json({ message: "Failed to remove job role" });
    }
  });
  
  // Set primary job role endpoint
  app.patch("/api/profile/job-roles/:jobRoleId/primary", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const jobRoleId = parseInt(req.params.jobRoleId);
      const { experienceLevel = null } = req.body;
      
      if (isNaN(jobRoleId)) {
        return res.status(400).json({ message: "Invalid job role ID" });
      }
      
      // Check if job role exists and is associated with user
      const userJobRoles = await storage.getUserJobRoles(req.user!.id);
      const hasRole = userJobRoles.some(role => role.jobRoleId === jobRoleId);
      
      if (!hasRole) {
        return res.status(404).json({ message: "Job role not found in your profile" });
      }
      
      // Set as primary in user job roles
      const updatedRole = await storage.setPrimaryUserJobRole(req.user!.id, jobRoleId, experienceLevel);
      
      // Also update the user's primary job role ID
      await storage.updateUser(req.user!.id, { jobRoleId });
      
      res.json(updatedRole);
    } catch (error) {
      console.error("Error setting primary job role:", error);
      res.status(500).json({ message: "Failed to set primary job role" });
    }
  });
  
  // Update job role experience endpoint (for non-primary roles)
  app.patch("/api/profile/job-roles/:jobRoleId/experience", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const jobRoleId = parseInt(req.params.jobRoleId);
      const { experienceLevel = null } = req.body;
      
      if (isNaN(jobRoleId)) {
        return res.status(400).json({ message: "Invalid job role ID" });
      }
      
      // Check if job role exists and is associated with user
      const userJobRoles = await storage.getUserJobRoles(req.user!.id);
      const hasRole = userJobRoles.some(role => role.jobRoleId === jobRoleId);
      
      if (!hasRole) {
        return res.status(404).json({ message: "Job role not found in your profile" });
      }
      
      // Update the experience level
      const updatedRole = await storage.updateUserJobRoleExperience(req.user!.id, jobRoleId, experienceLevel);
      
      res.json(updatedRole);
    } catch (error) {
      console.error("Error updating job role experience:", error);
      res.status(500).json({ message: "Failed to update job role experience" });
    }
  });
  
  // Get all job roles endpoint
  app.get("/api/job-roles", async (req, res) => {
    try {
      const jobRoles = await storage.getAllJobRoles();
      res.json(jobRoles);
    } catch (error) {
      console.error("Error fetching job roles:", error);
      res.status(500).json({ message: "Failed to fetch job roles" });
    }
  });
  
  // Get a specific job role by ID
  app.get("/api/job-roles/:id", async (req, res) => {
    try {
      const roleId = parseInt(req.params.id);
      if (isNaN(roleId)) {
        return res.status(400).json({ message: "Invalid job role ID" });
      }
      
      const jobRole = await storage.getJobRole(roleId);
      if (!jobRole) {
        return res.status(404).json({ message: "Job role not found" });
      }
      
      res.json(jobRole);
    } catch (error) {
      console.error("Error fetching job role:", error);
      res.status(500).json({ message: "Failed to fetch job role" });
    }
  });
  
  // Create a new job role
  app.post("/api/job-roles", async (req, res) => {
    try {
      const { name, category } = req.body;
      
      console.log("Creating job role with data:", { name, category });
      
      if (!name || typeof name !== 'string' || name.trim() === '') {
        return res.status(400).json({ message: "Job role name is required" });
      }
      
      // Check if a job role with this name already exists
      const existingRole = await storage.getJobRoleByName(name);
      if (existingRole) {
        console.log("Job role already exists:", existingRole);
        return res.json(existingRole);
      }
      
      // Create the new job role
      const newRole = await storage.createJobRole({
        name,
        category: category || "Custom"
      });
      
      console.log("Created new job role:", newRole);
      
      res.status(201).json(newRole);
    } catch (error) {
      console.error("Error creating job role:", error);
      res.status(500).json({ message: "Failed to create job role" });
    }
  });

  // Job routes
  app.get("/api/jobs", async (req, res) => {
    try {
      const query = req.query.query as string || "";
      const filters = {
        jobType: req.query.jobType as string,
        minHours: req.query.minHours ? parseInt(req.query.minHours as string) : undefined,
        maxHours: req.query.maxHours ? parseInt(req.query.maxHours as string) : undefined,
        timeZoneOverlap: req.query.timeZoneOverlap as string,
      };
      const jobs = await storage.searchJobs(query, filters);
      res.json(jobs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  // Anonymous jobs route - limited data for public viewing
  app.get("/api/jobs/anonymous", async (req, res) => {
    try {
      // Get up to 10 recent jobs
      const allJobs = await storage.getAllJobs();
      
      // Sort by most recent and take only 10
      const recentJobs = allJobs
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 10);
      
      // Limit the information for anonymous users (remove sensitive details)
      const anonymizedJobs = recentJobs.map(job => ({
        id: job.id,
        title: job.title,
        companyName: job.companyName || "Company Name Hidden",
        location: job.location,
        jobType: job.jobType,
        description: job.description ? job.description.substring(0, 150) + "..." : "Description hidden until login",
        createdAt: job.createdAt,
      }));
      
      res.json(anonymizedJobs);
    } catch (error) {
      console.error("Error fetching anonymous jobs:", error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:id", async (req, res) => {
    try {
      const jobId = parseInt(req.params.id);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Get job role details if job has a jobRoleId
      let jobRole = null;
      if (job.jobRoleId) {
        jobRole = await storage.getJobRole(job.jobRoleId);
      }
      
      res.json({
        ...job,
        jobRole
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch job" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      console.log("Creating job with data:", JSON.stringify(req.body, null, 2));
      
      // Handle job role - either use the ID or create a new job role if jobRoleName is provided
      let title = "Job";
      let jobRoleId = req.body.jobRoleId;
      
      if (req.body.jobRoleName && !jobRoleId) {
        // Create new job role or get existing one
        const jobRoleData = {
          name: req.body.jobRoleName,
          jobFamily: "Other" // Default job family
        };
        
        // Check if job role already exists
        const existingRole = await storage.getJobRoleByName(req.body.jobRoleName);
        if (existingRole) {
          jobRoleId = existingRole.id;
          title = existingRole.name;
        } else {
          // Create new job role
          const newJobRole = await storage.createJobRole(jobRoleData);
          jobRoleId = newJobRole.id;
          title = newJobRole.name;
        }
      } else if (jobRoleId) {
        // Get the job role details if only ID was provided
        const jobRole = await storage.getJobRole(jobRoleId);
        if (jobRole) {
          title = jobRole.name;
        }
      }
      
      // Handle skills - either use the IDs or create new skills if skills array is provided
      let requiredSkills = req.body.requiredSkills || [];
      if (req.body.skills && Array.isArray(req.body.skills)) {
        for (const skillName of req.body.skills) {
          // Check if skill already exists
          const existingSkill = await storage.getSkillByName(skillName);
          if (existingSkill) {
            if (!requiredSkills.includes(existingSkill.id)) {
              requiredSkills.push(existingSkill.id);
            }
          } else {
            // Create new skill
            const newSkill = await storage.createSkill({
              name: skillName,
              category: "Other"
            });
            requiredSkills.push(newSkill.id);
          }
        }
      }
      
      // Prepare the job data with the required fields
      const jobData = {
        ...req.body,
        title,
        jobRoleId,
        requiredSkills,
        employerId: req.user.id,
        description: req.body.description || "Join our global remote workforce with flexible hours and work arrangements that suit your lifestyle.",
        location: "Remote",
        jobType: req.body.jobType || "flexible", // Support different work arrangements
        salaryAmount: req.body.salaryAmount, // Store the actual amount entered by the user
        salaryType: req.body.salaryType || "hourly", // Store the salary type (hourly, weekly, monthly, yearly)
      };
      
      // Add validation for required fields
      if (!jobData.companyName) {
        return res.status(400).json({ message: "Company name is required" });
      }
      
      if (!jobData.jobRoleId) {
        return res.status(400).json({ message: "Job role is required" });
      }
      
      if (!jobData.hoursPerWeek) {
        return res.status(400).json({ message: "Hours per week is required" });
      }
      
      console.log("Before hourly rate calculation:", {
        hourlyRate: jobData.hourlyRate,
        salaryAmount: jobData.salaryAmount,
        salaryType: jobData.salaryType
      });
      
      // Directly set hourlyRate from salaryAmount if salaryType is hourly
      if (jobData.salaryType === 'hourly' && jobData.salaryAmount) {
        jobData.hourlyRate = jobData.salaryAmount;
        console.log("Set hourly rate directly from salary amount:", jobData.hourlyRate);
      }
      // Calculate hourly rate if not already set but salary amount and type are available
      else if (!jobData.hourlyRate && jobData.salaryAmount && jobData.salaryType) {
        const HOURS_PER_WEEK = 40;
        const WEEKS_PER_MONTH = 4.33;
        const MONTHS_PER_YEAR = 12;
        
        const numericAmount = parseFloat(jobData.salaryAmount);
        let calculatedHourlyRate: number;
        
        switch (jobData.salaryType) {
          case 'weekly':
            calculatedHourlyRate = numericAmount / HOURS_PER_WEEK;
            break;
          case 'monthly':
            calculatedHourlyRate = numericAmount / (HOURS_PER_WEEK * WEEKS_PER_MONTH);
            break;
          case 'yearly':
            calculatedHourlyRate = numericAmount / (HOURS_PER_WEEK * WEEKS_PER_MONTH * MONTHS_PER_YEAR);
            break;
          default:
            calculatedHourlyRate = numericAmount;
        }
        
        jobData.hourlyRate = calculatedHourlyRate.toFixed(2);
        console.log("Calculated hourly rate:", jobData.hourlyRate);
      }
      
      console.log("After hourly rate calculation:", {
        hourlyRate: jobData.hourlyRate,
        salaryAmount: jobData.salaryAmount,
        salaryType: jobData.salaryType
      });
      
      // After calculation, check if we have an hourly rate
      if (!jobData.hourlyRate) {
        return res.status(400).json({ message: "Hourly rate could not be calculated. Please provide salary information." });
      }
      
      if (!jobData.requiredAvailability || !Array.isArray(jobData.requiredAvailability) || jobData.requiredAvailability.length === 0) {
        return res.status(400).json({ message: "Required availability is missing or invalid" });
      }

      // Directly convert date strings to Date objects
      console.log("Before conversion - startDate:", jobData.startDate, typeof jobData.startDate);
      if (jobData.startDate && typeof jobData.startDate === 'string') {
        const date = new Date(jobData.startDate);
        console.log("Converting string to date:", jobData.startDate, "->", date);
        jobData.startDate = date;
      }
      console.log("After conversion - startDate:", jobData.startDate, typeof jobData.startDate);
      
      console.log("Before conversion - endDate:", jobData.endDate, typeof jobData.endDate);
      if (jobData.endDate && typeof jobData.endDate === 'string') {
        const date = new Date(jobData.endDate);
        console.log("Converting string to date:", jobData.endDate, "->", date);
        jobData.endDate = date;
      }
      console.log("After conversion - endDate:", jobData.endDate, typeof jobData.endDate);
      
      // Log the final job data before validation
      console.log("Final job data before validation:", JSON.stringify(jobData, null, 2));
      
      try {
        // Prepare a clean version of job data with proper types
        // This bypasses the schema validation which is causing issues with date handling
        const cleanJobData = {
          title: jobData.title,
          description: jobData.description,
          companyName: jobData.companyName,
          location: jobData.location || "Remote", 
          employerId: req.user.id,
          jobRoleId: jobData.jobRoleId ? parseInt(String(jobData.jobRoleId)) : null,
          requiredLanguages: jobData.requiredLanguages || "",
          salaryType: jobData.salaryType || "hourly",
          salaryAmount: jobData.salaryAmount ? String(jobData.salaryAmount) : null,
          currency: jobData.currency || "GBP",
          hourlyRate: jobData.hourlyRate ? String(jobData.hourlyRate) : null,
          hoursPerWeek: jobData.hoursPerWeek ? parseInt(String(jobData.hoursPerWeek)) : null,
          startDate: jobData.startDate ? new Date(jobData.startDate) : null,
          endDate: jobData.endDate ? new Date(jobData.endDate) : null,
          startDateFlexibility: jobData.startDateFlexibility || "exact",
          isPermanent: Boolean(jobData.isPermanent),
          requiredSkills: jobData.requiredSkills || [],
          requiredAvailability: jobData.requiredAvailability || [],
          jobType: jobData.jobType || "flexible",
          jobFamily: jobData.jobFamily || null,
          remote: true,
        };
        
        console.log("Clean job data ready for database:", {
          ...cleanJobData,
          // Log these separately since they don't stringify well
          startDate: cleanJobData.startDate?.toString(),
          endDate: cleanJobData.endDate?.toString()
        });
        
        // Create the job with our clean data object
        // This completely bypasses Zod validation issues
        const job = await storage.createJob(cleanJobData as any);
        console.log("Job created successfully:", job);
        res.status(201).json(job);
      } catch (validationError) {
        console.error("Validation error:", validationError);
        if (validationError instanceof ZodError) {
          return res.status(400).json({ 
            message: "Validation failed", 
            details: formatError(validationError).message,
            errors: validationError.errors
          });
        }
        throw validationError; // Re-throw if it's not a ZodError
      }
    } catch (error) {
      console.error("Error creating job:", error);
      if (error instanceof ZodError) {
        return res.status(400).json({ 
          message: "Validation failed", 
          details: formatError(error).message,
          errors: error.errors
        });
      }
      res.status(500).json({ 
        message: "Failed to create job", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  app.put("/api/jobs/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const jobId = parseInt(req.params.id);
      const job = await storage.getJob(jobId);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      if (job.employerId !== req.user!.id) {
        return res.status(403).json({ message: "You can only update your own jobs" });
      }
      
      // Not using the schema for partial updates
      const updatedJob = await storage.updateJob(jobId, req.body);
      res.json(updatedJob);
    } catch (error) {
      res.status(500).json({ message: "Failed to update job" });
    }
  });

  // Profile/User routes
  app.get("/api/profile", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Get user skills
      const skills = await storage.getUserSkills(req.user!.id);
      
      // Get user availability
      const availability = await storage.getUserAvailability(req.user!.id);
      
      // Get job role details if user has a jobRoleId
      let jobRole = null;
      if (req.user!.jobRoleId) {
        jobRole = await storage.getJobRole(req.user!.jobRoleId);
      }
      
      res.json({
        user: req.user,
        skills,
        availability,
        jobRole
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch profile" });
    }
  });

  app.put("/api/profile", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const userId = req.user!.id;
      const updatedUser = await storage.updateUser(userId, req.body);
      
      // Update session
      if (req.user) {
        req.user = { ...req.user, ...updatedUser };
      }
      
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: "Failed to update profile" });
    }
  });
  
  // PATCH endpoint for updating user (used by the job role selection component)
  app.patch("/api/user", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const userId = req.user!.id;
      console.log("Updating user with data:", req.body);
      const updatedUser = await storage.updateUser(userId, req.body);
      
      // Update session
      if (req.user) {
        req.user = { ...req.user, ...updatedUser };
      }
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  // User skills routes
  app.post("/api/profile/skills", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { skillId } = insertUserSkillSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      // Check if skill exists
      const skill = await storage.getSkill(skillId);
      if (!skill) {
        return res.status(404).json({ message: "Skill not found" });
      }
      
      // Add user skill
      await storage.addUserSkill({
        userId: req.user!.id,
        skillId
      });
      
      // Get updated skills
      const skills = await storage.getUserSkills(req.user!.id);
      res.json(skills);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: formatError(error).message });
      }
      res.status(500).json({ message: "Failed to add skill" });
    }
  });

  app.delete("/api/profile/skills/:skillId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const skillId = parseInt(req.params.skillId);
      
      // Remove user skill
      await storage.removeUserSkill(req.user!.id, skillId);
      
      // Get updated skills
      const skills = await storage.getUserSkills(req.user!.id);
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Failed to remove skill" });
    }
  });

  // Availability routes
  app.post("/api/profile/availability", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const slotData = insertAvailabilitySlotSchema.parse({
        ...req.body,
        userId: req.user!.id
      });
      
      // Add availability slot
      await storage.addAvailabilitySlot(slotData);
      
      // Get updated availability
      const availability = await storage.getUserAvailability(req.user!.id);
      res.json(availability);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: formatError(error).message });
      }
      res.status(500).json({ message: "Failed to add availability slot" });
    }
  });

  app.delete("/api/profile/availability/:slotId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const slotId = parseInt(req.params.slotId);
      
      // Remove availability slot
      await storage.removeAvailabilitySlot(slotId);
      
      // Get updated availability
      const availability = await storage.getUserAvailability(req.user!.id);
      res.json(availability);
    } catch (error) {
      res.status(500).json({ message: "Failed to remove availability slot" });
    }
  });
  
  // Get all availability slots for the current user
  app.get("/api/profile/availability", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const availability = await storage.getUserAvailability(req.user!.id);
      res.json(availability);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch availability slots" });
    }
  });
  
  // Route to delete all availability slots for the current user
  app.delete("/api/user/availability", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Get all user's availability slots
      const slots = await storage.getUserAvailability(req.user!.id);
      
      // Delete each slot
      for (const slot of slots) {
        await storage.removeAvailabilitySlot(slot.id);
      }
      
      res.json({ message: "All availability slots deleted" });
    } catch (error) {
      console.error("Error deleting availability slots:", error);
      res.status(500).json({ message: "Failed to clear availability slots" });
    }
  });

  // Job applications
  app.post("/api/jobs/:jobId/apply", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const jobId = parseInt(req.params.jobId);
      
      // Check if job exists
      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Prevent users from applying to their own jobs
      if (job.employerId === req.user!.id) {
        return res.status(403).json({ message: "You cannot apply to your own job posting" });
      }
      
      // Check if already applied
      const userApplications = await storage.getUserJobApplications(req.user!.id);
      const alreadyApplied = userApplications.some(app => app.jobId === jobId);
      
      if (alreadyApplied) {
        return res.status(400).json({ message: "You have already applied for this job" });
      }
      
      const applicationData = insertJobApplicationSchema.parse({
        jobId,
        jobseekerId: req.user!.id,
        message: req.body.message
      });
      
      const application = await storage.createJobApplication(applicationData);
      res.status(201).json(application);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: formatError(error).message });
      }
      res.status(500).json({ message: "Failed to apply for job" });
    }
  });

  app.get("/api/applications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Get applications the user has submitted
      const userApplications = await storage.getUserJobApplications(req.user!.id);
      
      // Get applications for jobs the user has created
      const employerJobs = await storage.getJobsByEmployer(req.user!.id);
      let receivedApplications: any[] = [];
      
      for (const job of employerJobs) {
        const jobApplications = await storage.getJobApplicationsForJob(job.id);
        receivedApplications = [...receivedApplications, ...jobApplications];
      }
      
      // Return both types of applications with a type indicator
      res.json({
        applied: userApplications,
        received: receivedApplications
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.put("/api/applications/:id/status", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const applicationId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!['pending', 'accepted', 'rejected'].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const application = await storage.getJobApplication(applicationId);
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Check if the employer owns the job
      const job = await storage.getJob(application.jobId);
      if (!job || job.employerId !== req.user!.id) {
        return res.status(403).json({ message: "You can only update applications for your own jobs" });
      }
      
      const updatedApplication = await storage.updateJobApplicationStatus(applicationId, status);
      res.json(updatedApplication);
    } catch (error) {
      res.status(500).json({ message: "Failed to update application status" });
    }
  });

  // Matching routes
  app.get("/api/matches/jobs", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Check if forced refresh is requested
      const forceRefresh = req.query.refresh === 'true';
      
      // Track start time to measure performance
      const startTime = Date.now();
      
      // Import the optimized matching algorithm
      const { findMatchingJobsForUser } = await import('./services/optimized-matching');
      
      // Use the optimized algorithm for better performance
      console.log("Using optimized matching algorithm");
      const matchingJobs = await findMatchingJobsForUser(req.user!.id, forceRefresh);
      
      // Calculate execution time
      const executionTime = Date.now() - startTime;
      
      // Send response with execution time
      res.json({
        matches: matchingJobs,
        matchCount: matchingJobs.length,
        executionTimeMs: executionTime,
        fromCache: false, // Always using real-time matching with optimization
        optimized: true // Flag to indicate optimized algorithm was used
      });
    } catch (error) {
      console.error("Error in /api/matches/jobs:", error);
      res.status(500).json({ message: "Failed to find matching jobs", error: error instanceof Error ? error.message : String(error) });
    }
  });
  
  // Endpoint to specifically refresh matches
  app.post("/api/matches/refresh", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Start timing
      const startTime = Date.now();
      
      // Import the optimized matching algorithm
      const { findMatchingJobsForUser } = await import('./services/optimized-matching');
      
      // Use the optimized algorithm for better performance
      console.log("Using optimized matching algorithm for match refresh");
      const matchingJobs = await findMatchingJobsForUser(req.user!.id, true);
      
      // Calculate execution time
      const executionTime = Date.now() - startTime;
      
      res.json({
        message: "Matches refreshed successfully",
        matchCount: matchingJobs.length,
        executionTimeMs: executionTime,
        optimized: true
      });
    } catch (error) {
      console.error("Error refreshing matches:", error);
      res.status(500).json({ message: "Failed to refresh matches", error: error instanceof Error ? error.message : String(error) });
    }
  });

  app.get("/api/matches/workers", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Check if user has the appropriate subscription level for searching
      const canSearch = await storage.checkSubscriptionForSearch(req.user!.id);
      if (!canSearch) {
        return res.status(403).json({ 
          message: "Subscription required", 
          detail: "The Recruiter subscription plan is required to search for candidates",
          code: "SUBSCRIPTION_REQUIRED"
        });
      }
      
      const jobId = parseInt(req.query.jobId as string);
      
      // Check if job exists and belongs to the employer
      const job = await storage.getJob(jobId);
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      if (job.employerId !== req.user!.id) {
        return res.status(403).json({ message: "You can only find matches for your own jobs" });
      }
      
      // Increment search count for analytics
      await storage.incrementSearchCount(req.user!.id);
      
      // Start timing
      const startTime = Date.now();
      
      // Import the optimized worker matching algorithm
      const { findMatchingWorkersForJob } = await import('./services/optimized-worker-matching');
      
      // Use the optimized algorithm for better performance
      console.log("Using optimized worker matching algorithm");
      const matchingWorkers = await findMatchingWorkersForJob(jobId);
      
      // Calculate execution time
      const executionTime = Date.now() - startTime;
      
      res.json({
        workers: matchingWorkers,
        matchCount: matchingWorkers.length,
        executionTimeMs: executionTime,
        optimized: true
      });
    } catch (error) {
      console.error("Error searching for workers:", error);
      res.status(500).json({ message: "Failed to find matching workers" });
    }
  });

  // Get jobs created by the current user
  app.get("/api/my-jobs", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const jobs = await storage.getJobsByEmployer(req.user!.id);
      
      // For each job, get the number of applications
      const jobsWithApplicationCounts = await Promise.all(
        jobs.map(async (job) => {
          const applications = await storage.getJobApplicationsForJob(job.id);
          return {
            ...job,
            applicationCount: applications.length
          };
        })
      );
      
      res.json(jobsWithApplicationCounts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch your jobs" });
    }
  });

  // Get all applications for a specific job
  
  app.get("/api/job-applications/:jobId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const jobId = parseInt(req.params.jobId);
    console.log(`[DEBUG] Getting applications for job ${jobId} by user ${req.user!.id}`);
    
    try {
      // Get the job to verify ownership
      const job = await storage.getJob(jobId);
      console.log(`[DEBUG] Job details:`, job);
      
      if (!job) {
        return res.status(404).json({ message: "Job not found" });
      }
      
      // Check if the user is the owner of the job
      if (job.employerId !== req.user!.id) {
        console.log(`[DEBUG] User ${req.user!.id} is not the owner of job ${jobId} (owner is ${job.employerId})`);
        return res.status(403).json({ message: "You do not have permission to view these applications" });
      }
      
      // Check subscription for viewing applicants
      const canViewApplicants = await storage.checkSubscriptionForApplicantView(req.user!.id, jobId);
      console.log(`[DEBUG] Can view applicants: ${canViewApplicants}`);
      
      if (!canViewApplicants) {
        return res.status(403).json({ 
          message: "You need to upgrade your subscription to view applicants",
          requiresUpgrade: true 
        });
      }
      
      // Increment the applicant view count
      await storage.incrementApplicantViewCount(req.user!.id);
      
      // Get all applications for the job
      const applications = await storage.getJobApplicationsForJob(jobId);
      console.log(`[DEBUG] Found ${applications.length} applications for job ${jobId}`);
      
      if (applications.length === 0) {
        console.log(`[DEBUG] No applications found for job ${jobId}`);
        return res.json([]);
      }
      
      // Get detailed applicant information
      const applicationsWithDetails = await Promise.all(
        applications.map(async (application) => {
          console.log(`[DEBUG] Processing application ${application.id} from jobseeker ${application.jobseekerId}`);
          const applicant = await storage.getUser(application.jobseekerId);
          const skills = await storage.getUserSkills(application.jobseekerId);
          const availability = await storage.getUserAvailability(application.jobseekerId);
          
          // Get user job roles for matching
          const userJobRoles = await storage.getUserJobRoles(application.jobseekerId);
          const userJobRoleIds = userJobRoles.map(ujr => ujr.jobRoleId);
          
          console.log(`[DEBUG] Job role ID: ${job.jobRoleId}`);
          console.log(`[DEBUG] Applicant (${application.jobseekerId}) primary job role ID: ${applicant.jobRoleId}`);
          console.log(`[DEBUG] Applicant job roles from userJobRoles:`, userJobRoleIds);
          
          // Calculate match score
          const matchScore = {
            overallScore: 0,
            roleScore: 0,
            skillsMatchPercentage: 0,
            availabilityScore: 0,
            skillsScore: 0
          };
          
          // 1. Job Role matching (50% of total score)
          // First check primary role (from the user object)
          if (job.jobRoleId && applicant.jobRoleId) {
            console.log(`[DEBUG] Comparing job role ID ${job.jobRoleId} with applicant primary role ID ${applicant.jobRoleId}`);
            // Direct role match with primary role
            if (job.jobRoleId === applicant.jobRoleId) {
              matchScore.roleScore = 50;
              console.log(`[DEBUG] Direct match with primary role! Setting roleScore to 50`);
            }
          }
          
          // If no match with primary role, check additional roles
          if (matchScore.roleScore === 0 && job.jobRoleId && userJobRoleIds.length > 0) {
            console.log(`[DEBUG] No match with primary role, checking additional roles`);
            // Find the best role match score from all user roles
            for (const userRoleId of userJobRoleIds) {
              console.log(`[DEBUG] Comparing job role ${job.jobRoleId} with user role ${userRoleId}`);
              // Calculate role match - exact match = 50 points (50%)
              if (job.jobRoleId === userRoleId) {
                matchScore.roleScore = 50;
                console.log(`[DEBUG] Match found with role ID ${userRoleId}! Setting roleScore to 50`);
                break;
              }
            }
          }
          
          // 2. Availability matching (30% of total score)
          if (job.requiredAvailability && job.requiredAvailability.length > 0 && availability.length > 0) {
            // Check if any user availability overlaps with job required availability
            const hasTimeMatch = job.requiredAvailability.some(jobSlot => {
              return availability.some(userSlot => {
                // Check if days match
                if (userSlot.dayOfWeek !== jobSlot.dayOfWeek) return false;
                
                // Check overlap in hours
                const userStart = userSlot.startHour;
                const userEnd = userSlot.endHour;
                const jobStart = jobSlot.startHour;
                const jobEnd = jobSlot.endHour;
                
                // Hours overlap if user's start time is before job's end time 
                // AND user's end time is after job's start time
                return userStart < jobEnd && userEnd > jobStart;
              });
            });
            
            if (hasTimeMatch) {
              matchScore.availabilityScore = 30; // 30% of the score is time availability match
            }
          }
          
          // 3. Skill matching (20% of total score)
          if (job.requiredSkills && job.requiredSkills.length > 0 && skills.length > 0) {
            const userSkillIds = skills.map(skill => skill.id);
            const matchingSkillsCount = job.requiredSkills.filter(skillId => 
              userSkillIds.includes(skillId)
            ).length;
            
            // Calculate the raw percentage of skills that match
            matchScore.skillsMatchPercentage = Math.round((matchingSkillsCount / job.requiredSkills.length) * 100);
            
            // Calculate skill match score (max 20% of total score)
            matchScore.skillsScore = (matchingSkillsCount / job.requiredSkills.length) * 20;
          }
          
          // Calculate overall score
          matchScore.overallScore = Math.round(matchScore.roleScore + matchScore.availabilityScore + matchScore.skillsScore);
          
          console.log(`[DEBUG] Calculated match score for application ${application.id}: `, matchScore);
          
          return {
            ...application,
            applicant: {
              ...applicant,
              skills,
              availability
            },
            matchScore
          };
        })
      );
      
      console.log(`[DEBUG] Returning ${applicationsWithDetails.length} applications with details`);
      res.json(applicationsWithDetails);
    } catch (error) {
      console.error(`[ERROR] Failed to fetch job applications:`, error);
      res.status(500).json({ message: "Failed to fetch job applications" });
    }
  });
  
  // Get a specific application with all details
  app.get("/api/applications/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const applicationId = parseInt(req.params.id);
      const application = await storage.getJobApplicationWithDetails(applicationId);
      
      if (!application) {
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Check if user is authorized to view this application (either the applicant or the job owner)
      if (application.jobseekerId !== req.user!.id && application.job.employerId !== req.user!.id) {
        return res.status(403).json({ message: "You don't have permission to view this application" });
      }
      
      // If user is viewing as employer, check subscription for applicant view
      if (application.job.employerId === req.user!.id) {
        // Get the job ID for the application
        const jobId = application.jobId;
        
        // Check if user has appropriate subscription for this job
        const canView = await storage.checkSubscriptionForApplicantView(req.user!.id, jobId);
        if (!canView) {
          return res.status(403).json({ 
            message: "You need an appropriate subscription to view applicant details",
            subscriptionRequired: true,
            jobId: jobId,
          });
        }
        
        // Increment the applicant view count
        await storage.incrementApplicantViewCount(req.user!.id);
      }
      
      res.json(application);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch application details" });
    }
  });

  // Messaging Routes
  // First define specific routes
  // Create a new reply to a message
  app.post("/api/messages/reply", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { content, applicationId, recipientId } = req.body;
      
      if (!content || !applicationId || !recipientId) {
        return res.status(400).json({ 
          message: "Missing required fields: content, applicationId, or recipientId" 
        });
      }
      
      // Create a new message
      const message = await storage.sendMessage({
        applicationId,
        senderId: req.user!.id,
        recipientId,
        content
      });
      
      console.log(`[DEBUG] Created new reply message: ${JSON.stringify(message)}`);
      
      // Get application details for the response
      const application = await storage.getJobApplicationWithDetails(applicationId);
      
      // Return the created message with enriched data
      res.status(201).json({
        ...message,
        sender: {
          id: req.user!.id,
          fullName: req.user!.fullName
        },
        application: application || null,
        job: application?.job || null
      });
    } catch (error) {
      console.error('[ERROR] Failed to create reply message:', error);
      res.status(500).json({ message: "Failed to send message" });
    }
  });
  
  // Get all messages for the current user
  app.get("/api/messages/me", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      console.log(`[DEBUG] Getting all messages for user ${req.user!.id}`);
      // Get messages directly with sender information
      const messagesWithSenders = await db
        .select({
          id: messages.id,
          applicationId: messages.applicationId,
          senderId: messages.senderId,
          recipientId: messages.recipientId,
          content: messages.content,
          createdAt: messages.createdAt,
          isRead: messages.isRead,
          senderName: users.fullName,
        })
        .from(messages)
        .where(or(
          eq(messages.senderId, req.user!.id),
          eq(messages.recipientId, req.user!.id)
        ))
        .leftJoin(users, eq(messages.senderId, users.id))
        .orderBy(desc(messages.createdAt));
      
      console.log(`[DEBUG] Raw messages found: ${messagesWithSenders.length}`);
      
      if (messagesWithSenders.length > 0) {
        console.log(`[DEBUG] First message: applicationId=${messagesWithSenders[0].applicationId}, senderId=${messagesWithSenders[0].senderId}, recipientId=${messagesWithSenders[0].recipientId}`);
      }
      
      // Format messages with sender info
      const formattedMessages = messagesWithSenders.map(msg => ({
        id: msg.id,
        applicationId: msg.applicationId,
        senderId: msg.senderId,
        recipientId: msg.recipientId,
        content: msg.content,
        createdAt: msg.createdAt,
        isRead: msg.isRead,
        sender: {
          id: msg.senderId,
          fullName: msg.senderName
        }
      }));
      
      // Get applications data to include with messages
      const applicationIds = Array.from(new Set(formattedMessages.map(msg => msg.applicationId)));
      const applications: any[] = [];
      
      console.log(`[DEBUG] Application IDs to process: ${applicationIds.join(', ')}`);
      
      // Make sure we're only processing valid application IDs (numbers)
      for (const appId of applicationIds) {
        try {
          // Ensure appId is a valid number
          const numericAppId = Number(appId);
          if (appId && !isNaN(numericAppId) && numericAppId > 0) {
            console.log(`[DEBUG] Fetching application details for ID: ${numericAppId}`);
            const app = await storage.getJobApplicationWithDetails(numericAppId);
            if (app) {
              applications.push(app);
              console.log(`[DEBUG] Successfully added application ${numericAppId} with job ${app.job?.title || 'unknown'}`);
            } else {
              console.log(`[DEBUG] Application ${numericAppId} not found`);
            }
          } else {
            console.log(`[DEBUG] Skipping invalid application ID: ${appId} (as number: ${numericAppId})`);
          }
        } catch (err) {
          console.error(`[ERROR] Error getting application ${appId}:`, err);
        }
      }
      
      // Include application and job data with each message
      const enrichedMessages = formattedMessages.map(msg => {
        const application = applications.find(app => app.id === msg.applicationId);
        return {
          ...msg,
          application: application || null,
          job: application?.job || null
        };
      });
      
      // Sort by created date, newest first
      enrichedMessages.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );
      
      console.log(`[DEBUG] Found ${formattedMessages.length} messages for user ${req.user!.id}`);
      res.json(enrichedMessages);
    } catch (error) {
      console.error('[ERROR] Failed to fetch user messages:', error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });
  
  // Then define the generic route with parameter
  app.get("/api/messages/:applicationId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Validate applicationId is a number
      const applicationId = Number(req.params.applicationId);
      
      if (isNaN(applicationId) || applicationId <= 0) {
        console.log(`[ERROR] Invalid application ID: ${req.params.applicationId}`);
        return res.status(400).json({ message: "Invalid application ID" });
      }
      
      console.log(`[DEBUG] Getting messages for application ${applicationId} by user ${req.user!.id}`);
      
      const application = await storage.getJobApplication(applicationId);
      
      if (!application) {
        console.log(`[ERROR] Application ${applicationId} not found`);
        return res.status(404).json({ message: "Application not found" });
      }
      
      console.log(`[DEBUG] Application details: jobId=${application.jobId}, jobseekerId=${application.jobseekerId}`);
      
      // Check if user is authorized to view messages for this application
      const job = await storage.getJob(application.jobId);
      if (!job) {
        console.log(`[ERROR] Associated job ${application.jobId} not found`);
        return res.status(404).json({ message: "Associated job not found" });
      }
      
      console.log(`[DEBUG] Job details: employerId=${job.employerId}, title=${job.title}`);
      
      if (application.jobseekerId !== req.user!.id && job.employerId !== req.user!.id) {
        console.log(`[ERROR] User ${req.user!.id} is not authorized to view messages for application ${applicationId}`);
        console.log(`[ERROR] Jobseeker ID: ${application.jobseekerId}, Employer ID: ${job.employerId}`);
        return res.status(403).json({ message: "You don't have permission to view these messages" });
      }
      
      // If user is viewing as employer, check subscription
      if (job.employerId === req.user!.id) {
        const jobId = application.jobId;
        const canView = await storage.checkSubscriptionForApplicantView(req.user!.id, jobId);
        console.log(`[DEBUG] Employer ${req.user!.id} subscription check for job ${jobId}: ${canView}`);
        
        if (!canView) {
          return res.status(403).json({ 
            message: "You need an appropriate subscription to view messages",
            subscriptionRequired: true,
            jobId: jobId
          });
        }
      }
      
      const messages = await storage.getMessages(applicationId);
      console.log(`[DEBUG] Found ${messages.length} messages for application ${applicationId}`);
      
      if (messages.length > 0) {
        console.log(`[DEBUG] First message: senderId=${messages[0].senderId}, recipientId=${messages[0].recipientId}`);
      }
      
      res.json(messages);
    } catch (error) {
      console.error(`[ERROR] Failed to fetch messages:`, error);
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  app.post("/api/messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { applicationId, recipientId, content } = req.body;
      
      console.log(`[DEBUG] Sending message: applicationId=${applicationId}, recipientId=${recipientId}, senderId=${req.user!.id}, content="${content?.substring(0, 20)}..."`);
      
      // Check if application exists
      const application = await storage.getJobApplication(applicationId);
      if (!application) {
        console.log(`[ERROR] Application not found: ${applicationId}`);
        return res.status(404).json({ message: "Application not found" });
      }
      
      // Check if job exists
      const job = await storage.getJob(application.jobId);
      if (!job) {
        console.log(`[ERROR] Associated job not found for application: ${applicationId}`);
        return res.status(404).json({ message: "Associated job not found" });
      }
      
      // Check if user is authorized to send messages for this application
      if (application.jobseekerId !== req.user!.id && job.employerId !== req.user!.id) {
        console.log(`[ERROR] User ${req.user!.id} is not authorized to send messages for application ${applicationId}`);
        return res.status(403).json({ message: "You don't have permission to send messages for this application" });
      }
      
      // If user is sending as employer, check subscription
      if (job.employerId === req.user!.id) {
        const jobId = application.jobId;
        const canMessage = await storage.checkSubscriptionForApplicantView(req.user!.id, jobId);
        console.log(`[DEBUG] Employer ${req.user!.id} subscription check for job ${jobId}: ${canMessage}`);
        
        if (!canMessage) {
          return res.status(403).json({ 
            message: "You need an appropriate subscription to send messages",
            subscriptionRequired: true,
            jobId: jobId
          });
        }
      }
      
      // Check if recipient is valid (either jobseeker or employer)
      if (recipientId !== application.jobseekerId && recipientId !== job.employerId) {
        console.log(`[ERROR] Invalid recipient ${recipientId}. Expected either jobseeker ${application.jobseekerId} or employer ${job.employerId}`);
        return res.status(400).json({ message: "Invalid recipient" });
      }
      
      // Create message
      const message = await storage.sendMessage({
        applicationId,
        senderId: req.user!.id,
        recipientId,
        content
      });
      
      console.log(`[DEBUG] Message sent successfully: ${message.id}`);
      res.status(201).json(message);
    } catch (error) {
      console.error('[ERROR] Failed to send message:', error);
      if (error instanceof ZodError) {
        return res.status(400).json({ message: formatError(error).message });
      }
      res.status(500).json({ message: "Failed to send message" });
    }
  });

  app.put("/api/messages/:id/read", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const messageId = Number(req.params.id);
      
      if (isNaN(messageId) || messageId <= 0) {
        console.log(`[ERROR] Invalid message ID: ${req.params.id}`);
        return res.status(400).json({ message: "Invalid message ID" });
      }
      
      const message = await storage.markMessageAsRead(messageId);
      
      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }
      
      res.json(message);
    } catch (error) {
      res.status(500).json({ message: "Failed to mark message as read" });
    }
  });

  app.get("/api/messages/unread-count", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const count = await storage.getUnreadMessageCount(req.user!.id);
      res.json({ count });
    } catch (error) {
      res.status(500).json({ message: "Failed to get unread count" });
    }
  });
  
  // Get all users endpoint for messaging
  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const users = await storage.getAllUsers();
      
      // Only return necessary user information for messaging
      const sanitizedUsers = users.map(user => ({
        id: user.id,
        username: user.username,
        fullName: user.fullName,
        avatarUrl: user.avatarUrl,
        jobRoleId: user.jobRoleId,
        location: user.location
      }));
      
      res.json(sanitizedUsers);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  // Direct Messages API (not tied to job applications)
  app.get("/api/direct-messages/conversation/:userId", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const currentUserId = req.user!.id;
      const otherUserId = parseInt(req.params.userId);
      
      // Check if user exists
      const otherUser = await storage.getUser(otherUserId);
      if (!otherUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const messages = await storage.getDirectMessages(currentUserId, otherUserId);
      
      res.status(200).json(messages);
    } catch (error) {
      console.error("Error getting direct messages:", error);
      res.status(500).json({ message: "Error getting direct messages" });
    }
  });
  
  app.get("/api/direct-messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const userId = req.user!.id;
      const messages = await storage.getDirectMessagesByUser(userId);
      
      res.status(200).json(messages);
    } catch (error) {
      console.error("Error getting direct messages:", error);
      res.status(500).json({ message: "Error getting direct messages" });
    }
  });
  
  app.post("/api/direct-messages", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const senderId = req.user!.id;
      const { recipientId, content } = req.body;
      
      if (!recipientId || !content) {
        return res.status(400).json({ message: "Recipient ID and content are required" });
      }
      
      // Verify both users exist
      const recipient = await storage.getUser(recipientId);
      if (!recipient) {
        return res.status(404).json({ message: "Recipient not found" });
      }
      
      // Any user can send messages
      const messageData = {
        senderId,
        recipientId,
        content
      };
      
      const message = await storage.sendDirectMessage(messageData);
      
      res.status(201).json(message);
    } catch (error) {
      console.error("Error sending direct message:", error);
      res.status(500).json({ message: "Error sending direct message" });
    }
  });
  
  app.put("/api/direct-messages/:id/read", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      const messageId = parseInt(req.params.id);
      const message = await storage.markDirectMessageAsRead(messageId);
      
      if (!message) {
        return res.status(404).json({ message: "Message not found" });
      }
      
      res.status(200).json(message);
    } catch (error) {
      console.error("Error marking direct message as read:", error);
      res.status(500).json({ message: "Error marking direct message as read" });
    }
  });
  
  app.get("/api/direct-messages/unread-count", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const count = await storage.getUnreadDirectMessageCount(req.user!.id);
      res.json({ count });
    } catch (error) {
      console.error("Error getting unread direct message count:", error);
      res.status(500).json({ 
        message: "Failed to get unread direct messages count",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Subscription management routes
  app.get("/api/subscription-plans", async (req, res) => {
    try {
      const plans = await storage.getAllSubscriptionPlans();
      res.json(plans);
    } catch (error) {
      console.error("Error with subscription plans:", error);
      res.status(500).json({ message: "Failed to fetch subscription plans" });
    }
  });

  app.get("/api/my-subscription", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const subscription = await storage.getUserSubscription(req.user!.id);
      
      if (!subscription) {
        return res.json(null);
      }
      
      // Include the plan details
      const plan = await storage.getSubscriptionPlan(subscription.planId);
      
      res.json({
        ...subscription,
        plan
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch your subscription" });
    }
  });
  
  // Cancel subscription endpoint
  app.post("/api/cancel-subscription", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      // Get the user's current subscription
      const subscription = await storage.getUserSubscription(req.user!.id);
      
      if (!subscription) {
        return res.status(404).json({ message: "No active subscription found" });
      }
      
      // For Level 1 (Single Job) plan, we don't allow cancellation as it's a one-time payment
      const plan = await storage.getSubscriptionPlan(subscription.planId);
      if (plan && plan.id === 1) {
        return res.status(400).json({ 
          message: "Single Job plan cannot be cancelled as it's a one-time payment" 
        });
      }
      
      // Update subscription to mark it as inactive
      const updatedSubscription = await storage.updateUserSubscription(subscription.id, {
        ...subscription,
        isActive: false,
        // Set end date to now if it's in the future
        endDate: new Date() > subscription.endDate ? subscription.endDate : new Date()
      });
      
      // If this is a Stripe subscription and we have customer info, cancel in Stripe too
      if (subscription.stripeSubscriptionId && stripe) {
        try {
          await stripe.subscriptions.cancel(subscription.stripeSubscriptionId);
          console.log(`Cancelled Stripe subscription: ${subscription.stripeSubscriptionId}`);
        } catch (stripeError) {
          console.error("Error cancelling Stripe subscription:", stripeError);
          // Continue anyway - we've already canceled it in our database
        }
      }
      
      res.json({ 
        success: true, 
        message: "Subscription cancelled successfully",
        subscription: updatedSubscription
      });
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      res.status(500).json({ 
        message: "Failed to cancel subscription",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Stripe Payment Endpoints
  app.post("/api/create-payment-intent", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      if (!stripe) {
        return res.status(500).json({ message: "Stripe is not configured" });
      }
      
      const { planId, jobId } = req.body;
      const plan = await storage.getSubscriptionPlan(planId);
      
      if (!plan) {
        return res.status(404).json({ message: "Plan not found" });
      }
      
      // Remove currency symbol and convert to cents
      const amount = Math.round(parseFloat(plan.price.replace(/[^0-9.]/g, '')) * 100);
      
      // Create metadata object with plan info
      const metadata: Record<string, string> = {
        userId: req.user!.id.toString(),
        planId: planId.toString(),
        planName: plan.name
      };
      
      // Add jobId to metadata for Single Job plan
      if (plan.id === 1 && jobId) {
        console.log(`Adding jobId ${jobId} to payment intent metadata for Single Job plan`);
        metadata.jobId = jobId.toString();
      }
      
      // Create production payment intent
      const paymentIntent = await stripe.paymentIntents.create({
        amount,
        currency: 'gbp',
        metadata,
        payment_method_types: ['card'],
        description: `${plan.name} Subscription - ${plan.price}`,
        receipt_email: req.user!.email
      });
      
      res.json({
        clientSecret: paymentIntent.client_secret,
        planDetails: plan
      });
    } catch (error) {
      console.error("Payment intent creation error:", error);
      res.status(500).json({ 
        message: "Failed to create payment intent", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });
  
  app.post("/api/subscribe", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { planId, billingCycle, jobId } = req.body;
      
      // Get subscription plan details
      const plan = await storage.getSubscriptionPlan(planId);
      if (!plan) {
        return res.status(404).json({ message: "Plan not found" });
      }
      
      // For Single Job plan, verify jobId is provided
      if (plan.name === "Single Job" && !jobId) {
        return res.status(400).json({ 
          message: "Job ID is required for Single Job subscriptions" 
        });
      }
      
      // If jobId is provided for Single Job plan, verify the job exists and belongs to the user
      if (plan.name === "Single Job" && jobId) {
        const job = await storage.getJob(jobId);
        if (!job) {
          return res.status(404).json({ message: "Job not found" });
        }
        
        if (job.employerId !== req.user!.id) {
          return res.status(403).json({ 
            message: "You don't have permission to subscribe for this job" 
          });
        }
      }
      
      if (!stripe) {
        return res.status(500).json({ message: "Stripe is not configured" });
      }
      
      // Calculate amount based on plan price and billing cycle
      // Make sure price is a number
      const basePrice = typeof plan.price === 'string' 
        ? parseFloat(plan.price.replace(/[^0-9.]/g, ''))
        : plan.price;
      
      const multiplier = billingCycle === 'yearly' ? 12 * 0.8 : 1; // 20% discount for yearly
      const amount = Math.round(basePrice * 100 * multiplier); // Convert to cents
      
      // Create payment intent with job ID in metadata if it's a Single Job plan
      const metadata: Record<string, string> = {
        userId: req.user!.id.toString(),
        planId: planId.toString(),
        planName: plan.name,
        billingCycle
      };
      
      // Add jobId to metadata if it's a Single Job plan
      if (plan.name === "Single Job" && jobId) {
        metadata.jobId = jobId.toString();
      }
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount,
        currency: 'gbp',
        metadata,
        payment_method_types: ['card'],
        description: `${plan.name} Subscription - ${plan.price} (${billingCycle})`,
        receipt_email: req.user!.email
      });
      
      // Return client secret to frontend for payment processing
      res.json({
        clientSecret: paymentIntent.client_secret,
        planDetails: plan
      });
    } catch (error) {
      console.error("Subscription error:", error);
      res.status(500).json({ 
        message: "Failed to create subscription", 
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Handle Stripe webhooks for subscription events
  app.post("/api/stripe-webhook", async (req, res) => {
    try {
      // Import the webhook handler
      const { handleStripeWebhook } = await import('./services/stripe-webhook');
      
      // The body-parser middleware in server/index.ts has already
      // preserved the raw body as a Buffer for this route
      const signature = req.headers['stripe-signature'] as string | undefined;
      
      // Pass the raw body buffer for webhook verification
      const result = await handleStripeWebhook(
        req.body, // This is the raw buffer preserved by our middleware
        signature,
        storage
      );
      
      if (!result.success) {
        return res.status(400).json({ 
          success: false,
          message: result.message 
        });
      }
      
      return res.json({ 
        success: true,
        message: result.message 
      });
    } catch (error) {
      console.error('Stripe webhook error:', error);
      return res.status(500).json({ 
        success: false,
        error: error instanceof Error ? error.message : 'Webhook handler failed' 
      });
    }
  });

  app.post("/api/payment-success", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    try {
      const { paymentIntentId } = req.body;
      
      if (!paymentIntentId) {
        return res.status(400).json({ message: "Missing payment intent ID" });
      }
      
      console.log(`Processing payment success for intent: ${paymentIntentId}`);
      
      if (!stripe) {
        return res.status(500).json({ message: "Stripe is not configured" });
      }
      
      // Verify payment intent was successful
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      console.log(`Payment intent status: ${paymentIntent.status}, metadata:`, paymentIntent.metadata);
      
      // Accept all valid payment statuses for production
      const validStatuses = ['succeeded', 'requires_capture', 'processing'];
      if (!validStatuses.includes(paymentIntent.status)) {
        return res.status(400).json({ 
          message: `Payment has not succeeded. Current status: ${paymentIntent.status}` 
        });
      }
      
      // Extract plan and job info from payment intent metadata
      const planId = parseInt(paymentIntent.metadata.planId || '0');
      const jobId = paymentIntent.metadata.jobId ? parseInt(paymentIntent.metadata.jobId) : null;
      
      console.log(`Retrieved from payment metadata: planId=${planId}, jobId=${jobId}`);
      
      // Get subscription plan details
      const plan = await storage.getSubscriptionPlan(planId);
      if (!plan) {
        return res.status(404).json({ message: "Plan not found" });
      }
      
      // For Basic (Single Job) plan, ensure jobId is provided
      if (plan.id === 1 && !jobId) {
        return res.status(400).json({ 
          message: "Job ID is required for Basic (Single Job) subscriptions"
        });
      }
      
      // If it's a Basic (Single Job) subscription, verify the job exists and belongs to the user
      if (plan.id === 1 && jobId) {
        const job = await storage.getJob(jobId);
        if (!job) {
          return res.status(404).json({ message: "Job not found" });
        }
        
        if (job.employerId !== req.user!.id) {
          return res.status(403).json({ 
            message: "You don't have permission to subscribe for this job"
          });
        }
      }
      
      // Calculate subscription end date based on plan
      let endDate: Date;
      if (plan.id === 1) { // Basic (Single Job) plan
        // One-time plans don't expire (or set to a far future date)
        endDate = new Date();
        endDate.setFullYear(endDate.getFullYear() + 10); // Set far in the future
      } else {
        // Monthly subscription for Standard and Premium
        endDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days from now
      }
      
      // Check if user already has a subscription
      const existingSubscription = await storage.getUserSubscription(req.user!.id);
      
      let subscription;
      
      // Get or create Stripe customer
      let stripeCustomerId: string | null = null;
      let stripeSubscriptionId: string | null = null;
      
      // For monthly/recurring subscriptions, create a Stripe Customer and Subscription
      if (plan.id > 1 && stripe) { // If it's not a Basic (Single Job) plan
        try {
          // First check if user already has a customer ID in a previous subscription
          if (existingSubscription?.stripeCustomerId) {
            stripeCustomerId = existingSubscription.stripeCustomerId;
          } else {
            // Create a new customer
            const customer = await stripe.customers.create({
              email: req.user!.email,
              name: req.user!.fullName || req.user!.username,
              metadata: {
                userId: req.user!.id.toString()
              }
            });
            stripeCustomerId = customer.id;
          }
          
          // Attach payment method to customer (if we have it)
          if (paymentIntent.payment_method) {
            await stripe.paymentMethods.attach(paymentIntent.payment_method.toString(), {
              customer: stripeCustomerId
            });
            
            // Set as default payment method
            await stripe.customers.update(stripeCustomerId, {
              invoice_settings: {
                default_payment_method: paymentIntent.payment_method.toString()
              }
            });
          }
          
          // First create a product
          const product = await stripe.products.create({
            name: plan.name,
            description: plan.description || 'RightPegMatch Subscription'
          });
          
          // Create a price for the product
          const price = await stripe.prices.create({
            product: product.id,
            currency: 'gbp',
            unit_amount: plan.id === 2 ? 2999 : 0, // £29.99 for Standard (ID 2)
            recurring: {
              interval: 'month'
            }
          });
          
          // Create a subscription for recurring billing
          const stripeSubscription = await stripe.subscriptions.create({
            customer: stripeCustomerId,
            items: [
              {
                price: price.id
              }
            ],
            metadata: {
              userId: req.user!.id.toString(),
              planId: planId.toString()
            }
          });
          
          stripeSubscriptionId = stripeSubscription.id;
          console.log(`Created Stripe subscription ${stripeSubscriptionId} for customer ${stripeCustomerId}`);
          
          // Update the end date to match the Stripe subscription billing cycle
          if (stripeSubscription.current_period_end) {
            endDate = new Date(stripeSubscription.current_period_end * 1000);
          }
        } catch (stripeError) {
          console.error("Error creating Stripe subscription:", stripeError);
          // Continue anyway - we'll still create a subscription in our database
        }
      }
      
      if (existingSubscription) {
        console.log(`Updating existing subscription ${existingSubscription.id} for user ${req.user!.id}`);
        // Update existing subscription
        subscription = await storage.updateUserSubscription(existingSubscription.id, {
          planId,
          startDate: new Date(),
          endDate,
          isActive: true,
          searchesUsed: 0,
          applicantViewsUsed: 0,
          jobId: plan.id === 1 ? jobId : null, // null for non-Basic plans
          stripeCustomerId: stripeCustomerId || existingSubscription.stripeCustomerId,
          stripeSubscriptionId: stripeSubscriptionId || existingSubscription.stripeSubscriptionId
        });
      } else {
        console.log(`Creating new subscription for user ${req.user!.id}, plan ${planId}`);
        // Create new subscription
        subscription = await storage.createUserSubscription({
          userId: req.user!.id,
          planId,
          startDate: new Date(),
          endDate,
          isActive: true,
          searchesUsed: 0,
          applicantViewsUsed: 0,
          jobId: plan.id === 1 ? jobId : null, // null for non-Basic plans
          stripeCustomerId,
          stripeSubscriptionId
        });
      }
      
      console.log("Subscription details:", JSON.stringify(subscription, null, 2));
      
      res.json({ 
        success: true, 
        message: "Subscription activated successfully", 
        subscription
      });
    } catch (error) {
      console.error("Payment success error:", error);
      res.status(500).json({ 
        message: "Failed to process successful payment", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // AI-powered routes
  if (process.env.ANTHROPIC_API_KEY) {
    // Get AI-powered skill suggestions for a specific job role
    app.get("/api/ai/job-role-skills/:jobRoleId", async (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const { jobRoleId } = req.params;
        
        // Find the job role
        const jobRole = await storage.getJobRole(parseInt(jobRoleId));
        if (!jobRole) {
          return res.status(404).json({ message: "Job role not found" });
        }

        // Get skill suggestions from Claude
        const suggestions = await anthropicService.suggestSkillsForJobRole(
          jobRole.name,
          jobRole.category
        );

        res.json(suggestions);
      } catch (error) {
        console.error("Error in job role skills suggestions:", error);
        res.status(500).json({ 
          message: "Failed to get skill suggestions",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    });

    // Suggest skills based on job role and bio
    app.post("/api/ai/suggest-skills", async (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const { jobRole, bio, existingSkills } = req.body;
        
        if (!jobRole) {
          return res.status(400).json({ message: "Job role is required" });
        }
        
        const skillSuggestions = await anthropicService.suggestSkills(
          jobRole, 
          bio || "", 
          existingSkills || []
        );
        
        res.json(skillSuggestions);
      } catch (error) {
        console.error("Error suggesting skills:", error);
        res.status(500).json({ 
          message: "Failed to generate skill suggestions",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    });
    
    // Analyze job description and assess compatibility
    app.post("/api/ai/analyze-job", async (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const { jobDescription, jobTitle, userSkills, userJobRole } = req.body;
        
        if (!jobDescription || !jobTitle) {
          return res.status(400).json({ message: "Job description and title are required" });
        }
        
        const analysis = await anthropicService.analyzeJobDescription(
          jobDescription,
          jobTitle,
          userSkills || [],
          userJobRole || "Not specified"
        );
        
        res.json(analysis);
      } catch (error) {
        console.error("Error analyzing job:", error);
        res.status(500).json({ 
          message: "Failed to analyze job description",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    });
    
    // Enhance job listing with AI
    app.post("/api/ai/enhance-job-listing", async (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const { jobTitle, draftDescription, companyName, location, salary } = req.body;
        
        if (!jobTitle || !draftDescription || !companyName) {
          return res.status(400).json({ 
            message: "Job title, draft description, and company name are required" 
          });
        }
        
        const enhancedDescription = await anthropicService.enhanceJobListing(
          jobTitle,
          draftDescription,
          companyName,
          location || null,
          salary || null
        );
        
        res.json({ enhancedDescription });
      } catch (error) {
        console.error("Error enhancing job listing:", error);
        res.status(500).json({ 
          message: "Failed to enhance job listing",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    });
    
    // Generate job matching explanation
    app.post("/api/ai/match-explanation", async (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const { jobTitle, jobRequirements, userSkills, userJobRole, matchScore } = req.body;
        
        if (!jobTitle || !jobRequirements) {
          return res.status(400).json({ message: "Job title and requirements are required" });
        }
        
        // Get job family information if available - use null as fallback
        const jobFamily = null;
        
        // Get candidate job family information from user's primary job role - use null as fallback
        const userJobFamily = null;
        
        const explanation = await anthropicService.generateMatchingExplanation(
          jobTitle,
          jobRequirements,
          userSkills || [],
          userJobRole || "Not specified",
          matchScore || 0,
          jobFamily,
          userJobFamily
        );
        
        res.json({ explanation });
      } catch (error) {
        console.error("Error generating match explanation:", error);
        res.status(500).json({ 
          message: "Failed to generate match explanation",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    });
    
    // Get skill suggestions for multiple job roles
    app.post("/api/ai/multiple-job-role-skills", async (req, res) => {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      try {
        const { jobRoleIds } = req.body;
        
        if (!Array.isArray(jobRoleIds) || jobRoleIds.length === 0) {
          return res.status(400).json({ message: "jobRoleIds must be a non-empty array" });
        }
        
        // Get job role details for all IDs
        const jobRolePromises = jobRoleIds.map(id => storage.getJobRole(parseInt(id.toString())));
        const jobRoles = await Promise.all(jobRolePromises);
        
        // Filter out any undefined results (invalid job role IDs)
        const validJobRoles = jobRoles.filter(role => role) as any[];
        
        if (validJobRoles.length === 0) {
          return res.status(404).json({ message: "No valid job roles found" });
        }
        
        // Format job roles for the AI service
        const formattedJobRoles = validJobRoles.map(role => ({
          name: role.name,
          category: role.category
        }));
        
        const suggestedSkills = await anthropicService.suggestSkillsForMultipleJobRoles(formattedJobRoles);
        
        res.json(suggestedSkills);
      } catch (error) {
        console.error("Error suggesting skills for multiple job roles:", error);
        res.status(500).json({ 
          message: "Failed to get skill suggestions",
          error: error instanceof Error ? error.message : String(error)
        });
      }
    });
  }

  // Direct Messages API endpoints are already defined earlier in the file.

  const httpServer = createServer(app);
  return httpServer;
}
