// This is a modified version of lines 740-750 in db-storage.ts

userJobRoles: userJobRoleNames,
userSkills: userSkillNames,
userLanguages,
userTimeZone: user.timeZone || 'UTC',
userAvailability: userAvailabilitySummary,
userPreferredHours: user.preferredHoursPerWeek || 0,
userJobFamily: userPrimaryJobRole?.jobFamily as string || "Other",
userMinSalary: user.minSalaryRequirement,
userMaxSalary: user.maxSalaryRequirement,
userSalaryType: user.preferredSalaryType || 'hourly'