/**
 * Optimized matching service for finding workers that match a job
 */
import { db } from "../db";
import * as schema from "../../shared/schema";
import { eq, inArray, and, sql, asc } from "drizzle-orm";
import { AIJobMatchResult, calculateAIJobMatchScore } from "./anthropic";
import { JobMatchScore } from "../../shared/schema";

/**
 * Find matching workers for a job with optimized performance
 * This uses a two-phase matching approach:
 * 1. Fast filtering using indexed tables (language, job family)
 * 2. Detailed matching on pre-filtered results
 */
export async function findMatchingWorkersForJob(jobId: number): Promise<(schema.User & { matchScore?: schema.JobMatchScore })[]> {
  console.time('optimizedFindMatchingWorkersForJob');
  
  // Get the job
  const job = await db.query.jobs.findFirst({
    where: eq(schema.jobs.id, jobId),
  });
  
  if (!job) {
    console.timeEnd('optimizedFindMatchingWorkersForJob');
    return [];
  }
  
  // STEP 1: Get job languages from the index
  const jobLanguages = await db.select({
    language: schema.jobLanguageIndex.language
  })
  .from(schema.jobLanguageIndex)
  .where(eq(schema.jobLanguageIndex.jobId, jobId));
  
  const jobLanguageList = jobLanguages.map(item => item.language);
  
  // For backward compatibility, also check the languages field if the index is empty
  if (jobLanguageList.length === 0 && job.requiredLanguages) {
    jobLanguageList.push(...job.requiredLanguages.split(',').map(lang => lang.trim()));
  }
  
  console.log(`Job languages: ${jobLanguageList.join(', ')}`);
  
  // STEP 2: Get job family from the index
  const jobFamilies = await db.select({
    jobFamily: schema.jobFamilyIndex.jobFamily
  })
  .from(schema.jobFamilyIndex)
  .where(eq(schema.jobFamilyIndex.jobId, jobId));
  
  const jobFamilyList = jobFamilies.map(item => item.jobFamily);
  
  // For backward compatibility, get job family directly if the index is empty
  if (jobFamilyList.length === 0 && job.jobFamily) {
    jobFamilyList.push(job.jobFamily);
  }
  
  console.log(`Job families: ${jobFamilyList.join(', ')}`);
  
  // PHASE 1: FAST FILTERING
  // Find users with matching language and job family
  // This query does an efficient pre-filtering before the expensive AI matching
  const potentialMatches = await db.select({
    userId: schema.users.id
  })
  .from(schema.users)
  .innerJoin(schema.userLanguageIndex, eq(schema.users.id, schema.userLanguageIndex.userId))
  .innerJoin(schema.userJobFamilyIndex, eq(schema.users.id, schema.userJobFamilyIndex.userId))
  .where(
    and(
      // Don't include the job creator 
      sql`${schema.users.id} != ${job.employerId}`,
      
      // User must know one of the job's required languages
      inArray(schema.userLanguageIndex.language, jobLanguageList),
      
      // User must be in one of the job's job families
      inArray(schema.userJobFamilyIndex.jobFamily, jobFamilyList)
    )
  )
  .groupBy(schema.users.id);
  
  const eligibleUserIds = potentialMatches.map(match => match.userId);
  console.log(`Fast filtering found ${eligibleUserIds.length} potential matches out of ~${await db.select({ count: sql<number>`count(*)` }).from(schema.users)}`);
  
  if (eligibleUserIds.length === 0) {
    console.timeEnd('optimizedFindMatchingWorkersForJob');
    return [];
  }
  
  // PHASE 2: DETAILED MATCHING
  // Now fetch the full user data for matches to perform detailed scoring
  const potentialUsers = await db.select()
    .from(schema.users)
    .where(inArray(schema.users.id, eligibleUserIds));
  
  // Get job skills
  let jobSkills: string[] = [];
  if (job.requiredSkills && (job.requiredSkills as number[]).length > 0) {
    const skills = await db.select()
      .from(schema.skills)
      .where(inArray(schema.skills.id, job.requiredSkills as number[]));
    
    jobSkills = skills.map(s => s.name);
  }
  
  // Get job role name
  let jobRoleName = '';
  if (job.jobRoleId) {
    const jobRole = await db.query.jobRoles.findFirst({
      where: eq(schema.jobRoles.id, job.jobRoleId)
    });
    
    if (jobRole) {
      jobRoleName = jobRole.name;
    }
  }
  
  // Prepare job availability data
  const jobAvailability = job.requiredAvailability as schema.JobAvailabilityRequirement[] || [];
  
  // Convert to user-friendly format
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const jobAvailabilitySummary = jobAvailability.map(slot => 
    `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 (${slot.timeZone || 'UTC'})`
  ).join(', ');
  
  // Array to hold user matches with their match scores
  const userMatches: { user: schema.User & { matchScore?: schema.JobMatchScore }; score: number }[] = [];
  
  // Process each user for detailed matching
  for (const user of potentialUsers) {
    try {
      // Get user skills
      const userSkillsData = await db.select()
        .from(schema.skills)
        .innerJoin(schema.userSkills, eq(schema.skills.id, schema.userSkills.skillId))
        .where(eq(schema.userSkills.userId, user.id));
      
      const userSkillNames = userSkillsData.map(skill => skill.skills.name);
      
      // Get user job roles
      const userJobRoles = await db.select({
        role: schema.jobRoles
      })
      .from(schema.userJobRoles)
      .innerJoin(schema.jobRoles, eq(schema.userJobRoles.jobRoleId, schema.jobRoles.id))
      .where(eq(schema.userJobRoles.userId, user.id));
      
      const userJobRoleNames = userJobRoles.map(userRole => userRole.role.name);
      
      // Get user job families
      const userJobFamilies = userJobRoles
        .map(r => r.role.jobFamily)
        .filter((jf): jf is string => jf !== null);
      
      // Get user availability
      const userAvailability = await db.select()
        .from(schema.availabilitySlots)
        .where(eq(schema.availabilitySlots.userId, user.id));
      
      // Convert to user-friendly format
      const userAvailabilitySummary = userAvailability.map(slot => 
        `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 (${slot.timeZone || 'UTC'})`
      ).join(', ');
      
      // Parse user languages
      const userLanguages = user.languages ? user.languages.split(',').map(lang => lang.trim()) : [];
      
      // Use the AI service to calculate match score
      const aiMatch = await calculateAIJobMatchScore({
        // Job details
        jobTitle: job.title,
        jobDescription: job.description || '',
        jobSkills,
        jobHourlyRate: job.hourlyRate || '',
        jobCurrency: job.currency || 'USD',
        jobRequiredLanguages: jobLanguageList,
        jobRoleName,
        jobAvailability: jobAvailabilitySummary,
        jobHoursPerWeek: job.hoursPerWeek || 0,
        jobFamily: job.jobFamily || "Other",
        jobMinSalary: job.minSalary ? Number(job.minSalary) : undefined,
        jobMaxSalary: job.maxSalary ? Number(job.maxSalary) : undefined,
        jobSalaryType: job.salaryType || 'hourly',
        
        // User details
        userJobRoles: userJobRoleNames,
        userSkills: userSkillNames,
        userLanguages,
        userTimeZone: user.timeZone || 'UTC',
        userAvailability: userAvailabilitySummary,
        userPreferredHours: user.preferredHoursPerWeek || 0,
        userJobFamily: userJobFamilies[0] || "Other",
        userMinSalary: user.minSalaryRequirement ? Number(user.minSalaryRequirement) : undefined,
        userMaxSalary: user.maxSalaryRequirement ? Number(user.maxSalaryRequirement) : undefined,
        userSalaryType: user.preferredSalaryType || 'hourly'
      });
      
      // Create match score from AI result
      const matchScore: JobMatchScore = {
        overallScore: aiMatch.matchScore,
        roleScore: aiMatch.keyFactors.roleMatch,
        skillsScore: aiMatch.keyFactors.skillsMatch,
        availabilityScore: aiMatch.keyFactors.availabilityMatch,
        skillsMatchPercentage: aiMatch.keyFactors.skillsMatch, // Use skill match score as percentage
        matchDetails: {
          // Traditional match details (can be empty for AI matching)
          matchedRoleId: 0,
          matchedSkillIds: [],
          requiredSkillsCount: jobSkills.length,
          matchedSkillsCount: 0, // Will be calculated differently by AI
          
          // AI-specific match details
          aiMatchExplanation: aiMatch.matchExplanation,
          aiStrengths: aiMatch.strengths,
          aiGaps: aiMatch.gaps,
          aiLanguageMatch: aiMatch.keyFactors.languageMatch,
          jobFamilyMatch: (aiMatch.keyFactors.jobFamilyMatch || 0) > 0,
          aiCompensationMatch: aiMatch.keyFactors.compensationMatch
        }
      };
      
      // Enhanced minimum threshold criteria to avoid poor matches
      const lowRoleScore = matchScore.roleScore < 40; // Role score below 40 is very low
      const lowSkillsScore = matchScore.skillsMatchPercentage < 30; // Skills match below 30% is very low
      
      // If both role and skills matches are poor, filter out the worker entirely
      if (lowRoleScore && lowSkillsScore) {
        console.log(`User ${user.id} (${user.username}) skipped due to both low role score (${matchScore.roleScore}) and low skills match (${matchScore.skillsMatchPercentage}%)`);
        continue;
      }
      
      // For users that pass both language requirement and role/skills minimums,
      // check overall score as a final filter
      if (matchScore.overallScore > 30) { // Threshold for better quality matches
        // Create a new user object with matchScore added
        const userWithScore = {
          ...user,
          matchScore
        };
        userMatches.push({ user: userWithScore, score: matchScore.overallScore });
      }
    } catch (error) {
      console.error(`Error calculating AI match for user ${user.id}:`, error);
      // If AI matching fails, skip this user
      continue;
    }
  }
  
  // Sort by score (highest first) and return users with their match scores
  console.timeEnd('optimizedFindMatchingWorkersForJob');
  return userMatches.sort((a, b) => b.score - a.score).map(match => match.user);
}