/**
 * Optimized matching service for improved performance
 */
import { db } from "../db";
import * as schema from "../../shared/schema";
import { eq, inArray, and, sql } from "drizzle-orm";
import { AIJobMatchResult, calculateAIJobMatchScore } from "./anthropic";
import { JobMatchScore } from "../../shared/schema";

/**
 * Find matching jobs for a user with optimized performance
 * This uses a two-phase matching approach:
 * 1. Fast filtering using indexed tables (language, job family)
 * 2. Detailed matching on pre-filtered results
 */
export async function findMatchingJobsForUser(userId: number, forceRefresh: boolean = false): Promise<(schema.Job & { matchScore?: schema.JobMatchScore })[]> {
  console.time('optimizedFindMatchingJobsForUser');
  
  // Get the user
  const user = await db.query.users.findFirst({
    where: eq(schema.users.id, userId),
  });
  
  if (!user) {
    console.timeEnd('optimizedFindMatchingJobsForUser');
    return [];
  }
  
  // STEP 1: Get user languages from the index
  const userLanguages = await db.select({
    language: schema.userLanguageIndex.language
  })
  .from(schema.userLanguageIndex)
  .where(eq(schema.userLanguageIndex.userId, userId));
  
  const userLanguageList = userLanguages.map(item => item.language);
  
  // For backward compatibility, also check the languages field if the index is empty
  if (userLanguageList.length === 0 && user.languages) {
    userLanguageList.push(...user.languages.split(',').map(lang => lang.trim()));
  }
  
  console.log(`User languages: ${userLanguageList.join(', ')}`);
  
  // STEP 2: Get user job families from the index
  const userJobFamilies = await db.select({
    jobFamily: schema.userJobFamilyIndex.jobFamily
  })
  .from(schema.userJobFamilyIndex)
  .where(eq(schema.userJobFamilyIndex.userId, userId));
  
  const userJobFamilyList = userJobFamilies.map(item => item.jobFamily);
  
  // For backward compatibility, check job roles directly if the index is empty
  if (userJobFamilyList.length === 0) {
    const userJobRoles = await db.select({
      jobFamily: schema.jobRoles.jobFamily
    })
    .from(schema.userJobRoles)
    .innerJoin(schema.jobRoles, eq(schema.userJobRoles.jobRoleId, schema.jobRoles.id))
    .where(eq(schema.userJobRoles.userId, userId));
    
    userJobFamilyList.push(...userJobRoles.map(item => item.jobFamily ?? "Other"));
    
    // If still empty, check legacy job role
    if (userJobFamilyList.length === 0 && user.jobRoleId) {
      const legacyRole = await db.query.jobRoles.findFirst({
        where: eq(schema.jobRoles.id, user.jobRoleId),
      });
      
      if (legacyRole?.jobFamily) {
        userJobFamilyList.push(legacyRole.jobFamily);
      }
    }
  }
  
  console.log(`User job families: ${userJobFamilyList.join(', ')}`);
  
  // PHASE 1: FAST FILTERING
  // Find jobs with matching language and job family requirements
  // This query does an efficient pre-filtering before the expensive AI matching
  const potentialMatches = await db.select({
    jobId: schema.jobs.id
  })
  .from(schema.jobs)
  .innerJoin(schema.jobLanguageIndex, eq(schema.jobs.id, schema.jobLanguageIndex.jobId))
  .innerJoin(schema.jobFamilyIndex, eq(schema.jobs.id, schema.jobFamilyIndex.jobId))
  .where(
    and(
      // Don't include jobs created by the current user
      sql`${schema.jobs.employerId} != ${userId}`,
      
      // Job must be in an active status
      eq(schema.jobs.status, "active"),
      
      // Job must require a language the user knows
      inArray(schema.jobLanguageIndex.language, userLanguageList),
      
      // Job must be in a job family the user belongs to
      inArray(schema.jobFamilyIndex.jobFamily, userJobFamilyList)
    )
  )
  .groupBy(schema.jobs.id);
  
  const eligibleJobIds = potentialMatches.map(match => match.jobId);
  console.log(`Fast filtering found ${eligibleJobIds.length} potential matches out of ~${await db.select({ count: sql<number>`count(*)` }).from(schema.jobs)}`);
  
  if (eligibleJobIds.length === 0) {
    console.timeEnd('optimizedFindMatchingJobsForUser');
    return [];
  }
  
  // PHASE 2: DETAILED MATCHING
  // Now fetch the full job data for matches to perform detailed scoring
  const matchingJobs = await db.select()
    .from(schema.jobs)
    .where(inArray(schema.jobs.id, eligibleJobIds));
  
  // Get user skills for AI matching
  const userSkills = await db.select()
    .from(schema.skills)
    .innerJoin(schema.userSkills, eq(schema.skills.id, schema.userSkills.skillId))
    .where(eq(schema.userSkills.userId, userId));
  
  const userSkillNames = userSkills.map(skill => skill.skills.name);
  
  // Get user job roles for AI matching
  const userJobRoles = await db.select({
    role: schema.jobRoles
  })
  .from(schema.userJobRoles)
  .innerJoin(schema.jobRoles, eq(schema.userJobRoles.jobRoleId, schema.jobRoles.id))
  .where(eq(schema.userJobRoles.userId, userId));
  
  const userJobRoleNames = userJobRoles.map(userRole => userRole.role.name);
  
  // Get user availability for AI matching
  const userAvailability = await db.select()
    .from(schema.availabilitySlots)
    .where(eq(schema.availabilitySlots.userId, userId));
  
  // Convert to user-friendly format
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const userAvailabilitySummary = userAvailability.map(slot => 
    `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 (${slot.timeZone || 'UTC'})`
  ).join(', ');
  
  // Array to hold job matches with their match scores
  const jobMatches: { job: schema.Job; score: number }[] = [];
  
  // Process each job for detailed matching
  for (const job of matchingJobs) {
    try {
      // Get job role name
      let jobRoleName = '';
      if (job.jobRoleId) {
        const jobRole = await db.query.jobRoles.findFirst({
          where: eq(schema.jobRoles.id, job.jobRoleId)
        });
        if (jobRole) {
          jobRoleName = jobRole.name;
        }
      }
      
      // Get job skills
      const jobSkillIds = job.requiredSkills as number[] || [];
      const jobSkills: string[] = [];
      
      if (jobSkillIds.length > 0) {
        for (const skillId of jobSkillIds) {
          const skill = await db.query.skills.findFirst({
            where: eq(schema.skills.id, skillId)
          });
          if (skill) {
            jobSkills.push(skill.name);
          }
        }
      }
      
      // Parse required languages
      const jobLanguages = job.requiredLanguages ? job.requiredLanguages.split(',').map(lang => lang.trim()) : [];
      
      // Prepare availability data
      const jobAvailability = job.requiredAvailability as schema.JobAvailabilityRequirement[] || [];
      
      // Convert to user-friendly format that Claude can understand
      const jobAvailabilitySummary = jobAvailability.map(slot => {
        const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        return `${days[slot.dayOfWeek]} ${slot.startHour}:00-${slot.endHour}:00 (${slot.timeZone || 'UTC'})`;
      }).join(', ');
      
      // Use the AI service to calculate match score
      const aiMatch = await calculateAIJobMatchScore({
        // Job details
        jobTitle: job.title,
        jobDescription: job.description || '',
        jobSkills,
        jobHourlyRate: job.hourlyRate || '',
        jobCurrency: job.currency || 'USD',
        jobRequiredLanguages: jobLanguages,
        jobRoleName,
        jobAvailability: jobAvailabilitySummary,
        jobHoursPerWeek: job.hoursPerWeek || 0,
        jobFamily: job.jobFamily || "Other",
        jobMinSalary: job.minSalary ? Number(job.minSalary) : undefined,
        jobMaxSalary: job.maxSalary ? Number(job.maxSalary) : undefined,
        jobSalaryType: job.salaryType || 'hourly',
        
        // User details
        userJobRoles: userJobRoleNames,
        userSkills: userSkillNames,
        userLanguages: userLanguageList,
        userTimeZone: user.timeZone || 'UTC',
        userAvailability: userAvailabilitySummary,
        userPreferredHours: user.preferredHoursPerWeek || 0,
        userJobFamily: userJobFamilyList[0] || "Other",
        userMinSalary: user.minSalaryRequirement ? Number(user.minSalaryRequirement) : undefined,
        userMaxSalary: user.maxSalaryRequirement ? Number(user.maxSalaryRequirement) : undefined,
        userSalaryType: user.preferredSalaryType || 'hourly'
      });
      
      // Create match score from AI result
      const matchScore: JobMatchScore = {
        overallScore: aiMatch.matchScore,
        roleScore: aiMatch.keyFactors.roleMatch,
        skillsScore: aiMatch.keyFactors.skillsMatch,
        availabilityScore: aiMatch.keyFactors.availabilityMatch,
        skillsMatchPercentage: aiMatch.keyFactors.skillsMatch, // Use skill match score as percentage
        matchDetails: {
          // Traditional match details (can be empty for AI matching)
          matchedRoleId: 0,
          matchedSkillIds: [],
          requiredSkillsCount: jobSkills.length,
          matchedSkillsCount: 0, // Will be calculated differently by AI
          
          // AI-specific match details
          aiMatchExplanation: aiMatch.matchExplanation,
          aiStrengths: aiMatch.strengths,
          aiGaps: aiMatch.gaps,
          aiLanguageMatch: aiMatch.keyFactors.languageMatch,
          jobFamilyMatch: (aiMatch.keyFactors.jobFamilyMatch || 0) > 0,
          aiCompensationMatch: aiMatch.keyFactors.compensationMatch
        }
      };
      
      // Enhanced minimum threshold criteria
      // 1. Check for poor role compatibility AND poor skills match
      const lowRoleScore = matchScore.roleScore < 40; // Role score below 40 is very low
      const lowSkillsScore = matchScore.skillsMatchPercentage < 30; // Skills match below 30% is very low
      
      // If both role and skills matches are poor, filter out the job entirely
      if (lowRoleScore && lowSkillsScore) {
        console.log(`Job ${job.id} (${job.title}) skipped due to both low role score (${matchScore.roleScore}) and low skills match (${matchScore.skillsMatchPercentage}%)`);
        continue;
      }
      
      // For jobs that pass both language requirement and role/skills minimums
      // We still check overall score as a final filter
      if (matchScore.overallScore > 30) { // Increased from 20 to 30 for better quality matches
        // Create a new job object with matchScore added
        const jobWithScore = {
          ...job,
          matchScore
        };
        jobMatches.push({ job: jobWithScore, score: matchScore.overallScore });
      }
    } catch (error) {
      console.error(`Error calculating AI match for job ${job.id}:`, error);
      // If AI matching fails, skip this job
      continue;
    }
  }
  
  // Sort by score (highest first) and return just the jobs
  console.timeEnd('optimizedFindMatchingJobsForUser');
  return jobMatches.sort((a, b) => b.score - a.score).map(match => match.job);
}