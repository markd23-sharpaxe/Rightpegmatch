import Anthropic from '@anthropic-ai/sdk';
import { Message } from '@anthropic-ai/sdk/resources';

// The newest Anthropic model is "claude-3-7-sonnet-20250219" which was released February 24, 2025
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// Helper function to safely extract text from Anthropic response
function getTextFromResponse(response: Message): string {
  if (response.content && response.content.length > 0) {
    const contentBlock = response.content[0];
    if ('type' in contentBlock && contentBlock.type === 'text' && 'text' in contentBlock) {
      return contentBlock.text;
    }
  }
  return '';
}

// Helper function to safely parse JSON from Claude's response
function parseResponseJson<T>(content: string, defaultValue: T): T {
  try {
    let jsonContent = content;
    
    // Look for JSON in markdown code blocks (```json ... ```)
    const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
    if (jsonBlockMatch && jsonBlockMatch[1]) {
      jsonContent = jsonBlockMatch[1];
    }
    
    // Try to parse the extracted JSON
    return JSON.parse(jsonContent) as T;
  } catch (parseError) {
    console.error("Error parsing Claude response:", parseError);
    console.error("Raw content:", content);
    return defaultValue;
  }
}

export interface SkillSuggestion {
  name: string;
  description: string;
  relevanceScore: number;
}

export interface JobRoleMatch {
  roleId: number;
  roleName: string;
  matchScore: number;
  reasonForMatch: string;
}

export interface AIJobMatchResult {
  matchScore: number;
  matchExplanation: string;
  strengths: string[];
  gaps: string[];
  keyFactors: {
    languageMatch: number;
    jobFamilyMatch?: number;
    roleMatch: number;
    skillsMatch: number;
    availabilityMatch: number;
    compensationMatch: number;
    qualificationsMatch: number; // Overall qualifications match score
    requiredQualificationsMatch: number; // Required qualifications match score
    optionalQualificationsMatch: number; // Optional qualifications match score
  };
}

/**
 * Suggests skills based on a job role
 */
export async function suggestSkillsForJobRole(
  jobRoleName: string, 
  jobRoleCategory: string,
  existingSkills: string[] = []
): Promise<SkillSuggestion[]> {
  try {
    const existingSkillsText = existingSkills.length > 0 
      ? `The user already has these skills: ${existingSkills.join(', ')}. Don't duplicate these.` 
      : '';
    
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1000,
      system: `You are a career advisor with expertise in professional skill recommendations. 
      When given a job role, suggest relevant technical and soft skills that would make someone successful in that role.
      Focus on the most important and practical skills for the modern workplace.
      For each skill, provide a brief description explaining why it's valuable for the role.
      Also include a relevance score from 1-10 for each skill.
      Format your response as a valid JSON array with objects having "name", "description", and "relevanceScore" fields.
      Suggest 5-10 skills, focusing on quality over quantity.
      ${existingSkillsText}`,
      messages: [
        {
          role: 'user',
          content: `Suggest skills for a ${jobRoleName} in the ${jobRoleCategory} category.`
        }
      ]
    });

    // Parse the JSON response from Claude
    try {
      const content = getTextFromResponse(response);
      if (!content) {
        console.error("Failed to get text from Claude response");
        return [];
      }
      
      // First, try to extract JSON from the content if it contains markdown code blocks
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as SkillSuggestion[];
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", getTextFromResponse(response));
      return [];
    }
  } catch (error) {
    console.error("Error suggesting skills:", error);
    return [];
  }
}

/**
 * Analyzes job requirements and suggests potential matches
 */
export async function analyzeJobRequirements(
  jobTitle: string,
  description: string,
  requiredSkills: string[]
): Promise<{ keywords: string[], summary: string }> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 800,
      system: `You are an AI recruitment specialist that helps analyze job requirements. 
      Extract key information from job descriptions to help match candidates with the right opportunities.
      Format your response as valid JSON with "keywords" (array of strings) and "summary" (string) fields.`,
      messages: [
        {
          role: 'user',
          content: `Analyze this job: 
          
          Title: ${jobTitle}
          Description: ${description}
          Required Skills: ${requiredSkills.join(', ')}
          
          Extract keywords, and provide a concise summary of the ideal candidate for this role.`
        }
      ]
    });

    // Parse the JSON response from Claude
    try {
      const content = getTextFromResponse(response);
      if (!content) {
        console.error("Failed to get text from Claude response");
        return { keywords: [], summary: "" };
      }
      
      // First, try to extract JSON from the content if it contains markdown code blocks
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as { keywords: string[], summary: string };
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", getTextFromResponse(response));
      return { keywords: [], summary: "" };
    }
  } catch (error) {
    console.error("Error analyzing job requirements:", error);
    return { keywords: [], summary: "" };
  }
}

/**
 * Evaluates a candidate profile against a job
 */
export async function evaluateCandidateJobMatch(
  jobTitle: string,
  jobDescription: string,
  jobRequiredSkills: string[],
  candidateRoles: string[],
  candidateSkills: string[],
  candidateExperience?: string
): Promise<{ matchScore: number, strengths: string[], gaps: string[], summary: string }> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1000,
      system: `You are an AI-powered job matching specialist that evaluates how well a candidate's profile matches a job.
      Analyze the candidate's experience, skills, and roles against the job requirements.
      Provide a match score from 0-100, identify strengths and improvement areas, and give a summary.
      Format your response as valid JSON with "matchScore" (number), "strengths" (array of strings), "gaps" (array of strings), and "summary" (string) fields.`,
      messages: [
        {
          role: 'user',
          content: `Evaluate this candidate for the job:
          
          JOB:
          Title: ${jobTitle}
          Description: ${jobDescription}
          Required Skills: ${jobRequiredSkills.join(', ')}
          
          CANDIDATE:
          Roles: ${candidateRoles.join(', ')}
          Skills: ${candidateSkills.join(', ')}
          Experience: ${candidateExperience || 'Not specified'}
          
          How well does this candidate match the job requirements?`
        }
      ]
    });

    // Parse the JSON response from Claude
    try {
      const content = getTextFromResponse(response);
      if (!content) {
        console.error("Failed to get text from Claude response");
        return { 
          matchScore: 0, 
          strengths: [], 
          gaps: [], 
          summary: "Failed to analyze match." 
        };
      }
      
      // First, try to extract JSON from the content if it contains markdown code blocks
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as { 
        matchScore: number, 
        strengths: string[], 
        gaps: string[], 
        summary: string 
      };
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", getTextFromResponse(response));
      return { 
        matchScore: 0, 
        strengths: [], 
        gaps: [], 
        summary: "Failed to analyze match." 
      };
    }
  } catch (error) {
    console.error("Error evaluating candidate match:", error);
    return { 
      matchScore: 0, 
      strengths: [], 
      gaps: [], 
      summary: "Failed to analyze match." 
    };
  }
}

/**
 * Analyzes a job description with AI and provides insights
 */
export async function analyzeJobDescription(
  jobDescription: string,
  jobTitle: string,
  userSkills: string[] = [],
  userJobRole: string = ""
): Promise<{ 
  keyRequirements: string[],
  relevantSkills: string[],
  fitScore: number,
  summary: string,
  advice: string
}> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1000,
      system: `You are an AI career advisor that analyzes job descriptions and provides insights.
      Extract key requirements and identify relevant skills that would make someone successful in this role.
      If user skills and job role are provided, analyze how well they match with the job.
      Format your response as valid JSON with "keyRequirements" (array of strings), "relevantSkills" (array of strings),
      "fitScore" (number from 0-100), "summary" (string), and "advice" (string) fields.`,
      messages: [
        {
          role: 'user',
          content: `Analyze this job:
          
          JOB TITLE: ${jobTitle}
          DESCRIPTION: ${jobDescription}
          
          ${userSkills.length > 0 ? `MY SKILLS: ${userSkills.join(", ")}` : ""}
          ${userJobRole ? `MY CURRENT ROLE: ${userJobRole}` : ""}
          
          What are the key requirements, what skills would be most valuable, ${userSkills.length > 0 ? "how well do I match," : ""} and what advice would you give?`
        }
      ]
    });

    // Parse the JSON response
    try {
      const content = getTextFromResponse(response);
      if (!content) {
        console.error("Failed to get text from Claude response");
        return { 
          keyRequirements: [],
          relevantSkills: [],
          fitScore: 0,
          summary: "Failed to analyze job description.",
          advice: "Please try again later."
        };
      }
      
      // First, try to extract JSON from the content if it contains markdown code blocks
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as { 
        keyRequirements: string[],
        relevantSkills: string[],
        fitScore: number,
        summary: string,
        advice: string
      };
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", getTextFromResponse(response));
      return { 
        keyRequirements: [],
        relevantSkills: [],
        fitScore: 0,
        summary: "Failed to analyze job description.",
        advice: "Please try again later."
      };
    }
  } catch (error) {
    console.error("Error analyzing job description:", error);
    return { 
      keyRequirements: [],
      relevantSkills: [],
      fitScore: 0,
      summary: "Failed to analyze job description.",
      advice: "Please try again later."
    };
  }
}

/**
 * Generates an explanation for why a job and candidate match or don't match
 */
export async function generateMatchingExplanation(
  jobTitle: string,
  jobRequirements: string,
  candidateSkills: string[],
  candidateRole: string,
  matchScore: number,
  jobFamily?: string,
  candidateJobFamily?: string
): Promise<string> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 600,
      system: `You are an AI job matching specialist that explains why candidates match or don't match specific job requirements.
      Provide clear, constructive explanations focusing on skill alignment, experience relevance, and potential areas for growth.
      Your tone should be professional but encouraging.
      
      VERY IMPORTANT: When explaining matches between candidates from one job family (e.g., Project Management) 
      and jobs from another family (e.g., Software Development), clearly explain:
      1. Whether the candidate has the necessary skills for the job despite coming from a different field
      2. Which specific skills qualify or disqualify them for the cross-family match
      3. How their background could be an advantage or disadvantage for the position`,
      messages: [
        {
          role: 'user',
          content: `Explain this job matching result:
          
          JOB: ${jobTitle}
          JOB REQUIREMENTS: ${jobRequirements}
          JOB FAMILY: ${jobFamily || 'Not specified'}
          
          CANDIDATE ROLE: ${candidateRole}
          CANDIDATE JOB FAMILY: ${candidateJobFamily || 'Not specified'}
          CANDIDATE SKILLS: ${candidateSkills.join(', ')}
          
          MATCH SCORE: ${matchScore}/100
          
          ${jobFamily && candidateJobFamily && jobFamily !== candidateJobFamily ? 
            `This is a cross-family match (${candidateJobFamily} → ${jobFamily}). Explain if the candidate has relevant skills for this field switch.` : 
            ''}
          
          Provide a clear, helpful explanation for why this match received this score, highlighting strengths and potential areas for improvement.`
        }
      ]
    });

    const content = getTextFromResponse(response);
    if (!content) {
      console.error("Failed to get text from Claude response");
      return "Unable to generate match explanation at this time.";
    }
    
    return content;
  } catch (error) {
    console.error("Error generating match explanation:", error);
    return "Unable to generate match explanation at this time.";
  }
}

/**
 * Enhances a job listing with AI-generated suggestions and improvements
 */
export async function enhanceJobListing(
  jobTitle: string,
  jobDescription: string,
  requiredSkills: string[] = [],
  targetAudience: string = "experienced professionals"
): Promise<{ 
  enhancedDescription: string,
  suggestedSkills: string[],
  improvementTips: string[],
  readabilityScore: number
}> {
  try {
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1500,
      system: `You are an expert job listing editor that helps employers create clear, compelling, and inclusive job descriptions.
      Analyze job listings for clarity, appeal, and effectiveness.
      Provide specific suggestions to improve the listing while maintaining its core requirements.
      Format your response as valid JSON with "enhancedDescription" (string with improved version), "suggestedSkills" (array of relevant skills to add),
      "improvementTips" (array of specific improvement suggestions), and "readabilityScore" (number from 0-100) fields.`,
      messages: [
        {
          role: 'user',
          content: `Enhance this job listing:
          
          JOB TITLE: ${jobTitle}
          DESCRIPTION: ${jobDescription}
          REQUIRED SKILLS: ${requiredSkills.join(', ')}
          TARGET AUDIENCE: ${targetAudience}
          
          Please provide an enhanced version, additional skills to consider, specific improvement tips, and a readability assessment.`
        }
      ]
    });

    const content = getTextFromResponse(response);
    if (!content) {
      console.error("Failed to get text from Claude response");
      return { 
        enhancedDescription: jobDescription,
        suggestedSkills: [],
        improvementTips: ["Could not generate improvements at this time."],
        readabilityScore: 0
      };
    }
    
    try {
      // First, try to extract JSON from the content if it contains markdown code blocks
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as { 
        enhancedDescription: string,
        suggestedSkills: string[],
        improvementTips: string[],
        readabilityScore: number
      };
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", content);
      return { 
        enhancedDescription: jobDescription,
        suggestedSkills: [],
        improvementTips: ["Could not parse AI suggestions."],
        readabilityScore: 0
      };
    }
  } catch (error) {
    console.error("Error enhancing job listing:", error);
    return { 
      enhancedDescription: jobDescription,
      suggestedSkills: [],
      improvementTips: ["An error occurred while enhancing the job listing."],
      readabilityScore: 0
    };
  }
}

/**
 * Suggests personalized skills based on job role and candidate information
 */
export async function suggestSkills(
  jobRole: string,
  bio: string = "",
  existingSkills: string[] = []
): Promise<SkillSuggestion[]> {
  try {
    const existingSkillsText = existingSkills.length > 0 
      ? `The candidate already has these skills: ${existingSkills.join(', ')}. Don't duplicate these.` 
      : 'The candidate has not specified any existing skills.';
    
    const bioContext = bio 
      ? `Here's some information about the candidate: ${bio}` 
      : 'No additional information about the candidate provided.';
    
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1000,
      system: `You are a career advisor specializing in professional skill recommendations.
      Your task is to suggest personalized skills for candidates based on their target job role, any existing skills, and biographical information.
      Focus on both technical and soft skills that would make the candidate more competitive for their target role.
      For each skill, provide a brief description explaining why it's valuable and a relevance score from 1-10.
      Format your response as a valid JSON array with objects having "name", "description", and "relevanceScore" fields.
      Suggest 5-10 high-quality, specific skills that would genuinely help the candidate.`,
      messages: [
        {
          role: 'user',
          content: `Suggest personalized skills for this candidate:
          
          TARGET JOB ROLE: ${jobRole}
          ${bioContext}
          ${existingSkillsText}
          
          Please suggest skills that would help this person succeed in their target role, considering their background.`
        }
      ]
    });

    const content = getTextFromResponse(response);
    if (!content) {
      console.error("Failed to get text from Claude response");
      return [];
    }
    
    try {
      // First, try to extract JSON from the content if it contains markdown code blocks
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as SkillSuggestion[];
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", content);
      return [];
    }
  } catch (error) {
    console.error("Error suggesting personalized skills:", error);
    return [];
  }
}

/**
 * Suggests skills for multiple job roles (primarily used for onboarding)
 */
export async function suggestSkillsForMultipleJobRoles(
  jobRoles: { name: string, category: string }[]
): Promise<SkillSuggestion[]> {
  try {
    if (!jobRoles.length) return [];
    
    const roleDescriptions = jobRoles.map(role => 
      `${role.name} (${role.category})`
    ).join(', ');
    
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1200,
      system: `You are a career advisor with expertise in professional skill recommendations.
      Based on multiple job roles, suggest relevant technical and soft skills that would make someone successful across these roles.
      Focus on the most important and practical skills for the modern workplace, prioritizing transferable skills.
      For each skill, provide a brief description explaining why it's valuable across the roles.
      Also include a relevance score from 1-10 for each skill.
      Format your response as a valid JSON array with objects having "name", "description", and "relevanceScore" fields.
      Suggest 7-12 skills, focusing on quality over quantity.`,
      messages: [
        {
          role: 'user',
          content: `Suggest skills for someone interested in these job roles: ${roleDescriptions}.
          
          Focus on skills that would be transferable and valuable across all or most of these roles.`
        }
      ]
    });

    const content = getTextFromResponse(response);
    if (!content) {
      console.error("Failed to get text from Claude response");
      return [];
    }
    
    try {
      // First, try to extract JSON from the content if it contains markdown code blocks
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as SkillSuggestion[];
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", content);
      return [];
    }
  } catch (error) {
    console.error("Error suggesting skills for multiple roles:", error);
    return [];
  }
}

/**
 * Calculates AI-powered job match score between a job and a candidate
 * This replaces the previous algorithm-based matching system with intelligent
 * matching that accounts for language, pay, job title, skills, and availability
 */
import { areSalariesCompatible } from "@shared/currency-utils";

export async function calculateAIJobMatchScore(params: {
  // Job details
  jobTitle: string;
  jobDescription: string;
  jobSkills: string[];
  jobHourlyRate?: string;
  jobCurrency?: string;
  jobRequiredLanguages: string[];
  jobRoleName: string;
  jobAvailability: string;
  jobHoursPerWeek: number;
  jobFamily?: string;
  jobMinSalary?: number;
  jobMaxSalary?: number;
  jobSalaryType?: string;
  jobRequiredQualifications?: string[]; // Required qualifications
  jobOptionalQualifications?: string[]; // Optional qualifications
  
  // User details
  userJobRoles: string[];
  userSkills: string[];
  userLanguages: string[];
  userTimeZone: string;
  userAvailability: string;
  userPreferredHours: number;
  userJobFamily?: string;
  userMinSalary?: number;
  userMaxSalary?: number;
  userSalaryType?: string;
  userCurrency?: string;
  userQualifications?: string[]; // User qualifications
}
): Promise<AIJobMatchResult> {
  try {
    // Extract parameters for easier reference
    const {
      jobTitle, 
      jobDescription, 
      jobSkills, 
      jobHourlyRate = '', 
      jobCurrency = 'USD', 
      jobRequiredLanguages,
      jobRoleName,
      jobAvailability,
      jobHoursPerWeek,
      jobFamily = 'Other',
      jobMinSalary,
      jobMaxSalary,
      jobSalaryType = 'hourly',
      jobRequiredQualifications = [],
      jobOptionalQualifications = [],
      
      userJobRoles,
      userSkills,
      userLanguages,
      userAvailability,
      userPreferredHours,
      userTimeZone,
      userJobFamily = 'Other',
      userMinSalary,
      userMaxSalary,
      userQualifications = [],
      userSalaryType = 'hourly',
      userCurrency = 'USD'
    } = params;
    
    // PART 1: LANGUAGE CHECK - Return early if user does not have all required languages
    // We're checking this before making the expensive API call
    const languageMatch = jobRequiredLanguages.every(jobLang => 
      userLanguages.some(userLang => userLang.toLowerCase() === jobLang.toLowerCase())
    );
    
    if (!languageMatch) {
      console.log(`Job ${jobTitle} skipped due to language mismatch (mandatory requirement)`);
      return {
        matchScore: 0,
        matchExplanation: "Required languages are not matched. This job requires specific language skills that are not listed in your profile.",
        strengths: [],
        gaps: [`Missing required languages: ${jobRequiredLanguages.join(', ')}`],
        keyFactors: {
          languageMatch: 0,
          jobFamilyMatch: userJobFamily === jobFamily ? 100 : 40,
          roleMatch: 0,
          skillsMatch: 0,
          availabilityMatch: 0,
          compensationMatch: 0,
          qualificationsMatch: 0,
          requiredQualificationsMatch: 0,
          optionalQualificationsMatch: 0
        }
      };
    }
    
    // PART 3: SALARY CHECK - Within 25% range check
    let salaryCompatible = true;
    let salaryCompatibilityNote = '';
    
    // Check salary compatibility if both min values are provided
    if (jobMinSalary && userMinSalary) {
      // Convert to same currency for comparison if needed
      // Convert both salaries to USD for comparison
      const jobMinConverted = jobMinSalary * (currencyExchangeRates[jobCurrency] || 1);
      const userMinConverted = userMinSalary * (currencyExchangeRates[userCurrency] || 1);
      
      console.log(`Comparing salaries: ${jobMinSalary} ${jobCurrency} (${jobMinConverted} USD) vs ${userMinSalary} ${userCurrency} (${userMinConverted} USD)`);
      
      // Calculate the lower and upper bounds of the 25% range
      const lowerBound = jobMinConverted * 0.75;
      const upperBound = jobMinConverted * 1.25;
      
      // Check if user's minimum salary is within 25% range of job's minimum
      if (userMinConverted < lowerBound || userMinConverted > upperBound) {
        salaryCompatible = false;
        salaryCompatibilityNote = `Salary expectations outside the acceptable range (±25%) for this position.`;
      }
    }
    
    // Check if max salary expectations align if both values provided
    if (salaryCompatible && userMaxSalary && jobMaxSalary) {
      const jobMaxConverted = jobMaxSalary; // Would need conversion in real implementation
      const userMaxConverted = userMaxSalary; // Would need conversion in real implementation
      
      // Calculate the lower and upper bounds of the 25% range
      const lowerBound = jobMaxConverted * 0.75;
      const upperBound = jobMaxConverted * 1.25;
      
      // Check if user's maximum salary is within 25% range of job's maximum
      if (userMaxConverted < lowerBound || userMaxConverted > upperBound) {
        salaryCompatible = false;
        salaryCompatibilityNote = `Salary expectations outside the acceptable range (±25%) for this position.`;
      }
    }
    
    // Format salary information with compatibility note
    let jobSalaryText = jobHourlyRate 
      ? `${jobHourlyRate} ${jobCurrency} per hour`
      : 'Not specified';
      
    // Add min/max salary information if available
    if (jobMinSalary || jobMaxSalary) {
      jobSalaryText = jobMinSalary && jobMaxSalary
        ? `${jobMinSalary.toLocaleString()}-${jobMaxSalary.toLocaleString()} ${jobCurrency} (${jobSalaryType})`
        : jobMinSalary
          ? `From ${jobMinSalary.toLocaleString()} ${jobCurrency} (${jobSalaryType})`
          : `Up to ${jobMaxSalary?.toLocaleString()} ${jobCurrency} (${jobSalaryType})`;
    }
      
    // Format candidate salary expectations
    let candidateSalaryText = 'Not specified';
    if (userMinSalary || userMaxSalary) {
      candidateSalaryText = userMinSalary && userMaxSalary
        ? `${userMinSalary.toLocaleString()}-${userMaxSalary.toLocaleString()} ${userCurrency} (${userSalaryType})`
        : userMinSalary
          ? `From ${userMinSalary.toLocaleString()} ${userCurrency} (${userSalaryType})`
          : `Up to ${userMaxSalary?.toLocaleString()} ${userCurrency} (${userSalaryType})`;
    }
    
    // Add salary compatibility note to candidateSalaryText if there's an issue
    if (salaryCompatibilityNote) {
      candidateSalaryText += ` (Note: ${salaryCompatibilityNote})`;
    }
    
    const response = await anthropic.messages.create({
      model: 'claude-3-7-sonnet-20250219',
      max_tokens: 1500,
      system: `You are an AI job matching system that analyzes how well a candidate matches a job, following a six-part matching framework:

      1. LANGUAGE MATCHING (BINARY REQUIREMENT):
         - Language match is MANDATORY - if the job requires ANY language the candidate doesn't have, overall score MUST be 0.
         - A score of 0 for language match should result in an overall score of 0, regardless of other factors.
         - This check has already been performed, so all candidates you evaluate PASS this requirement.
      
      2. AVAILABILITY MATCHING (PERCENTAGE TIERS):
         - Evaluate time availability overlap between job requirements and candidate availability.
         - Score on a scale of 50-100% with clear tiers:
           * 90-100%: Excellent availability match
           * 70-89%: Good availability match 
           * 50-69%: Sufficient availability match
           * Below 50%: Poor availability match (but not disqualifying)
         - Consider both total hours per week and specific time slots.
         - Account for timezone differences in your evaluation.
      
      3. SALARY MATCHING (25% RANGE):
         - Compensation expectations must be within 25% of job's offering.
         - If salary expectations are outside this range, significantly reduce the compensation match score.
         - A salary mismatch should reduce but not eliminate the overall match.
      
      4. JOB TITLE COMPATIBILITY:
         - Evaluate whether the candidate's job titles indicate they can effectively perform the advertised job.
         - Consider both exact matches and related/similar roles.
         - For cross-family matches (e.g., Project Manager applying for Developer), carefully evaluate transferable skills.
         - When job families are different, the title compatibility depends heavily on relevant skills.
      
      5. SKILLS ASSESSMENT:
         - Evaluate overlap between required job skills and candidate skills.
         - Skills enhance the match but should not be a strict requirement.
         - For cross-family roles, relevant skills are especially important.
         
      6. QUALIFICATIONS MATCHING:
         - Evaluate how well the candidate's qualifications match the job's required and optional qualifications.
         - Required qualifications should be weighted more heavily than optional qualifications.
         - A low match on required qualifications should significantly reduce the overall match score.
         - Optional qualifications can enhance the match but are not required.
      
      Format your response as valid JSON with these fields:
      - matchScore: Overall match percentage (0-100)
      - matchExplanation: Detailed explanation of the match result
      - strengths: Array of specific strengths/matches
      - gaps: Array of specific gaps/mismatches
      - keyFactors: Object with individual factor scores (0-100):
        - languageMatch: How well languages match (0 means no match and disqualifies candidate)
        - jobFamilyMatch: How well job families match (high priority in scoring)
        - roleMatch: How well job roles match
        - skillsMatch: How well skills match
        - availabilityMatch: How well availability matches
        - compensationMatch: How well compensation expectations match
        - qualificationsMatch: Overall qualification matching score
        - requiredQualificationsMatch: How well required qualifications match
        - optionalQualificationsMatch: How well optional qualifications match`,
      messages: [
        {
          role: 'user',
          content: `Evaluate this job match:
          
          JOB:
          Title: ${params.jobTitle}
          Description: ${params.jobDescription}
          Job Role: ${params.jobRoleName}
          Job Family: ${jobFamily}
          Required Skills: ${params.jobSkills.join(', ')}
          Required Languages: ${params.jobRequiredLanguages.join(', ')}
          Required Qualifications: ${jobRequiredQualifications.length > 0 ? jobRequiredQualifications.join(', ') : 'None specified'}
          Optional Qualifications: ${jobOptionalQualifications.length > 0 ? jobOptionalQualifications.join(', ') : 'None specified'}
          Salary Range: ${jobSalaryText}
          Availability Requirements: ${params.jobAvailability}
          Min Hours Per Week: ${params.jobHoursPerWeek || 'Not specified'}
          
          CANDIDATE:
          Roles: ${params.userJobRoles.join(', ')}
          Job Family: ${userJobFamily}
          Skills: ${params.userSkills.join(', ')}
          Qualifications: ${userQualifications.length > 0 ? userQualifications.join(', ') : 'None specified'}
          Languages: ${params.userLanguages.join(', ')}
          Availability: ${params.userAvailability}
          Hours Per Week: ${params.userPreferredHours || 'Not specified'}
          Time Zone: ${params.userTimeZone}
          Salary Expectation: ${candidateSalaryText}
          
          The candidate has PASSED the language requirement check.
          ${!salaryCompatible ? 'NOTE: The candidate\'s salary expectations are outside the 25% range of the job\'s offering.' : ''}
          
          Provide a comprehensive evaluation focusing on the five-part matching framework:
          1. Language match: Already verified (100% match)
          2. Availability matching (50-100% scale with quality tiers)
          3. Salary compatibility (within 25% range)
          4. Job title compatibility (can they perform this job based on their experience?)
          5. Skills assessment
          
          For cross-family role matches:
          - Analyze if they have transferable skills that qualify them
          - If they have relevant skills, adjust their match score accordingly
          - If they lack relevant skills for the job family, reduce the match score
          
          Provide qualitative assessment with clear explanation rather than just numerical scores.`
        }
      ]
    });

    const content = getTextFromResponse(response);
    if (!content) {
      console.error("Failed to get text from Claude response");
      return {
        matchScore: 0,
        matchExplanation: "Failed to analyze match.",
        strengths: [],
        gaps: ["Unable to process job match at this time"],
        keyFactors: {
          languageMatch: 0,
          jobFamilyMatch: 0,
          roleMatch: 0,
          skillsMatch: 0,
          availabilityMatch: 0,
          compensationMatch: 0,
          qualificationsMatch: 0,
          requiredQualificationsMatch: 0,
          optionalQualificationsMatch: 0
        }
      };
    }
    
    try {
      // Extract and parse JSON
      let jsonContent = content;
      
      // Look for JSON in markdown code blocks (```json ... ```)
      const jsonBlockMatch = content.match(/```(?:json)?\s*\n?([\s\S]*?)\n?```/);
      if (jsonBlockMatch && jsonBlockMatch[1]) {
        jsonContent = jsonBlockMatch[1];
      }
      
      // Try to parse the extracted JSON
      return JSON.parse(jsonContent) as AIJobMatchResult;
    } catch (parseError) {
      console.error("Error parsing Claude response:", parseError);
      console.error("Raw content:", content);
      return {
        matchScore: 0,
        matchExplanation: "Failed to parse match results.",
        strengths: [],
        gaps: ["Error processing match data"],
        keyFactors: {
          languageMatch: 0,
          jobFamilyMatch: 0,
          roleMatch: 0,
          skillsMatch: 0,
          availabilityMatch: 0,
          compensationMatch: 0,
          qualificationsMatch: 0,
          requiredQualificationsMatch: 0,
          optionalQualificationsMatch: 0
        }
      };
    }
  } catch (error) {
    console.error("Error calculating AI job match score:", error);
    
    // Check if the error is related to API credit balance
    const errorMessage = error instanceof Error ? error.message : String(error);
    const isCreditBalanceError = errorMessage.includes("credit balance is too low");
    
    if (isCreditBalanceError) {
      console.log("Credit balance error detected, using fallback matching algorithm");
      
      // Make sure jobFamily is always a string by providing default value
      const paramsWithDefaults = {
        ...params,
        jobFamily: params.jobFamily || "Other"
      };
      
      return calculateFallbackJobMatchScore(paramsWithDefaults);
    }
    
    return {
      matchScore: 0,
      matchExplanation: "An error occurred while analyzing this match.",
      strengths: [],
      gaps: ["System error while processing match"],
      keyFactors: {
        languageMatch: 0,
        jobFamilyMatch: 0,
        roleMatch: 0,
        skillsMatch: 0,
        availabilityMatch: 0,
        compensationMatch: 0,
        qualificationsMatch: 0,
        requiredQualificationsMatch: 0,
        optionalQualificationsMatch: 0
      }
    };
  }
}

/**
 * A fallback job matching algorithm that uses simple heuristics when the AI API is unavailable
 */
export function calculateFallbackJobMatchScore(params: {
  // Job details
  jobTitle: string;
  jobDescription: string;
  jobSkills: string[];
  jobHourlyRate?: string;
  jobCurrency?: string;
  jobRequiredLanguages: string[];
  jobRoleName: string;
  jobAvailability: string;
  jobHoursPerWeek: number;
  jobFamily: string; // This is now a required string
  jobMinSalary?: number;
  jobMaxSalary?: number;
  jobSalaryType?: string;
  jobRequiredQualifications?: string[]; // Required qualifications
  jobOptionalQualifications?: string[]; // Optional qualifications
  
  // User details
  userJobRoles: string[];
  userSkills: string[];
  userLanguages: string[];
  userAvailability: string;
  userPreferredHours: number;
  userTimeZone?: string;
  userJobFamily?: string;
  userMinSalary?: number;
  userMaxSalary?: number;
  userSalaryType?: string;
  userCurrency?: string;
  userQualifications?: string[]; // User qualifications
}): AIJobMatchResult {
  const {
    // Job details
    jobTitle,
    jobSkills,
    jobRequiredLanguages,
    jobRoleName,
    jobHoursPerWeek,
    jobFamily,
    jobCurrency = 'USD',
    jobMinSalary,
    jobMaxSalary,
    jobRequiredQualifications = [],
    jobOptionalQualifications = [],
    
    // User details
    userJobRoles,
    userSkills,
    userLanguages,
    userQualifications = [],
    userPreferredHours,
    userJobFamily,
    userCurrency = 'USD',
    userMinSalary,
    userMaxSalary
  } = params;
  
  // Initialize strengths and gaps arrays that will be populated throughout the process
  const strengths: string[] = [];
  const gaps: string[] = [];
  
  // PART 1: LANGUAGE MATCHING (BINARY REQUIREMENT)
  // Check if user has ALL the required languages for the job
  const languageMatch = jobRequiredLanguages.every(jobLang => 
    userLanguages.some(userLang => userLang.toLowerCase() === jobLang.toLowerCase())
  );
  
  // If language match fails, return zero match immediately
  if (!languageMatch) {
    return {
      matchScore: 0,
      matchExplanation: "Required languages are not matched. This job requires specific language skills that are not listed in your profile.",
      strengths: [],
      gaps: [`Missing required languages: ${jobRequiredLanguages.join(', ')}`],
      keyFactors: {
        languageMatch: 0,
        jobFamilyMatch: userJobFamily === jobFamily ? 100 : 40,
        roleMatch: 0,
        skillsMatch: 0,
        availabilityMatch: 0,
        compensationMatch: 0,
        qualificationsMatch: 0,
        requiredQualificationsMatch: 0,
        optionalQualificationsMatch: 0
      }
    };
  }
  
  // Add language match as strength since we passed the check
  strengths.push(`You have all the required languages for this position (${jobRequiredLanguages.join(', ')})`);
  
  // PART 2: AVAILABILITY MATCHING (PERCENTAGE TIERS 50-100%)
  // Calculate availability match score with tiers
  let availabilityMatchScore = 0;
  
  // Basic hours per week compatibility (normalized between 50-100%)
  const rawHoursMatchScore = Math.min(userPreferredHours, jobHoursPerWeek) / Math.max(userPreferredHours, jobHoursPerWeek);
  availabilityMatchScore = 50 + (rawHoursMatchScore * 50); // Scale from 50-100%
  
  // Assign tier label based on score
  let availabilityTier = "";
  if (availabilityMatchScore >= 90) {
    availabilityTier = "Excellent";
    strengths.push(`Your availability aligns extremely well with the job's requirements`);
  } else if (availabilityMatchScore >= 70) {
    availabilityTier = "Good";
    strengths.push(`Your availability aligns well with the job's requirements`);
  } else if (availabilityMatchScore >= 50) {
    availabilityTier = "Sufficient";
    gaps.push(`Your availability (${userPreferredHours} hrs/week) only partially matches job requirements (${jobHoursPerWeek} hrs/week)`);
  } else {
    availabilityTier = "Poor";
    gaps.push(`Your availability (${userPreferredHours} hrs/week) has significant conflicts with job requirements (${jobHoursPerWeek} hrs/week)`);
  }
  
  // PART 3: SALARY MATCHING (25% RANGE)
  let compensationMatchScore = 100; // Default perfect score
  
  // Check salary compatibility if both min values are provided
  if (jobMinSalary && userMinSalary) {
    // Convert to same currency for comparison if needed
    const jobMinConverted = jobMinSalary; // Would need conversion in real implementation
    const userMinConverted = userMinSalary; // Would need conversion in real implementation
    
    // Calculate the lower and upper bounds of the 25% range
    const lowerBound = jobMinConverted * 0.75;
    const upperBound = jobMinConverted * 1.25;
    
    // Check if user's minimum salary is within 25% range of job's minimum
    if (userMinConverted < lowerBound || userMinConverted > upperBound) {
      compensationMatchScore = 60; // Reduce score for being outside the 25% range
      gaps.push(`Your salary expectations are outside the acceptable range (±25%) for this position`);
    } else {
      strengths.push(`Your salary expectations align with this job's compensation range`);
    }
  }
  
  // Check if max salary expectations align if both values provided
  if (compensationMatchScore === 100 && userMaxSalary && jobMaxSalary) {
    const jobMaxConverted = jobMaxSalary; // Would need conversion in real implementation
    const userMaxConverted = userMaxSalary; // Would need conversion in real implementation
    
    // Calculate the lower and upper bounds of the 25% range
    const lowerBound = jobMaxConverted * 0.75;
    const upperBound = jobMaxConverted * 1.25;
    
    // Check if user's maximum salary is within 25% range of job's maximum
    if (userMaxConverted < lowerBound || userMaxConverted > upperBound) {
      compensationMatchScore = 60; // Reduce score for being outside the 25% range
      gaps.push(`Your salary expectations are outside the acceptable range (±25%) for this position`);
    } else if (!gaps.some(gap => gap.includes("salary expectations"))) {
      strengths.push(`Your salary expectations align with this job's compensation range`);
    }
  }
  
  // PART 4: JOB TITLE COMPATIBILITY
  let roleMatchScore = 0;
  
  // Check job family match first as a gating factor
  const sameJobFamily = userJobFamily === jobFamily;
  
  // First check for exact title match - this should give perfect score
  const exactTitleMatch = userJobRoles.some(role => 
    role.toLowerCase() === jobTitle.toLowerCase() || 
    role.toLowerCase() === jobRoleName.toLowerCase()
  );
  
  // If job families are different, apply stricter matching criteria
  if (!sameJobFamily) {
    // User has specified they want to be strict with cross-family matches
    // Only give a significant score if there's an exact title match
    if (exactTitleMatch) {
      roleMatchScore = 70; // Even with exact title match, cap score at 70 for different job families
      strengths.push(`You have the exact job title, but in a different job family`);
    } else {
      roleMatchScore = 15; // Very low score for different family without exact title match
      gaps.push(`Your job family (${userJobFamily}) is different from this job's family (${jobFamily})`);
    }
  } else {
    // Same job family - proceed with normal scoring
    if (exactTitleMatch) {
      roleMatchScore = 100; // Perfect match for exact same title in same family
      strengths.push(`Your job role is an exact match for this position`);
    } else if (userJobRoles.some(role => role.toLowerCase() === jobRoleName.toLowerCase())) {
      roleMatchScore = 100; // Exact match by role name in same family
      strengths.push(`Your job role is an exact match for this position`);
    } else {
      // Simple partial match for related roles within same family
      const jobTitleLower = jobTitle.toLowerCase();
      const roleMatches = userJobRoles.some(role => 
        jobTitleLower.includes(role.toLowerCase()) || 
        role.toLowerCase().includes(jobTitleLower)
      );
      
      // Only consider partial matches within the same job family
      if (roleMatches) {
        roleMatchScore = 85; // Good match for similar title in same family
        strengths.push(`Your job role is well aligned with this position`);
      } else {
        roleMatchScore = 60; // Basic match just for being in same job family
        strengths.push(`Your job role has some alignment with this position within the same job family`);
      }
    }
  }
  
  // PART 5: SKILLS ASSESSMENT
  const relevantUserSkills = userSkills.filter(skill => 
    jobSkills.some(jobSkill => jobSkill.toLowerCase() === skill.toLowerCase())
  );
  
  // Calculate raw score as percentage of matching skills
  let skillsMatchScoreRaw = jobSkills.length > 0 
    ? (relevantUserSkills.length / jobSkills.length) * 100
    : 50; // Default if no skills specified
  
  // Ensure score is within 0-100 range
  const skillsMatchScore = Math.min(100, Math.max(0, skillsMatchScoreRaw));
  
  // Add skills match information to strengths/gaps
  if (skillsMatchScore > 70) {
    strengths.push(`You have many of the skills required for this job (${Math.round(skillsMatchScore)}% match)`);
  } else if (skillsMatchScore > 30) {
    gaps.push(`You have some skills for this job but are missing others (${Math.round(skillsMatchScore)}% match)`);
  } else {
    gaps.push(`You're missing many of the skills required for this job (${Math.round(skillsMatchScore)}% match)`);
  }
  
  // We're no longer boosting cross-family matches based on skills
  // This ensures job family is a stronger dividing line between matches
  
  // PART 6: QUALIFICATIONS ASSESSMENT
  // Calculate required qualifications match
  const matchedRequiredQualifications = jobRequiredQualifications.filter(reqQual => 
    userQualifications.some(userQual => userQual.toLowerCase() === reqQual.toLowerCase())
  );
  
  // Calculate optional qualifications match
  const matchedOptionalQualifications = jobOptionalQualifications.filter(optQual => 
    userQualifications.some(userQual => userQual.toLowerCase() === optQual.toLowerCase())
  );
  
  // Calculate matching scores
  const requiredQualMatchPercentage = jobRequiredQualifications.length > 0 
    ? (matchedRequiredQualifications.length / jobRequiredQualifications.length) * 100
    : 100; // If no required qualifications, user meets all requirements
    
  const optionalQualMatchPercentage = jobOptionalQualifications.length > 0 
    ? (matchedOptionalQualifications.length / jobOptionalQualifications.length) * 100
    : 0; // If no optional qualifications, no bonus points
  
  // Required qualifications have higher weight than optional
  const qualificationsMatchScore = jobRequiredQualifications.length > 0 || jobOptionalQualifications.length > 0
    ? (requiredQualMatchPercentage * 0.7) + (optionalQualMatchPercentage * 0.3)
    : 50; // Default if no qualifications specified
  
  // Add to strengths/gaps based on qualification match
  if (jobRequiredQualifications.length > 0) {
    if (requiredQualMatchPercentage === 100) {
      strengths.push(`You meet all ${jobRequiredQualifications.length} required qualifications for this job`);
    } else if (requiredQualMatchPercentage >= 70) {
      strengths.push(`You meet most of the required qualifications for this job`);
    } else if (requiredQualMatchPercentage > 0) {
      gaps.push(`You're missing ${jobRequiredQualifications.length - matchedRequiredQualifications.length} out of ${jobRequiredQualifications.length} required qualifications`);
    } else {
      gaps.push(`You don't meet any of the required qualifications for this job`);
    }
  }
  
  if (jobOptionalQualifications.length > 0 && optionalQualMatchPercentage > 0) {
    strengths.push(`You have ${matchedOptionalQualifications.length} out of ${jobOptionalQualifications.length} preferred qualifications for this job`);
  }
  
  // Calculate overall score - weighted sum of different factors based on the six-part framework
  const weights = {
    // Language already checked (binary requirement)
    jobTitleCompatibility: 0.30, // Part 4 
    skillsMatch: 0.25, // Part 5
    availabilityMatch: 0.15, // Part 2
    compensationMatch: 0.10, // Part 3
    qualificationsMatch: 0.20 // Part 6
  };
  
  // Initial weighted score calculation
  let initialScore = 
    (weights.jobTitleCompatibility * roleMatchScore) + 
    (weights.skillsMatch * skillsMatchScore) + 
    (weights.availabilityMatch * availabilityMatchScore) + 
    (weights.compensationMatch * compensationMatchScore) +
    (weights.qualificationsMatch * qualificationsMatchScore);
  
  // For exact role matches with good skills match, ensure the score is at least 95
  // This ensures Project Manager matching with Project Manager job gets a top score
  if (exactTitleMatch && skillsMatchScore > 70 && sameJobFamily) {
    initialScore = Math.max(initialScore, 95);
  }
  
  // For different job families, cap the score to prevent cross-family matches
  if (!sameJobFamily) {
    // Cap score at 50 for different job families - this makes these jobs show up lower in results
    initialScore = Math.min(initialScore, 50);
  }
  
  // Round the final score
  const overallScore = Math.round(initialScore);
  
  // Format match explanation based on overall score
  let matchExplanation = '';
  if (overallScore >= 85) {
    matchExplanation = "Strong Match: Your profile is highly compatible with this job's requirements.";
  } else if (overallScore >= 70) {
    matchExplanation = "Good Match: Your profile shows good alignment with this job's core requirements.";
  } else if (overallScore >= 50) {
    matchExplanation = "Partial Match: You meet some of this job's requirements, but there are significant gaps.";
  } else {
    matchExplanation = "Limited Match: There's limited alignment between your profile and this job's requirements.";
  }
  
  // Return the result
  return {
    matchScore: overallScore,
    matchExplanation,
    strengths,
    gaps,
    keyFactors: {
      languageMatch: languageMatch ? 100 : 0,
      jobFamilyMatch: sameJobFamily ? 100 : 10, // Much lower score for different job families
      roleMatch: roleMatchScore,
      skillsMatch: skillsMatchScore,
      availabilityMatch: availabilityMatchScore,
      compensationMatch: compensationMatchScore,
      qualificationsMatch: qualificationsMatchScore,
      requiredQualificationsMatch: requiredQualMatchPercentage,
      optionalQualificationsMatch: optionalQualMatchPercentage
    }
  };
}