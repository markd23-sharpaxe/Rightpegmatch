/**
 * Stripe Webhook Handler Service
 * 
 * This service handles Stripe webhook events for production use with proper
 * signature verification for enhanced security.
 */

import Stripe from 'stripe';
import { IStorage } from '../storage';

// Initialize Stripe
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe environment variable: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-02-19', // Latest stable API version as of May 2025
});

/**
 * Verifies and processes a Stripe webhook event
 * @param body The raw request body (must be in buffer/string format, not parsed JSON)
 * @param signature The stripe-signature header
 * @param storage The storage interface
 */
export async function handleStripeWebhook(
  body: string | Buffer,
  signature: string | undefined,
  storage: IStorage
): Promise<{ success: boolean; message: string }> {
  if (!signature) {
    return { 
      success: false, 
      message: 'Missing Stripe signature header' 
    };
  }

  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    console.warn('STRIPE_WEBHOOK_SECRET is not set - webhook verification disabled');
    // Allow processing without verification in development
    const event = JSON.parse(body.toString()) as Stripe.Event;
    return processStripeEvent(event, storage);
  }

  try {
    // Verify the event with Stripe's signature
    const event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET
    );
    
    return processStripeEvent(event, storage);
  } catch (error) {
    console.error('Stripe webhook verification failed:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Unknown webhook error'
    };
  }
}

/**
 * Process a verified Stripe event
 */
async function processStripeEvent(
  event: Stripe.Event,
  storage: IStorage
): Promise<{ success: boolean; message: string }> {
  console.log('Processing Stripe webhook event:', event.type);
  
  try {
    switch (event.type) {
      case 'invoice.payment_failed': {
        // Handle failed payment
        const invoice = event.data.object as Stripe.Invoice;
        const subscriptionId = invoice.subscription as string;
        const customerId = invoice.customer as string;
        
        console.log(`Payment failed for subscription ${subscriptionId}, customer ${customerId}`);
        
        // Find the user subscription with this Stripe subscription ID
        const subscription = await storage.getUserSubscriptionByStripeId(subscriptionId);
        
        if (subscription) {
          // Update subscription to mark it as inactive
          await storage.updateUserSubscription(subscription.id, {
            ...subscription,
            isActive: false,
            endDate: new Date() // End subscription immediately
          });
          
          console.log(`Marked subscription ${subscription.id} as inactive due to payment failure`);
          return {
            success: true,
            message: `Subscription ${subscription.id} marked as inactive due to payment failure`
          };
        }
        return {
          success: true,
          message: 'No matching subscription found for failed payment'
        };
      }
      
      case 'customer.subscription.deleted': {
        // Handle subscription cancellation
        const deletedSubscription = event.data.object as Stripe.Subscription;
        
        // Find the user subscription with this Stripe subscription ID
        const userSubscription = await storage.getUserSubscriptionByStripeId(deletedSubscription.id);
        
        if (userSubscription) {
          // Update subscription to mark it as inactive
          await storage.updateUserSubscription(userSubscription.id, {
            ...userSubscription,
            isActive: false,
            endDate: new Date() // End subscription immediately
          });
          
          console.log(`Marked subscription ${userSubscription.id} as inactive due to deletion in Stripe`);
          return {
            success: true,
            message: `Subscription ${userSubscription.id} marked as inactive due to deletion in Stripe`
          };
        }
        return {
          success: true,
          message: 'No matching subscription found for deleted subscription'
        };
      }
      
      default:
        return {
          success: true,
          message: `Event type ${event.type} not processed`
        };
    }
  } catch (error) {
    console.error('Error processing Stripe webhook:', error);
    return {
      success: false,
      message: error instanceof Error ? error.message : 'Unknown error processing webhook'
    };
  }
}