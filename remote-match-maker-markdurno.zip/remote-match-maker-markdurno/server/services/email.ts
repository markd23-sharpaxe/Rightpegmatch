import sgMail from '@sendgrid/mail';

// Initialize SendGrid with API key
if (!process.env.SENDGRID_API_KEY) {
  console.warn('SENDGRID_API_KEY is not set. Email functionality will not work.');
} else {
  sgMail.setApiKey(process.env.SENDGRID_API_KEY);
}

// Email sending configuration
const FROM_EMAIL = 'info@rightpegmatch.com'; // Use your GoDaddy email address here
const APP_NAME = 'RightPegMatch';
const APP_URL = process.env.APP_URL || 'https://rightpegmatch.com';

/**
 * Send a password reset email
 * @param to Recipient email address
 * @param resetToken Password reset token
 * @returns Promise that resolves when email is sent
 */
export async function sendPasswordResetEmail(to: string, resetToken: string): Promise<boolean> {
  try {
    if (!process.env.SENDGRID_API_KEY) {
      console.log(`[DEV MODE] Password reset link for ${to}: ${APP_URL}/reset-password?token=${resetToken}`);
      return true;
    }
    
    const resetLink = `${APP_URL}/reset-password?token=${resetToken}`;
    
    const msg = {
      to,
      from: FROM_EMAIL,
      subject: `${APP_NAME} - Reset Your Password`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #6C4ED9; padding: 20px; text-align: center;">
            <h1 style="color: white; margin: 0;">${APP_NAME}</h1>
          </div>
          <div style="padding: 20px; border: 1px solid #ddd; border-top: none;">
            <h2>Reset Your Password</h2>
            <p>We received a request to reset your password. Click the button below to set a new password:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetLink}" style="background-color: #6C4ED9; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px; font-weight: bold;">Reset Password</a>
            </div>
            <p>If you didn't request a password reset, you can safely ignore this email.</p>
            <p>This link will expire in 1 hour for security reasons.</p>
            <p>If the button doesn't work, copy and paste this URL into your browser:</p>
            <p style="word-break: break-all; font-size: 14px; color: #666;">${resetLink}</p>
            <hr style="margin: 30px 0; border: none; border-top: 1px solid #ddd;" />
            <p style="font-size: 12px; color: #999;">
              &copy; ${new Date().getFullYear()} ${APP_NAME}. All rights reserved.
            </p>
          </div>
        </div>
      `,
    };
    
    await sgMail.send(msg);
    return true;
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return false;
  }
}