CREATE TABLE IF NOT EXISTS job_required_skills (
  job_id INTEGER NOT NULL REFERENCES jobs(id),
  skill_id INTEGER NOT NULL REFERENCES skills(id),
  PRIMARY KEY (job_id, skill_id)
);