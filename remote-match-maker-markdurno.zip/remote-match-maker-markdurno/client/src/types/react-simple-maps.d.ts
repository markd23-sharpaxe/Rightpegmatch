// This module is no longer used in the project
// We've replaced react-simple-maps with a custom implementation
// that doesn't require any external dependencies

declare module 'react-simple-maps' {
  // Empty declaration to satisfy TypeScript
}