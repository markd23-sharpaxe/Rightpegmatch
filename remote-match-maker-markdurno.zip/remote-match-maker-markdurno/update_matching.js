import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const filePath = path.join(__dirname, 'server/db-storage.ts');

let content = fs.readFileSync(filePath, 'utf8');

// Add jobFamily parameter to first calculateAIJobMatchScore call
content = content.replace(
  /jobHoursPerWeek: job\.hoursPerWeek \|\| 0,(\s+)\/\/ User details/,
  'jobHoursPerWeek: job.hoursPerWeek || 0,\n          jobFamily: job.jobFamily || "Other",\n// User details'
);

// Add userJobFamily to the first call
content = content.replace(
  /userPreferredHours: user\.preferredHoursPerWeek \|\| 0(\s+)\}\);/,
  'userPreferredHours: user.preferredHoursPerWeek || 0,\n          userJobFamily: userPrimaryJobRole?.jobFamily || "Other"\n});'
);

// Update the second calculateAIJobMatchScore call for searching workers for a job
content = content.replace(
  /jobHoursPerWeek: job\.hoursPerWeek \|\| 0,(\s+)\/\/ User details([\s\S]*?)userPreferredHours: user\.preferredHoursPerWeek \|\| 0(\s+)\}\);/,
  'jobHoursPerWeek: job.hoursPerWeek || 0,\n          jobFamily: job.jobFamily || "Other",\n// User detailsuserPreferredHours: user.preferredHoursPerWeek || 0,\n          userJobFamily: userPrimaryJobRole?.jobFamily || "Other"\n});'
);

// Add jobFamilyMatch to the matchScore keyFactors recording
content = content.replace(
  /aiLanguageMatch: aiMatch\.keyFactors\.languageMatch,(\s+)aiCompensationMatch: aiMatch\.keyFactors\.compensationMatch/,
  'aiLanguageMatch: aiMatch.keyFactors.languageMatch,\n            jobFamilyMatch: aiMatch.keyFactors.jobFamilyMatch || 0,aiCompensationMatch: aiMatch.keyFactors.compensationMatch'
);

// Do the same for the second instance
content = content.replace(
  /aiLanguageMatch: aiMatch\.keyFactors\.languageMatch,(\s+)aiCompensationMatch: aiMatch\.keyFactors\.compensationMatch/g,
  'aiLanguageMatch: aiMatch.keyFactors.languageMatch,\n            jobFamilyMatch: aiMatch.keyFactors.jobFamilyMatch || 0,aiCompensationMatch: aiMatch.keyFactors.compensationMatch'
);

fs.writeFileSync(filePath, content);
console.log('Updated AI matching with job family parameters');
